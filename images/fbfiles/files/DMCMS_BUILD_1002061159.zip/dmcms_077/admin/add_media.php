<?php

if (!isset($INDM)) {echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html><head><meta http-equiv="content-type" content="text/html; charset=iso-8859-1"><meta name="Content-Language" content="en"><meta name="description" content="DMCMS"><meta name="author" content="Mick Percy"><meta name="copyright" content="Copyright 2007 DeeEmm"><title>DMCMS</title></HEAD><body><br><br><br><br><br><br><br><br><center><img src="http://www.deeemm.com/images/logo.gif" alt="DMCMS"><br><a href="http://www.deeemm.com"><span style="font-weight:bold">http://www.deeemm.com</span></a></center></body></html>'; exit;}

//===========================================================================

//===========================================================================
//>check user priviledges
//===========================================================================
require 'validate.php';
if ($user != 'ADMIN') header("Location: " . $default_path . "index.php");

$content = $default_path . "admin/templates/admin_mod_media.tpl";
$main = read_file($content);


//===========================================================================
//>if $id is not set -  new file is being added
//===========================================================================
if (!isset($id) || $id == ''){
	$admin_title = $lan[add_media];

	//propogate media category drop down list
	$media_library_list = "<select style=\"width:71%; float:right\" name='parent'>";
	foreach($media_tables as $value){
		if ($value == $page){
			$value = str_replace($value, "<option selected value='$value'>$value</option>", $value);
			$media_library_list .= $value;
		} else {
			$value = str_replace($value, "<option>$value</option>", $value);
			$media_library_list .= $value;
		}
	}
	$media_library_list = str_replace('  ', '', $media_library_list);
	$media_library_list .= '</select>';

	$media_category_list = "<select name=\"category\" onChange=\"this.form.selected_category.value = this.options[this.selectedIndex].text\"	style=\"position:absolute;z-index:1;width:190px;clip:rect(0px,190px, 22px, 80px)\"><option selected value='$category'>$category</option>";
	foreach($media_categories as $value){
		//propogate category type option list
		if ($value != $category) {
			$media_category_list .= "<option>$value</option>";
		}
	}
	$media_category_list = str_replace('  ', '', $media_category_list);
	$media_category_list .= '</select>';


	$article_ref = "index.php?page=admin";
}

?>
