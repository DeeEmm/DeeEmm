<?php

if (!isset($INDM)) {echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html><head><meta http-equiv="content-type" content="text/html; charset=iso-8859-1"><meta name="Content-Language" content="en"><meta name="description" content="DMCMS"><meta name="author" content="Mick Percy"><meta name="copyright" content="Copyright 2007 DeeEmm"><title>DMCMS</title></HEAD><body><br><br><br><br><br><br><br><br><center><img src="http://www.deeemm.com/images/logo.gif" alt="DMCMS"><br><a href="http://www.deeemm.com"><span style="font-weight:bold">http://www.deeemm.com</span></a></center></body></html>'; exit;}

//===================================================================================================
//>check user priviledges
//===================================================================================================
require 'validate.php';

//===================================================================================================
//check user level is admin
//===================================================================================================
if ($user !== 'ADMIN') {
	header("Location: " . $default_url);
	break;
} else {

	//  $db_file = file_get_contents(strtolower(basename($_FILES['db_filename']['db_filename'])));
	//	breakpoint($db_file);
	$db_filename = $_REQUEST['db_filename'];
	if ($db_filename == 'select_file') {
		//selection not changed upload file if selected
		$db_filename = $_REQUEST['local_db_filename'];
		$new_filename = upload_file('db_backups/' . $db_filename, 'local_db');
		$db_file = read_file('db_backups/' . $new_filename);
	} else {
		$db_file = read_file('db_backups/' . $db_filename);
	}

	//split file line by line
	$db_file_array = preg_split('/\n/', $db_file);
	//check each line
	foreach($db_file_array as $value){
		//if it's not a comment or blank line execute sql statement
		if (preg_match("/^[^#\s ]/", $value)) mysql_query($value);
	}
}

?>