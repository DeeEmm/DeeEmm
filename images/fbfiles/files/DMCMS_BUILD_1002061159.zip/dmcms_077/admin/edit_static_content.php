<?php

if (!isset($INDM)) {echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html><head><meta http-equiv="content-type" content="text/html; charset=iso-8859-1"><meta name="Content-Language" content="en"><meta name="description" content="DMCMS"><meta name="author" content="Mick Percy"><meta name="copyright" content="Copyright 2007 DeeEmm"><title>DMCMS</title></HEAD><body><br><br><br><br><br><br><br><br><center><img src="http://www.deeemm.com/images/logo.gif" alt="DMCMS"><br><a href="http://www.deeemm.com"><span style="font-weight:bold">http://www.deeemm.com</span></a></center></body></html>'; exit;}

//===========================================================================

//===========================================================================
//>check user priviledges
//===========================================================================
require 'validate.php';
if ($user != 'ADMIN')header("Location: " . $default_path . "index.php");

$content = $default_path . "admin/templates/admin_mod_static_content.tpl";
$admin_title = $lan[$action];

//$description_lan_1 = mysql_escape_string(stripslashes($_REQUEST['description_lan_1']));
$description_lan_1 = $_REQUEST['description_lan_1'];

$action = str_replace( 'edit_', '', $action);

switch ($action) {

	case 'save_static_content';
	$page = $_REQUEST['page'];
	mysql_query("UPDATE `" . $db_table_prefix . "static_content` SET `description_lan_1` = '$description_lan_1' WHERE `category` = '$page'");
	header("Location: " . $default_path . "index.php");
	break;

	case $action;
	$page = $action;
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "static_content` WHERE `category` = '$page'");
	while($sql_result = mysql_fetch_array($sql_query)){
		$description_lan_1 = rtesafe($sql_result[description_lan_1]);
	}
	$rte_editor_rows = '30';
	$rte_editor_width = '100%';
	break;

	default :
		break;

}

$main = read_file($content);

/*===========================================================================
 //>replace template markers with variables
 ===========================================================================*/
$main = replace_variables($main);

echo $main;
exit;


?>
