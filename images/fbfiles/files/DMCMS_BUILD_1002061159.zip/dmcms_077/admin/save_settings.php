<?php
if (!isset($INDM)) {echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html><head><meta http-equiv="content-type" content="text/html; charset=iso-8859-1"><meta name="Content-Language" content="en"><meta name="description" content="DMCMS"><meta name="author" content="Mick Percy"><meta name="copyright" content="Copyright 2007 DeeEmm"><title>DMCMS</title></HEAD><body><br><br><br><br><br><br><br><br><center><img src="http://www.deeemm.com/images/logo.gif" alt="DMCMS"><br><a href="http://www.deeemm.com"><span style="font-weight:bold">http://www.deeemm.com</span></a></center></body></html>'; exit;}

//===========================================================================
//>check user priviledges
//===========================================================================
require 'validate.php';

//get user input
$site_name = $_REQUEST['site_name'];
$site_description = $_REQUEST['site_description'];
$site_is_active = $_REQUEST['site_is_active'];
$admin_email = $_REQUEST['admin_email'];
$db_editor_path = $_REQUEST['db_editor_path'];
$login_link_enabled = $_REQUEST['login_link_enabled'];
$multi_language = $_REQUEST['multi_language'];
$search_enabled = $_REQUEST['search_enabled'];
$forum_enabled = $_REQUEST['forum_enabled'];
$forum_name = $_REQUEST['forum_name'];
$forum_path = $_REQUEST['forum_path'];
$forum_search_url = $_REQUEST['forum_search_url'];
$current_template = $_REQUEST['current_template'];
$language_1 = $_REQUEST['language_1'];
$language_1_flag = $_REQUEST['language_1_flag'];
$language_2 = $_REQUEST['language_2'];
$language_2_flag = $_REQUEST['language_2_flag'];
$language_3 = $_REQUEST['language_3'];
$language_3_flag = $_REQUEST['language_3_flag'];
$language_4 = $_REQUEST['language_4'];
$language_4_flag = $_REQUEST['language_4_flag'];

//save stuff to database
mysql_query("UPDATE " . $db_table_prefix . "admin SET
`site_name` = '$site_name',
`site_description` = '$site_description',
`site_is_active` = '$site_is_active',
`db_editor_path` = '$db_editor_path',
`login_link_enabled` = '$login_link_enabled',
`admin_email` = '$admin_email',
`multi_language` = '$multi_language',
`search_enabled` = '$search_enabled',
`forum_enabled` = '$forum_enabled',
`forum_name` = '$forum_name',
`forum_path` = '$forum_path',
`forum_search_url` = '$forum_search_url',
`current_template` = '$current_template',
`language_1` = '$language_1',
`language_1_flag` = '$language_1_flag',
`language_2` = '$language_2',
`language_2_flag` = '$language_2_flag',
`language_3` = '$language_3',
`language_3_flag` = '$language_3_flag',
`language_4` = '$language_4',
`language_4_flag` = '$language_4_flag' WHERE `id` = 0");

header("Location: " . $default_path . "index.php?page=admin&action=edit_settings");
?>