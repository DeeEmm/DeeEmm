<?php
if (!isset($INDM)) {echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html><head><meta http-equiv="content-type" content="text/html; charset=iso-8859-1"><meta name="Content-Language" content="en"><meta name="description" content="DMCMS"><meta name="author" content="Mick Percy"><meta name="copyright" content="Copyright 2007 DeeEmm"><title>DMCMS</title></HEAD><body><br><br><br><br><br><br><br><br><center><img src="http://www.deeemm.com/images/logo.png" alt="DMCMS"><br><a href="http://www.deeemm.com"><span style="font-weight:bold">http://www.deeemm.com</span></a></center></body></html>'; exit;}

//===========================================================================
//>check user priviledges
//===========================================================================
if ($user != 'ADMIN')header("Location: " . $default_path . "index.php");

switch ($action) {

	case 'find_user';
	$find_name = mysql_escape_string(stripslashes($_GET['find_name']));
	$popup = '<body onBlur="window.close()">';
	$popup .= $lan['matching_user_names'] . '<br><hr>';
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "users` WHERE `user_name` LIKE '%" . $find_name . "%'");
	while($sql_result = mysql_fetch_array($sql_query)) {
		$popup .= '<span style="float:right">[' . $sql_result[user_level] . ']</span><a href="index.php?page=admin&action=user_mod" onClick="window.close(); formSubmit()" target="main_window">' . $sql_result[user_name] . '</a><br>';
		//				$popup .= '<span style="float:right">[' . $sql_result[user_level] . ']</span><a href="index.php?page=admin&action=save_user" target="main_window" onClick="javascript: blur()">' . $sql_result[user_name] . '</a><br>';
	}
	$popup .= '</body">';
	echo $popup;
	exit;
	break;

	case 'save_user';
	//get data from form
	$user_name = mysql_escape_string(stripslashes($_REQUEST['user_name']));
	$user_level = mysql_escape_string(stripslashes($_REQUEST['user_level']));
	$password_1 = mysql_escape_string(stripslashes($_REQUEST['password_1']));
	$password_2 = mysql_escape_string(stripslashes($_REQUEST['password_2']));

	//check if user exists
	$sql_result = mysql_query("select * from `" . $db_table_prefix . "_users` WHERE `user_name` = '$user_name' LIMIT 1");
	if (!@mysql_result($sql_result,0)) {

		//if password present, check it matches confirmation then create user
		if (($password_1 != '' && $password_2 != '') && ($password_1 == $password_2)){
			$password_md5 = md5($password_1);
			mysql_query("INSERT INTO `" . $db_table_prefix . "users` VALUES('$user_name',
				  '$password_md5',
				  '',
				  '$user_level',
				  '',
				  '',
				  '',
					'',
				  (now()),
				  (now()),
				  '',
				  '')") or die ("<b>A fatal MySQL error occured</b>.\n<br />\nError: (" . mysql_errno() . ") " . mysql_error());;
			$page = 'messagebox';
			$warning_message = $lan['user_added'] . '"' . $user_name . '"';
		}
	}
	break;

	case 'delete_user';
	//delete user from database
	$user_name = mysql_escape_string(stripslashes($_REQUEST['user_name']));
	if ($user_name == 'Admin' || ($user == 'ADMIN' && !$user_name == 'Admin')){
		//cannot delete user 'Admin'
		$page = 'messagebox';
		$warning_message = $lan['cannot_delete_user'] . '"' . $user_name . '"';
	} else {
		mysql_query("DELETE FROM `" . $db_table_prefix . "users` WHERE `user_name` = '$user_name'");
		$page = 'messagebox';
		$warning_message = $lan['user_deleted'] . '"' . $user_name . '"';
	}
	break;
}

//display user moderation page if no message to be displayed
$content = $default_path . "admin/templates/admin_mod_users.tpl";
$main = read_file($content);
?>
