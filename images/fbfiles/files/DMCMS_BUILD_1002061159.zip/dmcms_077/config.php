<?php

if (!isset($INDM)) {echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html><head><meta http-equiv="content-type" content="text/html; charset=iso-8859-1"><meta name="Content-Language" content="en"><meta name="description" content="DMCMS"><meta name="author" content="Mick Percy"><meta name="copyright" content="Copyright 2007 DeeEmm"><title>DMCMS</title></HEAD><body><br><br><br><br><br><br><br><br><center><img src="http://www.deeemm.com/images/logo.gif" alt="DMCMS"><br><a href="http://www.deeemm.com"><span style="font-weight:bold">http://www.deeemm.com</span></a></center></body></html>'; exit;}

/*===========================================================================
Change the details below to get your site up and running
===========================================================================*/
$default_url = 'http://localhost/dmcms_077/'; //<--Change this to the default url of your site!
$db_username = 'DeeEmm'; //<--Change this to your database username
$db_password = 'DeeEmm'; //<--Change this to the password of the above user
$db_name = 'dmcms_077'; //<--Change this to the name of your database

/*===========================================================================
Misc settings - change these to suit your site
===========================================================================*/
$author = 'Mick Percy';
$meta_keywords = 'DeeEmm CMS, DMCMS, Open Source Content Management Software';
$header_copyright = "Copyright " . date ("Y") . " DMCMS";

/*===========================================================================
Only change the details below this line if you know what you are doing!!
===========================================================================*/
$default_path = './';
//  $absolute_path = '\home\dmv\public_html\';
$templates_dir =  'templates/';
$stylesheet = 'default.css';
$media_dir = 'media/';
$admin_dir = 'admin/';
$db_backup_dir = 'db_backups/';
$includes_dir = 'includes/';
$updates_dir = 'updates/';
$db_server = 'localhost';
//it is not reccomended to change the following lines as the auto update will not work
$db_table_prefix = 'deeemm_';
//===========================================================================
$backup_dmcms_tables_only = TRUE; 
$media_library_thumbs_per_page = 8;
$media_library_thumb_rows_per_page = 2;
$media_library_max_image_width = 80;
$media_library_thumb_width = 90;
$media_library_thumb_height = 70;
$media_library_video_width = 350;
$media_library_video_height = 300;
$max_upload_filesize = 100000000;
$max_search_results = 100;
$search_result_length = 400;
$num_search_results_per_page = 5;
$remote_support_enabled = TRUE;
$version_check_enabled = TRUE;
$db_save_to_file = TRUE;
$navigation_seperator = "&nbsp&nbsp&nbsp&nbsp";
$cookie_trial_seperator = ' > ';
$num_languages = 4;
$nav_style = 'buttons'; // (buttons / text)

//===========================================================================

?>
