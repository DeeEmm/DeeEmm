<?php
if (!isset($INDM)) {echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html><head><meta http-equiv="content-type" content="text/html; charset=iso-8859-1"><meta name="Content-Language" content="en"><meta name="description" content="DMCMS"><meta name="author" content="Mick Percy"><meta name="copyright" content="Copyright 2007 DeeEmm"><title>DMCMS</title></HEAD><body><br><br><br><br><br><br><br><br><center><img src="http://www.deeemm.com/images/logo.gif" alt="DMCMS"><br><a href="http://www.deeemm.com"><span style="font-weight:bold">http://www.deeemm.com</span></a></center></body></html>'; exit;}


//===========================================================================
//connect to server
//===========================================================================
$db_connection = mysql_connect($db_server,  $db_username,  $db_password) or die("Database Error: Could not connect to MySQL:" . mysql_error());
//===========================================================================
//select database
//===========================================================================
mysql_select_db($db_name) or die("Database Error: " . mysql_error());

?>