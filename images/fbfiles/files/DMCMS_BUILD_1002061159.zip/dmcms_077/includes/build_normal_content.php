<?php

if (!isset($INDM)) {echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html><head><meta http-equiv="content-type" content="text/html; charset=iso-8859-1"><meta name="Content-Language" content="en"><meta name="description" content="DMCMS"><meta name="author" content="Mick Percy"><meta name="copyright" content="Copyright 2007 DeeEmm"><title>DMCMS</title></HEAD><body><br><br><br><br><br><br><br><br><center><img src="http://www.deeemm.com/images/logo.gif" alt="DMCMS"><br><a href="http://www.deeemm.com"><span style="font-weight:bold">http://www.deeemm.com</span></a></center></body></html>'; exit;}

//===========================================================================


//===========================================================================
//>create recursive pages
//===========================================================================

$content = $default_path . $templates_dir  . "recursive_content.tpl";
$main = read_file($content);

if (!isset($id) || $id == ''){
	//display parent page

	//replace admin link template marker if admin
	$admin_href = $empty_normal_page_admin_href;

	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . $page . "` ORDER BY `date` DESC LIMIT 1");
	while($sql_result = @mysql_fetch_array($sql_query)){
		$id = $sql_result[id];
	}

} if(!$action) {

	//replace admin link template marker if admin
	$admin_href = $normal_page_admin_href;
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . $page . "` WHERE `id` = '$id'");

	//get data from database
	while($sql_result = mysql_fetch_array($sql_query)){
		$category = $sql_result[category];
		$title = $sql_result[title_lan_ . $language];
		$tool_tip = $sql_result[tool_tip_lan_ . $language];
		$article_text = $sql_result[description_lan_ . $language];
	}

	//replace template markers with data from database
	$main = str_replace('[var]list_item_href[/var]', $list_item_href, $main);
	$main = str_replace('[var]title[/var]', $title, $main);
	$main = str_replace('[var]list_body[/var]', $article_text, $main);

	$cookie_trial .= $cookie_trial_seperator . $title;
	$page_title .= $cookie_trial_seperator . $title;

	$list_item_href = "<STRONG><A HREF='$default_path"."index.php?page=$page&amp;id=$sql_result[id]'>";

}


?>