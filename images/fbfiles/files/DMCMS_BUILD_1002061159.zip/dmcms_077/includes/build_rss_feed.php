<?php

if (!isset($INDM)) {echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html><head><meta http-equiv="content-type" content="text/html; charset=iso-8859-1"><meta name="Content-Language" content="en"><meta name="description" content="DMCMS"><meta name="author" content="Mick Percy"><meta name="copyright" content="Copyright 2007 DeeEmm"><title>DMCMS</title></HEAD><body><br><br><br><br><br><br><br><br><center><img src="http://www.deeemm.com/images/logo.gif" alt="DMCMS"><br><a href="http://www.deeemm.com"><span style="font-weight:bold">http://www.deeemm.com</span></a></center></body></html>'; exit;}

//===========================================================================

$category = stripslashes($_GET["category"]);

//check which type of feed
if ($page == 'rss2'){
	//get page template
	$content = $default_path . $templates_dir . "rss2main.tpl";
	$main .= read_file($content);
	//set item template
	$content = $default_path . $templates_dir . "rss2item.tpl";
}


//foreach ($list_tables as $rss_item){

$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . $category . "` ORDER BY `date` DESC");
while($sql_result = @mysql_fetch_array($sql_query)){

	if (!$first_article) {
		//add new item
		$rss_items .= read_file($content);
		//get item info
		$rss_item_href = $default_url .'index.php?page=' . $category . '&amp;id=' . $sql_result[id];
		$rss_item_description = xmlsafe(balanceTags(truncate(strip_tags($sql_result[description_lan_ . $language]), 200)));
		$rss_item_description = preg_replace('/\n|\r|\n\r/',' ',$rss_item_description); //convert crlf to space

		$rss_item_title = xmlsafe($sql_result[title_lan_ . $language]);
		$rss_item_category = $category;
		//      $category_date = strftime("%A %d %B %Y", strtotime($sql_result[date]));
		$rss_item_date = strftime ("%a, %d %b %Y %H:%M:%S +0000", strtotime($sql_result[date]));

		$rss_items = replace_variables($rss_items);

	}

}// end while
//}

//$main = xmlsafe($main);

$main = replace_variables($main);
header("Content-Type: application/xml; charset=ISO-8859-1");
echo $main;

?>