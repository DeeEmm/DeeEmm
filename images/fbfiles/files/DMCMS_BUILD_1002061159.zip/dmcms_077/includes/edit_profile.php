<?php
if (!isset($INDM)) {echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html><head><meta http-equiv="content-type" content="text/html; charset=iso-8859-1"><meta name="Content-Language" content="en"><meta name="description" content="DMCMS"><meta name="author" content="Mick Percy"><meta name="copyright" content="Copyright 2007 DeeEmm"><title>DMCMS</title></HEAD><body><br><br><br><br><br><br><br><br><center><img src="http://www.deeemm.com/images/logo.gif" alt="DMCMS"><br><a href="http://www.deeemm.com"><span style="font-weight:bold">http://www.deeemm.com</span></a></center></body></html>'; exit;}


//===========================================================================
//>check user priviledges
//===========================================================================
require 'validate.php';
if ($logged_in != true)header("Location: " . $default_path . "index.php");


if ($action == 'save_profile') {

	//>get data from form
	$password_old = mysql_escape_string(stripslashes($_REQUEST['password_old']));
	$password_1 = mysql_escape_string(stripslashes($_REQUEST['password_1']));
	$password_2 = mysql_escape_string(stripslashes($_REQUEST['password_2']));


	//>if password fields set - change password
	if ($password_old != '' || $password_1 != '' || $password_2 != '') {
		if ((md5($password_old) == $password) && ($password_1 == $password_2)) {
			$password_new = md5($password_1);
			mysql_query("UPDATE " . $db_table_prefix . "users SET `password` = '$password_new' WHERE `user_name` = '$username'");
			$status_message = $lan[password_changed];
		} else {
			$status_message = $lan[password_not_changed];
		}
	}
}


//>get profile info and propogate form

$content = $default_path . $templates_dir . "edit_profile.tpl";
$main = read_file($content);

$main = replace_variables($main);

?>