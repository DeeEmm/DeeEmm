<?php
if (!isset($INDM)) {echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html><head><meta http-equiv="content-type" content="text/html; charset=iso-8859-1"><meta name="Content-Language" content="en"><meta name="description" content="DMCMS"><meta name="author" content="Mick Percy"><meta name="copyright" content="Copyright 2007 DeeEmm"><title>DMCMS</title></HEAD><body><br><br><br><br><br><br><br><br><center><img src="http://www.deeemm.com/images/logo.gif" alt="DMCMS"><br><a href="http://www.deeemm.com"><span style="font-weight:bold">http://www.deeemm.com</span></a></center></body></html>'; exit;}


if($username && $password) {
	$password = md5($password);
	$sql = "SELECT * FROM `" . $db_table_prefix . "users` WHERE `user_name` = '$username'";
	$result = mysql_db_query($db_name,$sql);
	if(!mysql_num_rows($result))
	header("Location: index.php?page=login");
	$user = mysql_fetch_array($result);
	if($user["password"] == $password) {
		$password = base64_encode(serialize($password));
		setcookie("deeemm","$username $password");
		$msg = "<meta http-equiv=\"Refresh\" content=\"0;url=index.php\">";
	}else{
		header("Location: index.php?page=login");
	}
}
if($msg) echo $msg;

$content = $default_path . $templates_dir  . "login.tpl";
$main = read_file($content);
?>