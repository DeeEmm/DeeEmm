<?php
if (!isset($INDM)) {echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html><head><meta http-equiv="content-type" content="text/html; charset=iso-8859-1"><meta name="Content-Language" content="en"><meta name="description" content="DMCMS"><meta name="author" content="Mick Percy"><meta name="copyright" content="Copyright 2007 DeeEmm"><title>DMCMS</title></HEAD><body><br><br><br><br><br><br><br><br><center><img src="http://www.deeemm.com/images/logo.gif" alt="DMCMS"><br><a href="http://www.deeemm.com"><span style="font-weight:bold">http://www.deeemm.com</span></a></center></body></html>'; exit;}


//===========================================================================
//>check user priviledges
//===========================================================================
require 'validate.php';


//transfer file
$filename = strtolower(basename($_FILES['file_data']['name']));

if ($filename) {
	$destination_file = $default_path . $media_dir . $filename;
	echo strtolower(basename($_FILES['file_data']['name']));
}

if (file_exists($destination_file)) {
	$count = 1;
	while(file_exists($destination_file)) {
		$filename = $count . '_' .  $filename;
		$destination_file = $default_path . $media_dir . $filename ;
		$count++;
	}
}


if ($filename && !file_exists($destination_file)) {
	if (!move_uploaded_file($_FILES['file_data']['tmp_name'], $destination_file)) {
		echo '<br>' . "Upload failed!" .'<br>';
		echo $destination_file .'<br>';
		echo ($_FILES['file_data']['name']) .'<br>';
		echo ($_FILES['file_data']['tmp_name']) .'<br>';
		echo ($_FILES['file_data']['size']) .'<br>';
		echo ($_FILES['file_data']['type']) .'<br>';
		echo ($_FILES['file_data']['error']) .'<br>';
		//print_r ($_FILES);
		exit;
	}
}

//check file upload ok then update database
if ($_FILES['file_data']['error'] == 0 ){
	$file_uploaded = TRUE;
} else {
	$file_uploaded = FALSE;
	//file upload not ok
	header("Location: " . $default_path . '$default_url"."index.php?page=messagebox&message=no_data');
	exit;
}
?>