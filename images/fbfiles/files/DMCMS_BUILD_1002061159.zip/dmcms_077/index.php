<?php
/*[Info]=====================================================================
 index.php
 Original File Created on 24/12/04 20:15 by Mick Percy

 DMCMS is an open source Content Management System (CMS) provided free for use
 under the GNU General Public License.

 ==[Support]=====================================================================
 Support for DMCMS is provided via the following channels:
 The DeeEmm forum at http://www.deeemm.com/forum
 The DeeEmm wiki at http://www.deeemm.com/wiki
 The DMCMS support tracker hosted at the DMCMS SourceForge project page at
 http://sourceforge.net/projects/dmcms/

 ==[Bug Tracking / Feature Requests]=============================================
	Please report all bugs using the tracker which can be found at
	http://sourceforge.net/tracker/?group_id=189064

	==[Copyright]===================================================================
	DMCMS (Also known as DeeEmm CMS), and all constituent files including
	this file are copyright (C) 2007 Mick Percy. All rights reserved.

	==[License]=====================================================================
	This file is part of DMCMS (Also known as DeeEmm CMS).
	DMCMS is free software; you can redistribute it and/or modify it under
	the terms of the GNU General Public License as published by the Free
	Software Foundation; either version 2 of the License, or (at your option)
	any later version.
	DMCMS is distributed in the hope that it will be useful, but WITHOUT ANY
	WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
	FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
	details.
	You should have received a copy of the GNU General Public License along
	with DMCMS; if not, write to the Free Software Foundation, Inc.,
	51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA or alternatively
	you can visit http://www.gnu.org/copyleft/gpl.html

	==[Changelog]===================================================================
	Please refer to README.TXT for the changelog

	==[Installation]================================================================
	Please refer to README.TXT for installation instructions

	==============================================================================*/

ob_start();
session_start();

$INDM = TRUE;

/*===========================================================================
 //>required files
 ===========================================================================*/
require './initialise.php';
require './config.php';
require './functions.php';
require './db_access.php';
require './site_status.php';
require $includes_dir . 'build_static_content.php';

/*===========================================================================
 //>get navigation string query from browser
 ===========================================================================*/
$page = anti_inject(htmlspecialchars($_GET["page"], ENT_QUOTES));
$child = anti_inject(htmlspecialchars($_GET["child"], ENT_QUOTES));
$category = anti_inject(htmlspecialchars($_GET["category"], ENT_QUOTES));
$id = anti_inject(htmlspecialchars($_GET["id"], ENT_QUOTES));
$search_text = anti_inject(htmlspecialchars($_GET["search"], ENT_QUOTES));
$action = anti_inject(htmlspecialchars($_GET["action"], ENT_QUOTES));
$message = anti_inject(htmlspecialchars($_GET["message"], ENT_QUOTES));

/*===========================================================================
Check $id only contains numbers
 ===========================================================================*/
if (preg_match_all("/[^0-9]/", $id, $matches)){
	echo 'Possible Hack Attempt';
	exit;	
}

/*===========================================================================
Check $page only contains valid characters
 ===========================================================================*/
if (preg_match_all("/[^ _A-Za-z0-9]/", $page, $matches)){
	echo 'Possible Hack Attempt';
	exit;	
}


/*===========================================================================
 //>check user priviledges
 ===========================================================================*/
require './validate.php';


/*===========================================================================
 //>get language related info
 ===========================================================================*/
require './user_language.php';


/*===========================================================================
 //>if maintenance mode send maintenance page to browser
 ===========================================================================*/
if ($site_is_active !== 'on' && $user !== 'ADMIN' && $page !== 'login') {
	$page_title .= $cookie_trial_seperator . $lan[maintenance];
	$cookie_trial =  "<a href='$default_path?page=login'>" . $lan[login] . "</a>";
	$header = read_file($default_path . $templates_dir  . "header.tpl");
	$banner = read_file($default_path . $templates_dir  . "banner.tpl");
	$main = read_file($default_path . $templates_dir . "maintenance.tpl");
	$footer = read_file($default_path . $templates_dir  ."footer.tpl");
	$page_html = $header . $banner . $main . $footer;
	$page_html = replace_variables($page_html);
	$page_html = replace_dm_code($page_html);
	$page_html = replace_language($page_html);
	echo $page_html;
	exit;
}


/*===========================================================================
 //>set page title + cookie trial
 ===========================================================================*/
if ($page !== 'login')  {
	$display = '3';

	if ($user == 'ADMIN')  {
		$cookie_trial = '<a href="' . $default_url . 'index.php?page=admin&action=edit_sitemap">[ ' . $lan[sitemap] . ' ]</a>' . $cookie_trial_seperator . '<a href="[var]default_url[/var]">' . $site_name . '</A>';
	} ELSE {
		$cookie_trial = '<a href="' . $default_url . 'index.php?page=sitemap">[ ' . $lan[sitemap] . ' ]</a>' . $cookie_trial_seperator . '<a href="[var]default_url[/var]">' . $site_name . '</A>';
	}

	$page_title = $cookie_trial_seperator . ucfirst($page);
	if ($page !== 'orphan' && $page !== '') {
		$cookie_trial .= $cookie_trial_seperator . '<a href = "' . $default_url . 'index.php?page=' . $page . '&id=1">' . ucfirst($page) . '</a>';
	}
} else {
	$display = '1';
}

/*===========================================================================
 //>get standard page header
 ===========================================================================*/
$header = read_file($default_path . $templates_dir  . "header.tpl");


/*===========================================================================
 //>get standard page banner
 ===========================================================================*/
$banner = read_file($default_path . $templates_dir  . "banner.tpl");


/*===========================================================================
 //>if site active or user is admin get content
 ===========================================================================*/
if ($site_is_active || $user == 'ADMIN') {

	//get left and right columns
	$left_column = read_file($default_path . $templates_dir  . "left_column.tpl");
	$right_column = read_file($default_path . $templates_dir  . "right_column.tpl");


	//>if search enabled add searchbox
	if ($search_enabled) {
		$searchbox = read_file($default_path . $templates_dir  ."searchbox.tpl");
		$searchbox = replace_variables($searchbox);
	} else {
		$searchbox = '';
	}


	//>select random list item(s)
	if (count($newsbox_libraries) > 0) {
		include $includes_dir . 'build_newsbox_content.php';
	}


	//>select random media library picture(s)
	if (count($imagebox_libraries) > 0) {
		include $includes_dir . 'build_imagebox_content.php';
	}



	//>if enabled create multi language navigation box
	if ($multi_language) {
		$content = $default_path . $templates_dir . "multi_language_nav.tpl";
		$multi_language_nav = read_file($content);
		$multi_language_nav = replace_variables($multi_language_nav);
	} else {
		$multi_language_nav = '';
	}

	if ($login_link_enabled) {
		$login_link = "<A class='navmenulinks' href='$default_path"."index.php?page=login' title='Log In'>Log In</A>";
	} else {
		$login_link = '';
	}
}


/*===========================================================================
 //>ADMIN functions
 ===========================================================================*/

//>check if admin user
if ($user=='ADMIN'){

	//set link to admin javascript functions
	$admin_javascript_link = '<script language="javascript"  type="text/javascript" src="./javascript/admin_functions.js"></script>';

	//>select admin action
	switch ($action) {

		case 'messagebox';
		$message = $lan[warning];
		$warning_message = $lan[delete_warning];

		$content = $default_path . $templates_dir  . "message_box.tpl";
		$main = read_file($content);
		break;

		//edit  sitemap
		case 'edit_sitemap';
		require $admin_dir . 'build_admin_sitemap.php';
		break;

		//change settings
		case 'edit_settings';
		require $admin_dir . 'edit_settings.php';
		break;

		//content = edit static content
		case 'edit_left_column';
		case 'edit_right_column';
		case 'edit_banner';
		case 'edit_footer';
		case 'save_static_content';
		require $admin_dir . 'edit_static_content.php';
		exit;
		break;

		//save settings
		case 'save_settings';
		require $admin_dir . 'save_settings.php';
		break;
		
	    case 'delete_db';
	    	$db_filename = './db_backups/' . $_REQUEST['db_filename'];
	    	@fclose($db_filename);
	    	unlink($db_filename);
	    	header("Location: " . $default_path . "index.php?page=admin&action=edit_settings&tab=4");
	    break;
	    
		//restore database
		case 'restore_db';
		require $admin_dir . 'db_restore.php';
		header("Location: " . $default_path . "index.php?page=admin&action=edit_settings");
		break;

		//backup database
		case 'backup_db';
		$db_save_to_file = $_REQUEST['db_save_to_file'];
		require $admin_dir . 'db_backup.php';
		header("Location: " . $default_path . "index.php?page=admin&action=edit_settings");
		break;

		//display server settings
		case 'phpinfo';
		echo phpinfo();
		exit;
		break;

		//edit users
		case 'find_user';
		case 'user_mod';
		case 'save_user';
		case 'delete_user';
		require $admin_dir . 'user_mod.php';
		break;

		//content = edit categories
		case 'move_up_category';
		case 'move_down_category';
		case 'move_up_subcategory';
		case 'move_down_subcategory';
		case 'delete_category';
		case 'save_categories';
		case 'edit_sitemap';
		case 'change_categories';
		require $admin_dir . 'edit_sitemap.php';
		//redirect page to sitemap
		$page = 'sitemap';
		break;

		//content = edit / add normal page
		case 'edit';
		case 'add';
		require $admin_dir . 'edit_content.php';
		$page = 'admin';
		break;

		//content = display add media page
		case 'add_media';
		require $admin_dir . 'add_media.php';
		$page = 'admin';
		break;

		//content = display add link page
		case 'add_link';
		case 'edit_link';
		require $admin_dir . 'edit_link.php';
		$page = 'admin';
		break;

		//content = display add link page
		case 'save_link';
		require $admin_dir . 'save_link.php';
		$page = 'sitemap';
		break;

		//content = display edit media page
		case 'edit_media';
		require $admin_dir . 'edit_media.php';
		$page = 'admin';
		break;

		//delete current article data
		case 'delete';
		require $admin_dir . 'delete_item.php';
		break;

		//save media article data
		case 'save_media';
		require $admin_dir . 'save_media.php';
		break;

		//save current article data
		case 'save_content';
		require $admin_dir . 'save_content.php';
		break;

		//edit / save profile
		case 'edit_profile';
		$page = 'admin';
		case 'save_profile';
		require $admin_dir . 'edit_profile.php';
		break;

		$article_ref = "index.php?page=$page&child=$child";

		//display current article data
		if (!isset($action))  header("Location: " . $default_path . $article_ref);  exit;

	} //end switch $action
} elseif ($page == 'admin') { //if user not admin send to homepage
	$page = '';
}


/*===========================================================================
 //>USER functions
 ===========================================================================*/

//>check if active user
if ($user=='USER' || $user=='ADMIN'){
	switch ($action) {

		//    //edit / save profile
		//    case 'edit_profile';
		//    case 'save_profile';
		//      require $includes_dir . 'edit_profile.php';
		//    break;

	}
}


/*===========================================================================
 //>build navigation menu
 ===========================================================================*/
if ($site_is_active == 'on' || $user == 'ADMIN') {
	include $includes_dir . 'build_navigation.php';
}


/*===========================================================================
 //>perform search if search string present
 ===========================================================================*/
if (strlen($search_text) > 0){
	include $includes_dir . 'perform_site_search.php';
} else {

	/*===========================================================================
	 //>generate page from navigation query result
	 ===========================================================================*/
	switch ($page) {

  //add cases here where you do not want any action to be carried out
  //otherwise case '$page' will pick up all not specified

  case 'messagebox';
  $content = $default_path . $templates_dir  . "message_box.tpl";
  $main = read_file($content);
		$admin_href = $empty_media_page_admin_href;
  break;

  case 'admin';
  $header = read_file($default_path . "admin/templates/admin_header.tpl");
  $footer = read_file($default_path . "admin/templates/admin_footer.tpl");
  $layout = $header . $main . $footer;
		$layout = replace_variables($layout);
		$layout = replace_language($layout);
		echo $layout;
		Exit;
  break;

  case 'user';
  break;

  //rss2 feed create
  case 'rss2';
  case 'rss1';
  case 'atom';
  include $includes_dir . 'build_rss_feed.php';
  exit;
  break;

  //display sitemap content
  case 'sitemap';
  include $includes_dir . 'build_sitemap.php';
  break;

  //check login / display login form
  case 'login';
  include $includes_dir . 'login.php';
  break;

  //check logout / cancel session
  case 'logout';
  setcookie ("deeemm", "", time() - 3600);
  header("Location: " . $default_path . "index.php");
  exit;

  //build pages based on type
  case $page :

  	if ($page == 'orphan') $type = 'orphan';

  	//if no page set use page ranked highest by order (i.e. index / home page)
  	if ($page == '' || !isset($page)) {
  		unset($action);
  		$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "structure` WHERE `order` = 1");
  		while($sql_result = mysql_fetch_array($sql_query)) {
  			$page = $sql_result[table];
  		}
  		$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . $page . "` WHERE `order` = 1");
  		while($sql_result = mysql_fetch_array($sql_query)) {
  			$id = $sql_result[id];
  		}
  	}

  	if (!$id || $id == 'id') { //fix for strange bug where $id becomes id!!?!
  		$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . $page . "` WHERE `order` = 1");
  		while($sql_result = mysql_fetch_array($sql_query)) {
  			$id = $sql_result[id];
  		}
  	}


  	//get page type from database
  	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "structure` WHERE `table` = '$page'");
  	while($sql_result = mysql_fetch_array($sql_query)) {
  		$type = $sql_result[type];
  	}

  	//process page type
  	switch ($type) {

  		//build normal / home pages
  		case 'normal' :
  		case 'orphan' :
  			include $includes_dir . 'build_normal_content.php';
  			break;

  			//build news / list / blog type page
  		case 'list' :
  		case 'list + newsbox' :
  			include $includes_dir . 'build_list_content.php';
  			break;

  			//build media pages
  		case 'media' :
  			include $includes_dir . 'build_media_content.php';
  			break;

  			//build forum
  		case 'forum' :
  			//include $includes_dir . 'build_normal_content.php';
  			break;

  			//if no other cases match
  		default :
  			//        include $includes_dir . 'build_normal_content.php';
  			break;

  	} //end switch ($type)
	} //end switch ($page)
} // end search else


	/*===========================================================================
	 //>build standard page footer
	 ===========================================================================*/
	$footer = read_file($default_path . $templates_dir  ."footer.tpl");

	/*===========================================================================
	 //>construct the page
	 ===========================================================================*/
	switch ($display) {
  case '1' : //single column
  	$page_html = $header . $banner . $main . $footer;
  	break;

  case '2' : //two columns
  	$page_html = $header . $banner . $main . $left_column  . $footer;
  	break;

  case '3' : //three columns
  	$page_html = $header . $banner . $main . $left_column . $right_column . $footer;
  	break;
	}


	/*===========================================================================
	 //>replace template markers with variables
	 ===========================================================================*/
	$page_html = replace_variables($page_html);
	$page_html = replace_dm_code($page_html);
	$page_html = replace_language($page_html);


	/*===========================================================================
	 //>send page to browser
	 ===========================================================================*/
	echo $page_html;


	mysql_close($db_connection);
	ob_end_flush();
	?>
