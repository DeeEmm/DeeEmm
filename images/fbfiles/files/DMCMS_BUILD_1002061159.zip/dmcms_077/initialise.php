<?php
if (!isset($INDM)) {echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html><head><meta http-equiv="content-type" content="text/html; charset=iso-8859-1"><meta name="Content-Language" content="en"><meta name="description" content="DMCMS"><meta name="author" content="Mick Percy"><meta name="copyright" content="Copyright 2007 DeeEmm"><title>DMCMS</title></HEAD><body><br><br><br><br><br><br><br><br><center><img src="http://www.deeemm.com/images/logo.gif" alt="DMCMS"><br><a href="http://www.deeemm.com"><span style="font-weight:bold">http://www.deeemm.com</span></a></center></body></html>'; exit;}

//===========================================================================
$short_date = date ("F j Y");
$year = date ("Y");
$long_date = date ("F j Y - g:i:s");
$long_time = date ("g:i:s");
$short_time = date ("g:i");
$crlf = "\r\n";
$lf = "\n";
$nav_seperator = " :: ";
//===========================================================================
$main = '';
$page_title = '';
$cookie_trial = '';
$hidden_header = '';
$list_item_href = '';
$return_link = '';
$news_article_edit = '';
$list_article_edit = '';
$list_index_edit = '';
$media_library_index_edit = '';
$media_library_image_edit = '';
$media_href = '';
$admin_nav = '';
$h_nav_menu = '';
$v_nav_menu = '';

//===========================================================================

?>