/*[ReadMe.txt]==================================================================
  DMCMS version 0.7.5 (DMCMS LT RC1)

==[Release Notes]===============================================================
  This release is to address some minor bugs.

==[Support]=====================================================================
  Support for DMCMS is provided via the following:
  The DeeEmm forum at http://www.deeemm.com/forum
  The DeeEmm wiki at http://www.deeemm.com/wiki
  The DMCMS support tracker hosted at the DMCMS SourceForge project page at
  http://sourceforge.net/projects/dmcms/

==[Bug Tracking / Feature Requests]=============================================
  Please report all bugs using the tracker which can be found at
  http://sourceforge.net/tracker/?group_id=189064

==[Copyright]===================================================================
  DMCMS (Also known as DeeEmm CMS), and all constituent files including
  this file are copyright (C) 2007 Mick Percy. All rights reserved.

==[License]=====================================================================
  This file is part of DM CMS (Also known as DeeEmm CMS).
    DM CMS is free software; you can redistribute it and/or modify it under
  the terms of the GNU General Public License as published by the Free
  Software Foundation; either version 2 of the License, or (at your option)
  any later version.
    DM CMS is distributed in the hope that it will be useful, but WITHOUT ANY
  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
  FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
  details.
    You should have received a copy of the GNU General Public License along
  with DM CMS; if not, write to the Free Software Foundation, Inc.,
  51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA or alternatively
  you can visit http://www.gnu.org/copyleft/gpl.html

==[Changelog]===================================================================

0.7.7 (DMCMS RC1) 28/08/2008
	Security Fixes.
		N/A
	Bug Fixes.
		N/A
	Added Features / Changes.
		Database Backup Handling
		Admin templates directory changed
	Changed files.
		./admin/edit_settings.php
		./admin/style/admin_mod_settings.tpl
		./index.php
		./admin/style/*.*
		

0.7.6 (DMCMS RC1) 17/08/2008
	Security Fixes.
		Remote File injection vulnerability
	Bug Fixes.
		N/A
	Added Features / Changes.
		N/A
	Changed files.
		./user_language.php

0.7.5 (DMCMS RC1) 16/08/2008
	Security Fixes.
		SQL injection vulnerability
	Bug Fixes.
		Fixed bug where hyphenated table names caused backup to crash
	Added Features / Changes.
		Added ability to select only DMCMS tables for database backup (default)
		Added ability to set metatags in header.tpl via config file
	Changed files.
		./admin/db_backup.php
		./templates/deeemm/header.tpl
		./index.php
		./functions.php

0.7.4 (DMCMS RC1) 10/07/2008
	Security Fixes.
		N/A
	Bug Fixes.
		N/A
	Added Features / Changes.
		Updated Admin Interface
		Added contextual help
	Changed files.
		./admin/help/*
		./admin/icons/*
		./admin/images/*
		./admin/style/*
		./admin/style/*
		./templates/.../admin/*
		./javascript/*
		./includes/build_sitemap.php
		./admin/build_sitemap.php

>>>>>>> 1.8.2.2
0.7.3 (BETA) 22/06/2008
	Security Fixes.
		N/A
	Bug Fixes.
		Media gallery display icon not showing for non-image files
		Changed paths to relative for sitemap admin template call
		Edit link changed for list type pages
	Added Features / Changes.
		Commented out check for deleting used files
	Changed files.
		./includes/build_sitemap.php
		./includes/build_media_content.php
		./includes/build_navigation.php
		./admin/delete_item.php

0.7.2 (BETA) 03/01/2008
	Security Fixes.
		N/A
	Bug Fixes.
		1862909  	  Category incorrect after category renamed
	Added Features / Changes.
		Previous articles not showing when home page is list type article
		Adjusted static page submission script [save_form() function]
	Changed files.
		./admin/edit_sitemap.php
		./includes/build_list_content.php
		./includes/build_normal_content.php
		./templates/deeemm/admin/admin_mod_static_content.tpl
		./templates/dmcms/admin/admin_mod_static_content.tpl

0.7.1 (BETA) 02/01/2008
	Security Fixes.
		1849905     DMCMS Index.PHP SQL Injection Vulnerability
	Bug Fixes.
		1810461  	  RSS Feed doesn't like spaces in title
		1757976  	  File Upload Function Bug
		1747487  	  Initial DB load from backup fails to CREATE deeemm_structure
	Added Features / Changes.
		Accumulated bug fixes
	Changed files.
		./index.php
		./includes/build_list_content.php
		./includes/build_media_content.php
		./templates/deeemm/list_index.tpl

0.7.0 (BETA) 05/06/2007
	Security Fixes.
		N/A
	Bug Fixes.
		1757976  	  File Upload Function Bug
		1726782			Right column displaying incorrectly in IE
		1726756			Floating editor windows in IE
		1729221			IE Textbox focus problem
		1730226			IE6 Drop Down Menus
		1729858			links display incorrect in list type page
		1730752  	  IE6 PNG transparency problem
		1730750  	  IE6 Button Hover
		1731224  	  Thumbnail layout not symmetrical
		1731226  	  Translate button does not work
		1726758  	  Floating editor not updating
	Added Features / Changes.
		1726802  	  Database restore from file
		Improved media image deletion handling
		Removed inline style elements
		Uploaded filenames now converted to lower case
		Added database restore from file
		Improved database restore file handling.
		Improved user handling
	Changed files.
		.GIF style template icons added
		*.* (All files changed)

		0.6.4 (BETA) 17/05/2007
	Security Fixes.
		Fixed security flaw 'File Upload Vulnerability' in includes/upload_file.php
		as reported on - http://nvd.nist.gov/nvd.cfm?cvename=CVE-2007-2214
	Bug Fixes.
		Spaces in categories (SQL table names) now allowed
		Gallery image edit bug fixed
		Top level link on navigation broken if link was 'link' type
		Removed strip slashes on replace vars function
		IE6 Menu dropdowns fixed (broken javascript)
		phpBB plugin drop downs also fixed
		hit counter session
	Added Features.
		User management
		Galery image check when deleeting image - now checks if image used elsewhere
		Gallery image check when adding image - renames image if name already exists
		Dotted underline in links added for DeeEmm template for better readability
	Changed files.
		/admin/delete_item.php - Stopped reorder of id's to allow permanent links
		/admin/edit_users.php - renamed to user_mod.php - user moderation control
		/admin/edit_sitemap.php - user comment control (Not functioning yet)
		/admin/edit_media.php - Image edit bug
		/admin/save_link.php - SQL bug
		/admin/db_backup.php - Bugfix - spaces in table names
		/admin/delete_item.php - Check image not used before deleting
		/includes/recursive_content.php - Added dotted underline on links
		/includes/build_sitemap.php - user comment control / link url bugfix / added link for category link add
		/includes/build_navigation.php - link url bugfix
		/includes/build_media_content.php - modded code to ignore non sequential id's / $file_id_array initialisation bugfix
		/includes/upload_file.php - security fix - 'File Upload Vulnerability'
		/index.php - user mod control
		/site_status.php - Bugfix - hitcounter session changed to cookie
		/java.js - renamed to functions.js
		/admin_functions.js - new file
		/functions.php - Bugfix - Removed stripslahes on replace vars function
		/language/english.php - added language fields / Bugfix - DMCMS footer link
		/templates/deeemm/css/nav_h.css - fixed IE dropdown bug
		/templates/deeemm/css/default.css - Added dotted underline on links
		/templates/deeemm/recursive_content.tpl - Added dotted underline on links
		/templates/deeemm/list_article.tpl - Added dotted underline on links
		/templates/deeemm/list_index.tpl - Added dotted underline on links
		/templates/deeemm/header.tpl - added admin javascript link / Bugfix - IE6 menu dropdowns
		/templates/deeemm/banner.tpl - Bugfix - phpBB plugin mod dropdowns
		/templates/deeemm/admin/admin_mod_settings.tpl changed reference to user_mod.php
		/templates/deeemm/admin/admin_mod_users.tpl - add / delete user control
		/templates/deeemm/admin/admin_mod_sitemap.tpl - user comment control

0.6.3 (BETA) 27/02/2007
	Bug Fixes.
		database restore function fixed
		php parse error when saving link type page fixed
		automated database update - update file checks added
		sitemap category editor not propogating contents
	Added Features.
		Improved automated database update function (for DMCMS upgrades)
		Added ability to remove pages from navigation structure
	Changed files.
		admin/db_backup.php - moved each statement onto its own line.
		admin/db_restore.php - split files by newline instead of terminator.
		admin/save_link.php - error in syntax.
		admin/edit_settings.php - changed auto update for database
		language/english.php
		includes/build_sitemap.php - added 'not in sitemap' function
		admin/edit_sitemap.php - added 'not in sitemap' function
		includes/build_navigation.php - prevented pages 'not in sitemap' displaying
		templates/dmcms/admin_mod_sitemap.tpl - added 'not in sitemap' function
		templates/dmcms/sitemap.tpl - added 'not in sitemap' function
		templates/deeemm/admin_mod_sitemap.tpl - added pages not in sitemap function
		templates/deeemm/sitemap.tpl - added 'not in sitemap' function
		templates/dmcms/images/icons/normal.png - icon modified
		templates/dmcms/images/icons/page.png - icon added
		templates/deeemm/images/icons/normal.png - icon modified
		templates/deeemm/images/icons/page.png - icon added

0.6.2 (BETA) 25/02/2007
	Bug Fixes.
		Navigation menu appearing under flash slide show.
		Newsbox link incorrect.
		Fixed database backup (output format was incorrect).
		Category info type wasn't being displayed when editing.
	Added Features.
		Added ability to be able to add links into navigation structure.
		Button hover colour for DeeEmm template.
		Individual RSS feeds for each list type page.
		Database backup and restore functions.
		Update file for database update (not tested - use at your own risk).

0.6.1 (BETA) 14/02/2007
	Bug Fixes.
		Prevented 'Orphan' from displaying in breadcrumb when viewing orphan pages.
		Fixed 'edit link not working on homepage' problem (Bug 1659313).
	Added Features.
		Added template selection feature to admin interface.
		Additional template added (dmcms) - features revised buttons and colours.
		Login link enable / disable added to admin interface.
		Database editor path added to admin interface.
		Index.htm pages added to subfolders to prevent browsing content.

0.6.0 (BETA) 13/02/2007 Initial version
		First available release on sourceforge.

==[Installation]================================================================
#	As this is a beta version it is largely aimed at programmers and webmasters,
	The installation process is not too hard but it does require manually
	modifying the config file and manually updating your database. This is
	probably how it will remain for the beta versions as all of my time is
	currently being spent on getting the bugs ironed out ready for release
	candidate 1.
# If you already have DMCMS 0.6.X upwards installed, you will simply need to
	perform an update. You will need to upload the new files to you webspace and
	then update the database. To do this, you can try the automated database
	update tool	- After you have uploaded the files, simply go to the admin page
	and click on the update button. Please note that the update function has not
	been extensively tested so there are no guarantees that it will work 100%.
# To install DMCMS, first download the latest version from the DMCMS SourceForge
	project homepage at http://sourceforge.net/projects/dmcms/
# If you need to create a database, now is that time to do it. Most Web Space
	Providers either provide you with a database automatically (you will need to
	find out the name of the database and the username and password needed to
	access it), or they will allow you to create one through your web space admin
	control panel (Don't forget to write down the details!).
# Unzip or untar the contents to your local hard drive.
# Now you will need to upload / merge the DMCMS SQL data into your database	To
	do this you will need to use a database client like phpMyAdmin, or whatever
	client is provided by your WSP. Add / merge the info from the SQL backup that
	is in the db_backups folder of the files that you have just unzipped. Don't
	forget to back up any data you already have in the database before making any
	changes.
# Open 'config.php' in your favourite text editor, you will find this in the
	root directory of the files you have just unzipped. (notepad or gedit will do
	fine) and then look for the following lines:

	$default_url = 'http://www.yoursite.com/';
	(Change this to the default url of your site - remember the trailing slash)

	$db_username = 'DeeEmm';
	(Change this to your database username)

	$db_password = 'DeeEmm';
	(Change this to the password of the above user)

	$db_name = 'DMCMS';
	(Change this to the name of your database)

# Change the above details to reflect those of your website + database - these
	details may be supplied by your web space provider.
# Now transfer the files to your web space - copy them to the folder that will be
	seen by visitors to your site - usually called 'www' or 'public_html'.
# Now open your website URL in your favourite browser and you should see your
	new website!!
# Navigate to the F.A.Q. section to find out how to use DMCMS.
# To log in as Administrator you will need to use the following username and
	password:

	Username - Admin
	Password - DeeEmm

	Please remember the username and password are case sensitive. It is a good
	idea to change this - you can do this from the administration panel.

==============================================================================*/

