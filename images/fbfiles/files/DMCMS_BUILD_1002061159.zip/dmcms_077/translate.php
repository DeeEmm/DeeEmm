<?php

if (!isset($INDM)) {echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html><head><meta http-equiv="content-type" content="text/html; charset=iso-8859-1"><meta name="Content-Language" content="en"><meta name="description" content="DMCMS"><meta name="author" content="Mick Percy"><meta name="copyright" content="Copyright 2007 DeeEmm"><title>DMCMS</title></HEAD><body><br><br><br><br><br><br><br><br><center><img src="http://www.deeemm.com/images/logo.gif" alt="DMCMS"><br><a href="http://www.deeemm.com"><span style="font-weight:bold">http://www.deeemm.com</span></a></center></body></html>'; exit;}

//===========================================================================

//===========================================================================
//>translate text
//===========================================================================

	//can also use following url directly
	//http://ets.freetranslation.com?language=english/German&sequence=core&srctext=translate

	//language elements
	//English/Spanish
	//English/French
	//English/German
	//English/Italian
	//English/Portuguese
	//English/Norwegian
	//Spanish/English
	//French/English
	//German/English
	//Italian/English
	//Portuguese/English

	$lang_pair = $_GET["lang_pair"];
	$text = $_GET["text"];
  $html_file=fopen("http://translate.google.com/translate_t?lang_pair=$lang_pair&text=$text","r");
  if(!$html_file){
    echo 'The translation server is not responding at the moment - Please try later.';
		exit;
  }
  while(!feof($html_file)){
    $decoded_html.= fgets($html_file);
  }
  fclose($html_file);

//===========================================================================
//<get data from the string
//===========================================================================
	//set search strings
  $start = 'wrap=PHYSICAL>';
  $end = '</textarea>';

	//decode
	$start_position=strpos($decoded_html, $start)+strlen($start);
	$end_position=strpos($decoded_html, $end);
	$length=$end_position-$start_position;
	//get text from string
	$translation=substr($decoded_html, $start_position, $length);
	//return $translation;
	echo $translation;

?>