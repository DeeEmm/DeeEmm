<?php

if (!isset($INDM)) {echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html><head><meta http-equiv="content-type" content="text/html; charset=iso-8859-1"><meta name="Content-Language" content="en"><meta name="description" content="DMCMS"><meta name="author" content="Mick Percy"><meta name="copyright" content="Copyright 2007 DeeEmm"><title>DMCMS</title></HEAD><body><br><br><br><br><br><br><br><br><center><img src="http://www.deeemm.com/images/logo.gif" alt="DMCMS"><br><a href="http://www.deeemm.com"><span style="font-weight:bold">http://www.deeemm.com</span></a></center></body></html>'; exit;}

//===========================================================================

$new_version = '0.6.3 (BETA)';

/*===========================================================================
//>update version number
===========================================================================*/
mysql_query("UPDATE `" . $db_table_prefix . "admin` SET `version` = '$new_version' WHERE `id` = 0") OR DIE ("<b>A fatal MySQL error occured</b>.\n<br />Query: " . $sql_query . "<br />\nError: (" . mysql_errno() . ") " . mysql_error());
echo $version . ' -> ' . $new_version . ' Update<br><br>';    


/*===========================================================================
//>update control tables in database
===========================================================================*/
mysql_query("ALTER TABLE `" . $db_table_prefix . "structure` ADD `display_in_sitemap` varchar(10) NOT NULL AFTER `display_in_margin`") OR DIE ("<b>A fatal MySQL error occured</b>.\n<br />Query: " . $sql_query . "<br />\nError: (" . mysql_errno() . ") " . mysql_error());

/*===========================================================================
//>update non control (content) tables in database
===========================================================================*/
//No changes

?>