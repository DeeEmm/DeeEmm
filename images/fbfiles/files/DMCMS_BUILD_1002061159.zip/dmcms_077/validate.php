<?php

if (!isset($INDM)) {echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html><head><meta http-equiv="content-type" content="text/html; charset=iso-8859-1"><meta name="Content-Language" content="en"><meta name="description" content="DMCMS"><meta name="author" content="Mick Percy"><meta name="copyright" content="Copyright 2007 DeeEmm"><title>DMCMS</title></HEAD><body><br><br><br><br><br><br><br><br><center><img src="http://www.deeemm.com/images/logo.gif" alt="DMCMS"><br><a href="http://www.deeemm.com"><span style="font-weight:bold">http://www.deeemm.com</span></a></center></body></html>'; exit;}

//===========================================================================


 
//===========================================================================
//>validate users
//===========================================================================

$logged_in = false;

//get variables passed from login form
$username = $_GET["username"];
$password = $_GET["password"];


if(!isset($_COOKIE["deeemm"])) {

	//no cookie so reset cookie just in case
 	setcookie ("deeemm", "", time() - 3600);

} elseif (isset($_COOKIE["deeemm"])) {

 	//get data from cookie
  $user = explode(" ",$_COOKIE["deeemm"]);

	//compare data against database
  $sql_query = "SELECT * FROM `" . $db_table_prefix . "users` WHERE `user_name` = '$user[0]'";
  $result = mysql_db_query($db_name, $sql_query);

  if(!mysql_num_rows($result)) {
  	//user not in database so reset cookie
  	setcookie ("deeemm", "", time() - 3600);
    $user = '';
  } ELSE {

    //compare cookie against database info
	  $chkusr = mysql_fetch_array($result);

	  if(unserialize(base64_decode($user[1])) != $chkusr[1]) {

	  	//password does not match database so reset cookie
	  	setcookie ("deeemm", "", time() - 3600);
	    $user = '';
		} else {

			//password matches database so get user level
		  $sql_query = "SELECT * FROM `" . $db_table_prefix . "users` WHERE `user_name` = '$user[0]'";
	  	$result = mysql_fetch_array(mysql_db_query($db_name, $sql_query));
			$user = $result[user_level];
			$logged_in = true;

      //get other userdata
			$username = $result[user_name];
			$password = $result[password];
			$nickname = $result[nick_name];
			$user_rank = $result[user_rank];
			$is_active = $result[is_active];
			$bio = $result[bio];
			$signature = $result[signature];
		}
	}
}
?>