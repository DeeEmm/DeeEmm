<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

//===========================================================================

//===========================================================================
//>check user priviledges
//===========================================================================
require VALIDATE;

//if ($user=='USER' || $user=='ADMIN'){
if ($user=='ADMIN'){

	switch ($action) {

		case 'edit_profile';
		$content = "templates/edit_profile.tpl";
		$main = read_file($content);
		break;

		case 'save_profile';

		//>get data from form
		$password_old = mysql_escape_string(stripslashes($_REQUEST['password_old']));
		$password_1 = mysql_escape_string(stripslashes($_REQUEST['password_1']));
		$password_2 = mysql_escape_string(stripslashes($_REQUEST['password_2']));


		//>if password fields set - change password
		if ($password_old != '' || $password_1 != '' || $password_2 != '') {
			if ((md5($password_old) == $password) && ($password_1 == $password_2)) {
				$password_new = md5($password_1);
				mysql_query("UPDATE " . $db_table_prefix . "users SET `password` = '$password_new' WHERE `user_name` = '$username'");
				$status_message = $lan[password_changed];
			} else {
				$status_message = $lan[password_not_changed];
			}
		}
		break;

	}

}
//>get profile info and propogate form

$content = "templates/edit_profile.tpl";
$main = read_file($content);

$main = replace_variables($main);

?>
