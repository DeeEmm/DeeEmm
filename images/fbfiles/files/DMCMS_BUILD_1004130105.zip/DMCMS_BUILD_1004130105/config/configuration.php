<?php

// no direct access
defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Change the details below to get your site up and running
===========================================================================*/

// 1. Change this to the default url of your site!
$default_url 		= 'http://localhost/dmcms_077/'; 

// 2. Change this to your database username
$db_username 		= 'DeeEmm'; 

// 3. Change this to the password of the above user
$db_password 		= 'DeeEmm'; 

// 4. Change this to the name of your database
$db_name 			= 'dmcms_077'; 

// 5. Change this to the IP address of your SQL server if different from your webserver
$db_server 			= 'localhost'; 

/*===========================================================================
Miscellaneous settings - change these to suit your site

NB - revise for SEO - should be set on per page basis!!
===========================================================================*/
$author 			= 'Mick Percy';
$meta_keywords 		= 'DeeEmm CMS, DMCMS, Open Source Content Management Software';
$header_copyright 	= "Copyright " . date ("Y") . " DMCMS";

/*===========================================================================
Setup the envoironment
===========================================================================*/
$absolute_path 		= '\home\dmv\public_html\\';
$templates_dir 		= 'templates/';
$stylesheet 		= 'default.css';
$media_dir 			= 'media/';
$admin_dir 			= 'admin/';
$db_backup_dir 		= 'db_backups/';
$core_dir 			= 'core/';
$includes_dir 		= 'includes/';
$updates_dir 		= 'updates/';
$language_dir 		= 'language/';

define('INITIALISATIONS', $rel_path . $config_dir . 'initialisations.php');
define('DEFINITIONS', $rel_path . $config_dir . 'definitions.php');
define('FUNCTIONS', $rel_path . $core_dir . 'functions.php');
define('DB_ACCESS', $rel_path . $core_dir . 'db_access.php');
define('SITE_STATUS', $rel_path . $core_dir . 'site_status.php');
define('STATIC_CONTENT', $rel_path . $includes_dir . 'static_content.php');
define('VALIDATE', $rel_path . $core_dir . 'validate.php');
define('LANGUAGE', $rel_path . $core_dir . 'language.php');

/*$initialise			= $rel_path . $config_dir . 'initialise.php';
$config 			= $rel_path . $config_dir . 'define.php';
$functions 			= $rel_path . $core_dir . 'functions.php';
$db_access 			= $rel_path . $core_dir . 'db_access.php';
$site_status		= $rel_path . $core_dir . 'site_status.php';
$get_static_content = $rel_path . $includes_dir . 'get_static_content.php';*/

/*===========================================================================
It is not reccomended to change the following line as the auto update will not work
===========================================================================*/
$db_table_prefix 	= 'deeemm_';

?>
