<?php
defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

//===========================================================================
$short_date = date ("F j Y");
$year = date ("Y");
$long_date = date ("F j Y - g:i:s");
$long_time = date ("g:i:s");
$short_time = date ("g:i");
$crlf = "\r\n";
$lf = "\n";
$nav_seperator = " :: ";
//===========================================================================
$main = '';
$page_title = '';
$cookie_trial = '';
$hidden_header = '';
$list_item_href = '';
$return_link = '';
$news_article_edit = '';
$list_article_edit = '';
$list_index_edit = '';
$media_library_index_edit = '';
$media_library_image_edit = '';
$media_href = '';
$admin_nav = '';
$h_nav_menu = '';
$v_nav_menu = '';

//===========================================================================

?>