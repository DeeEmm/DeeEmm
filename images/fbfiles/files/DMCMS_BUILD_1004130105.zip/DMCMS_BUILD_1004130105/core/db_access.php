<?php
defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );


//===========================================================================
//connect to server
//===========================================================================
$db_connection = mysql_connect($db_server,  $db_username,  $db_password) or die("Database Error: Could not connect to MySQL:" . mysql_error());
//===========================================================================
//select database
//===========================================================================
mysql_select_db($db_name) or die("Database Error: " . mysql_error());

?>