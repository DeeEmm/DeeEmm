<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

//===========================================================================

$value = NULL;
// add check for imagebox_libraries
if ($imagebox_libraries){ // need to check what happens if none set!!!!!!!!!!!

	foreach ($imagebox_libraries as $value){
		//get number of images in media library
		$sql_result = mysql_query("select count(*) from `" . $db_table_prefix . "$value`");
		$num_media_files = mysql_result($sql_result,0);

		$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "structure` WHERE `table` = '$value'");
		while($sql_result = mysql_fetch_array($sql_query)){
			$media_library_enabled = $sql_result[media_library_enabled];
			$media_library_default_view = $sql_result[media_library_default_view];
			$num_slideshow_images = $sql_result[num_slideshow_images];
			$imagebox_type = $sql_result[imagebox_type];
		}
		//		breakpoint($imagebox_type);
		if ($num_media_files <> 0) {

			switch ($imagebox_type) {

				case 'random';
				$content = $default_path . $templates_dir  . "imagebox_random.tpl";
				$imagebox .= read_file($content);

				//get random image id
				$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "$value` WHERE `image` NOT LIKE '%mpg' AND `image` NOT LIKE '%pdf' AND `image` NOT LIKE '%mov' AND `image` NOT LIKE '%zip' AND `image` NOT LIKE '%txt' ORDER BY RAND()");
				while($sql_result = mysql_fetch_array($sql_query)) {
					$random_image_name = $sql_result[image];
					$random_image_title = $sql_result[title_lan_ . $language];
					$random_image_description = $sql_result[description_lan_ . $language];
					$random_image_num = $sql_result[id];
				}
				if ($random_image_name == ''){
					$random_image_name = 'image_unavailable.jpg';
				}

				break;

				case 'slideshow';
				$content = $default_path . $templates_dir  . "imagebox_slideshow.tpl";
				$imagebox .= read_file($content);
				break;

			}//end switch
				
		} ELSE {
			//do nothing
		}

		$imagebox = replace_variables($imagebox);
	}//end for each
}//end if imagebox_libraries

$value = NULL;


?>