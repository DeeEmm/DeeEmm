<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

//===========================================================================

//>get title
$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "structure` WHERE `table` = '$page'");
while ($sql_result = mysql_fetch_array($sql_query)){
	$list_page_title = $sql_result[category_lan_ . $language];
}

if (htmlspecialchars($_GET["id"], ENT_QUOTES) <> '' && $action !== 'edit' && $action !=='show_index'){

	//read template data
	$content = $default_path . $templates_dir  . "list_article.tpl";
	$main = read_file($content);

	//get article info from database
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "$page` WHERE `id` = '$id'");
	while($sql_result = mysql_fetch_array($sql_query)){
		$main = str_replace('[var]article_image[/var]', $article_image, $main);
		$main = str_replace('[var]article_date[/var]', strftime("%a %d %b %y", strtotime($sql_result[1])), $main);
		$main = str_replace('[var]article_image[/var]', $article_image, $main);
		$main = str_replace('[var]article_title[/var]', $sql_result[title_lan_ . $language], $main);
		$main = str_replace('[var]article_text[/var]', $sql_result[description_lan_ . $language], $main);
	}

} else {
	$content = $default_path . $templates_dir . "list_index.tpl";
	$main .= read_file($content);

	$first_article = true;
	$content = $default_path . $templates_dir . "list_index_item.tpl";
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . $page . "` ORDER BY `date` DESC");
	while($sql_result = @mysql_fetch_array($sql_query)){

  //>get latest article (first article)
  if ($first_article) {
  	$list_content_main_article .= read_file($content);
  	$tool_tip = $sql_result[tool_tip_lan_ . $language];
  	$article_text = $sql_result[description_lan_ . $language];
  	//replace template markers with data from database
  	$list_content_main_article = str_replace('[var]article_href[/var]', $list_item_href, $list_content_main_article);
  	$list_content_main_article = str_replace('[var]article_title[/var]', $sql_result[title_lan_ . $language], $list_content_main_article);
  	//show first item in entirety
  	$list_content_main_article = str_replace('[var]article_text[/var]', $article_text, $list_content_main_article);
  	$list_content_main_article = str_replace('[var]article_date[/var]', strftime("%A %d %B %Y", strtotime($sql_result[1])), $list_content_main_article);
  }

  //>get previous articles
  if (!$first_article) {
  	$list_index_previous_articles .= read_file($content);
  	$tool_tip = $sql_result[tool_tip_lan_ . $language];
  	$list_item_href = '<A class="list_index_item" title="' . $tool_tip . '" href="' .$default_path .'index.php?page=' . $page . '&amp;id=' . $sql_result[id] . '">';
  	$article_text = $sql_result[description_lan_ . $language];
  	//$article_text = preg_replace('/\n|\r|\n\r/','<BR>',$article_text); //convert crlf to <BR>
  	//replace template markers with data from database
  	$list_index_previous_articles = str_replace('[var]article_href[/var]', $list_item_href, $list_index_previous_articles);
  	$list_index_previous_articles = str_replace('[var]article_title[/var]', $sql_result[title_lan_ . $language], $list_index_previous_articles);
  	//this line for titles only
  	$list_index_previous_articles = str_replace('[var]article_text[/var]', '', $list_index_previous_articles);
  	//this line for truncated article text as well
  	//$list_index_previous_articles = str_replace('[var]article_text[/var]', balanceTags(truncate($article_text, 260)), $list_index_previous_articles);
  	$list_index_previous_articles = str_replace('[var]article_date[/var]', strftime("%A %d %B %Y", strtotime($sql_result[1])), $list_index_previous_articles);
  	if (!$article_text) {
  		$previous_articles = '';
  	} else {
  		$previous_articles = $lan[previous_articles];
  	}
  }

  $first_article = false;

	}// end while

	if($err=mysql_errno())return $err;

}

?>