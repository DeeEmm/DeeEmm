<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

//===========================================================================


//===========================================================================
//>create recursive pages
//===========================================================================

$content = $default_path . $templates_dir  . "recursive_content.tpl";
$main = read_file($content);

if (!isset($id) || $id == ''){
	//display parent page

	//replace admin link template marker if admin
	$admin_href = $empty_normal_page_admin_href;

	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . $page . "` ORDER BY `date` DESC LIMIT 1");
	while($sql_result = @mysql_fetch_array($sql_query)){
		$id = $sql_result[id];
	}

} if(!$action) {

	//replace admin link template marker if admin
	$admin_href = $normal_page_admin_href;
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . $page . "` WHERE `id` = '$id'");

	//get data from database
	while($sql_result = mysql_fetch_array($sql_query)){
		$category = $sql_result[category];
		$title = $sql_result[title_lan_ . $language];
		$tool_tip = $sql_result[tool_tip_lan_ . $language];
		$article_text = $sql_result[description_lan_ . $language];
	}

	//replace template markers with data from database
	$main = str_replace('[var]list_item_href[/var]', $list_item_href, $main);
	$main = str_replace('[var]title[/var]', $title, $main);
	$main = str_replace('[var]list_body[/var]', $article_text, $main);

	$cookie_trial .= $cookie_trial_seperator . $title;
	$page_title .= $cookie_trial_seperator . $title;

	$list_item_href = "<STRONG><A HREF='$default_path"."index.php?page=$page&amp;id=$sql_result[id]'>";

}


?>