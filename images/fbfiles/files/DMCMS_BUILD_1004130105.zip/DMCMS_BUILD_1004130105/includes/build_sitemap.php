<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

//===========================================================================

$content = $default_path . $templates_dir  . "sitemap.tpl";
$main = read_file($content);

/*===========================================================================
 //>propogate the site map
 ===========================================================================*/
//generate list with links for modifying category
foreach($all_tables as $value){
	$tables_list = '';
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "structure` WHERE `table` = '$value'");
	while($sql_result = mysql_fetch_array($sql_query)){
		$type = $sql_result[type];
		$media_library_default_view = $sql_result[media_library_default_view];
		$num_slideshow_images = $sql_result[num_slideshow_images];
		$imagebox_type = $sql_result[imagebox_type];
		$display_in_margin = $sql_result[display_in_margin];
		$display_in_sitemap = $sql_result[display_in_sitemap];
		$allow_comments = $sql_result[allow_comments];
		$category = $sql_result[category_lan_ . $language];
	}

	//>get highest order page
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "$value` WHERE `id` > 0 ORDER BY `order` LIMIT 1");
	if($sql_result = mysql_fetch_array($sql_query)){
		$id = $sql_result[id];
		$link_url = $sql_result[link_url];
	}

	//get main heading

	switch ($type) {

		case 'list';
		case 'normal';
		if (isset($link_url) && $link_url <> '') {
			$tables_list .= str_replace($value, "<HR size='1px' color='#ddd' class='clear_both'><img class='icon' title='$type' src='$default_url".$templates_dir."images/icons/$type.gif'>&nbsp&nbsp<a class='sitemap_item' href='" . $link_url . "'>" . $category . "</A>", $value);
		} else {
			$tables_list .= str_replace($value, "<HR size='1px' color='#ddd' class='clear_both'><img class='icon' title='$type' src='$default_url".$templates_dir."images/icons/$type.gif'>&nbsp&nbsp<a class='sitemap_item' href='$default_url"."index.php?page=" . $value . "'&amp;id=$id>" . $category . "</A>", $value);
		}
		break;

		case 'media';
		$tables_list .= str_replace($value, "<HR size='1px' color='#ddd' class='clear_both'><img class='icon' title='$type' src='$default_url".$templates_dir."images/icons/$type.gif'>&nbsp&nbsp<a class='sitemap_item' href='$default_url"."index.php?page=" . $value . "'>" . $category . "</A>", $value);
		break;
	}


	//get sub heading
	$sql_query  = mysql_query("SELECT * FROM `" . $db_table_prefix . "$value` ORDER BY `order`");
	while ($sql_result = mysql_fetch_array($sql_query)){
		$title = $sql_result[title_lan_ . $language];
		$id = $sql_result[id];
		$link_url = $sql_result[link_url];

		if ($type == 'normal'){
			$tables_list .= str_replace($value, "<ul><img class='icon' title='$type' src='$default_url".$templates_dir."images/icons/page.gif'>&nbsp;&nbsp;<a class='sitemap_item' href='$default_url"."index.php?page=" . $value . "&amp;id=$id'>" . $title . "</A></span></ul>", $value);
		}
	}
	$tables_list = str_replace('  ', '', $tables_list);
	if (isset($display_in_sitemap) && $display_in_sitemap <> ''){
		$sitemap_list .= $tables_list;
	} else {
		$non_sitemap_list .= $tables_list;
	}
}
//>add forum link if enabled
if ($forum_enabled == true) {
	$sitemap_list .= "<HR size='1px' color='#ddd' class='clear_both'><img class='icon' title='" . $lan[forum] . "' src='$default_url".$templates_dir."images/icons/page.gif'>&nbsp;&nbsp;<A href='" . $forum_path . "' title='" . $lan[forum] . "'>$forum_name</a>	";
}

$sitemap_editor = replace_variables($sitemap_editor);


?>


























































