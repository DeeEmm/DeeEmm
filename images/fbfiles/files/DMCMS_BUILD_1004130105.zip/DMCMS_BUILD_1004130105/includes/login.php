<?php
defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );


if($username && $password) {
	$password = md5($password);
	$sql = "SELECT * FROM `" . $db_table_prefix . "users` WHERE `user_name` = '$username'";
	$result = mysql_db_query($db_name,$sql);
	if(!mysql_num_rows($result))
	header("Location: index.php?page=login");
	$user = mysql_fetch_array($result);
	if($user["password"] == $password) {
		$password = base64_encode(serialize($password));
		setcookie("deeemm","$username $password");
		$msg = "<meta http-equiv=\"Refresh\" content=\"0;url=index.php\">";
	}else{
		header("Location: index.php?page=login");
	}
}
if($msg) echo $msg;

$content = $default_path . $templates_dir  . "login.tpl";
$main = read_file($content);
?>