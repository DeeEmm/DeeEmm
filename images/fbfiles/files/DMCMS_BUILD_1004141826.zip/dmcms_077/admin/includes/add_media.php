<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );


/*===========================================================================
Check user priviledges
===========================================================================*/
require VALIDATE;

if ($user != 'ADMIN') header("Location: " . $default_path . "index.php");

$content = "templates/admin_mod_media.tpl";
$main = read_file($content);


/*===========================================================================
If $id is not set -  new file is being added
===========================================================================*/
if (!isset($id) || $id == ''){
	$admin_title = $lan[add_media];

	//propogate media category drop down list
	$media_library_list = "<select style=\"width:71%; float:right\" name='parent'>";
	foreach($media_tables as $value){
		if ($value == $page){
			$value = str_replace($value, "<option selected value='$value'>$value</option>", $value);
			$media_library_list .= $value;
		} else {
			$value = str_replace($value, "<option>$value</option>", $value);
			$media_library_list .= $value;
		}
	}
	$media_library_list = str_replace('  ', '', $media_library_list);
	$media_library_list .= '</select>';

	$media_category_list = "<select name=\"category\" onChange=\"this.form.selected_category.value = this.options[this.selectedIndex].text\"	style=\"position:absolute;z-index:1;width:190px;clip:rect(0px,190px, 22px, 80px)\"><option selected value='$category'>$category</option>";
	foreach($media_categories as $value){
		//propogate category type option list
		if ($value != $category) {
			$media_category_list .= "<option>$value</option>";
		}
	}
	$media_category_list = str_replace('  ', '', $media_category_list);
	$media_category_list .= '</select>';


	$article_ref = "index.php?page=admin";
}

?>
