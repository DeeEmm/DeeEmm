<<<<<<< db_backup.php
<?php
defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

//===================================================================================================
//check user level is admin
//===================================================================================================
if ($user_level != 'ADMIN') header("Location: " . $default_path . "index.php");

require $core_dir . 'db_access.php';

//===================================================================================================
//get table definition
//===================================================================================================
function get_table_def($table, $crlf,$db_name) {
	$schema_create = "DROP TABLE IF EXISTS `$table`;$crlf";
	$db = $table;
	$schema_create .= "CREATE TABLE `$table` (";
	$result = mysql_query("SHOW FIELDS FROM `" .$db_name."`.`" . $table."`");
	while($row = mysql_fetch_array($result))	{
echo ".";
		$schema_create .= "   `$row[Field]` $row[Type]";
		if(isset($row["Default"]) && (!empty($row["Default"]) || $row["Default"] == "0"))	$schema_create .= " DEFAULT '$row[Default]'";
		if($row["Null"] != "YES") $schema_create .= " NOT NULL";
		if($row["Extra"] != "")	{
			$schema_create .= " $row[Extra]";
		}
		$schema_create .= ",";
	}
	$schema_create = ereg_replace(",".$crlf."$", "", $schema_create);
	$result = mysql_query("SHOW KEYS FROM `" .$db_name."`.`" .	$table."`") or die(" error!");
	while($row = mysql_fetch_array($result))	{
echo ">";	
		$kname=$row['Key_name'];
		$comment=(isset($row['Comment'])) ? $row['Comment'] : '';
		$sub_part=(isset($row['Sub_part'])) ? $row['Sub_part'] : '';
		if(($kname != "PRIMARY") && ($row['Non_unique'] == 0)) $kname="UNIQUE|$kname";
		if($comment=="FULLTEXT")$kname="FULLTEXT|$kname";
		if(!isset($index[$kname])) $index[$kname] = array();
		if ($sub_part>1){
			$index[$kname][] = $row['Column_name'] . "(" . $sub_part . ")";
		} else {
			$index[$kname][] = $row['Column_name'];
		}
	}
	while(list($x, $columns) = @each($index)) {
		$schema_create .= ",";
		if($x == "PRIMARY")
		$schema_create .= "   PRIMARY KEY (`";
		elseif (substr($x,0,6) == "UNIQUE")
		$schema_create .= "   UNIQUE `" .substr($x,7)."` (`";
		elseif (substr($x,0,8) == "FULLTEXT")
		$schema_create .= "   FULLTEXT `".substr($x,9)."` (`";
		else
		$schema_create .= "   KEY $x (`";

		$schema_create .= implode($columns,", ") . "`)";
	}
	$schema_create .= ")";
	$schema_create = str_replace(',,', ',', $schema_create);//bad bugfix 050407
	$schema_create = str_replace(',)', ')', $schema_create);//bad bugfix 050407
	if(get_magic_quotes_gpc()) {
		return (stripslashes($schema_create));
	} else {
		return ($schema_create);
	}
}

//===================================================================================================
//get table content
//===================================================================================================
function get_table_content($db, $table, $limit_from = 0, $limit_to = 0,$handler) {
	// Defines the offsets to use
	if ($limit_from > 0) {
		$limit_from--;
	} else {
		$limit_from = 0;
	}
	if ($limit_to > 0 && $limit_from >= 0) {
		$add_query  = " LIMIT $limit_from, $limit_to";
	} else {
		$add_query  = '';
	}
	get_table_content_fast($db, $table, $add_query,$handler);
}

//===========================================================================
//get table
//===========================================================================
function get_table_content_fast($db, $table, $add_query = '',$handler) {
	$result = mysql_query('SELECT * FROM `' . $db . '`.`' . $table . "`" . $add_query) or die();
	if ($result != false) {
		@set_time_limit(1200); // 20 Minutes
		// Checks whether the field is an integer or not
		for ($j = 0; $j < mysql_num_fields($result); $j++) {
			$field_set[$j] = mysql_field_name($result, $j);
			$type          = mysql_field_type($result, $j);
			if ($type == 'tinyint' || $type == 'smallint' || $type == 'mediumint' || $type == 'int' || $type == 'bigint'  ||$type == 'timestamp') {
				$field_num[$j] = true;
			} else {
				$field_num[$j] = false;
			}
		} // end for
		// Get the scheme
		if (isset($GLOBALS['showcolumns'])) {
			$fields        = implode(', ', $field_set);
			$schema_insert = "INSERT INTO `$table` ($fields) VALUES (";
		} else {
			$schema_insert = "INSERT INTO `$table` VALUES (";
		}
		$field_count = mysql_num_fields($result);
		$search  = array("\x0a","\x0d","\x1a"); //\x08\\x09, not required
		$replace = array("\\n","\\r","\Z");
		while ($row = mysql_fetch_row($result)) {
			for ($j = 0; $j < $field_count; $j++) {
				if (!isset($row[$j])) {
					$values[]     = 'NULL';
				} else if (!empty($row[$j])) {
					// a number
					if ($field_num[$j]) {
						$values[] = $row[$j];
						// a string
					} else {
						$values[] = "'" . str_replace($search, $replace, addslashes($row[$j])) . "'";
					}
				} else {
					$values[]     = "''";
				} // end if
			} // end for
			$insert_line = $schema_insert . implode(',', $values) . ')';
			unset($values);
			// Call the handler
			$handler($insert_line);
		} // end while
	} // end if ($result != false)
	return true;
}

//===========================================================================
//insert crlf
//===========================================================================
function my_handler($sql_insert) {
	global $crlf, $asfile;
	global $tmp_buffer;
	if(empty($asfile))
	$tmp_buffer.= htmlspecialchars("$sql_insert;$crlf");
	else
	$tmp_buffer.= "$sql_insert;$crlf";
}


//===========================================================================
//perform the backup
//===========================================================================
$asfile="download";
$crlf="\r\n";
$dump_buffer="";

if ($backup_dmcms_tables_only) {
	$tables = mysql_query("SHOW TABLES LIKE '" . $db_table_prefix . "%'");
} else {
	$tables = mysql_query("SHOW TABLES");
}

$num_tables = mysql_num_rows($tables);

if($num_tables == 0){
	echo "#No Tables Found on " . $db_name;
	exit;
}

$dump_buffer.= "#DMCMS Database Backup; $crlf";
$dump_buffer.= "#Backup made: " . date("F j, Y, g:i a").";$crlf";
$dump_buffer.= "#Database: $db_name;$crlf";
echo "Creating Backup for Database: $db_name;$crlf<br>";
$i = 0;
while($i < $num_tables)	{
	$table = mysql_tablename($tables, $i);
		echo "<br>Adding Table: " . $table . "<br>";
		$dump_buffer.= "$crlf";
		$dump_buffer.= "#Table structure for table '$table';$crlf";
		$dump_buffer.= "$crlf";
		$db = $table;
		$dump_buffer.= get_table_def($table, $crlf,$db_name).";$crlf";
		echo ">";
		$dump_buffer.= "$crlf";
		$dump_buffer.= "#Dumping data for table '$table';$crlf";
		$dump_buffer.= "$crlf";
		$tmp_buffer="";
		get_table_content($db_name, $table, 0, 0, 'my_handler', $db_name);
		$dump_buffer.=$tmp_buffer;
		$i++;
		$dump_buffer.= "$crlf";
	
}
 
//===================================================================================================
//perform backup - save to file or to db_backups directory
//===================================================================================================
$filename = $absolute_path . $db_backup_dir . date ("jMyHis") . '.sql';
if (!$db_save_to_file){
	//save database to db_backup directory
	global $absolute_path;
	global $db_backup_dir;
	write_file($filename, $dump_buffer);
} else {
	//save database to file
	@ob_start();
	@ob_implicit_flush(0);
	header('Content-Type: application/octetstream');
	header('Content-Disposition: attachment; filename="' . $filename . '"');
	echo $dump_buffer;
	exit;
}
//  	exit;

?>