<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Check user priviledges
===========================================================================*/
require VALIDATE;

if ($user != 'ADMIN') header("Location: " . $default_path . "index.php");

	//  $db_file = file_get_contents(strtolower(basename($_FILES['db_filename']['db_filename'])));
	//	breakpoint($db_file);
	$db_filename = $_REQUEST['db_filename'];
	if ($db_filename == 'select_file') {
		//selection not changed upload file if selected
		$db_filename = $_REQUEST['local_db_filename'];
		$new_filename = upload_file('db_backups/' . $db_filename, 'local_db');
		$db_file = read_file('db_backups/' . $new_filename);
	} else {
		$db_file = read_file('db_backups/' . $db_filename);
	}

	//split file line by line
	$db_file_array = preg_split('/\n/', $db_file);
	//check each line
	foreach($db_file_array as $value){
		//if it's not a comment or blank line execute sql statement
		if (preg_match("/^[^#\s ]/", $value)) mysql_query($value);
	}


?>