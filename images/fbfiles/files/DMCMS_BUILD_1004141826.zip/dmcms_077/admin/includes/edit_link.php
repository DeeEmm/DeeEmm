<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Check user priviledges
===========================================================================*/
require VALIDATE;

if ($user != 'ADMIN') header("Location: " . $default_path . "index.php");


$content = "templates/admin_mod_link.tpl";
$main = read_file($content);

//>create array of all categories in structure
for($count=1;$count<$num_tables+1;$count++){
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "structure` WHERE `id` = '$count'");
	while($sql_result = mysql_fetch_array($sql_query)){
		if ($sql_result[table] != $media_library) {
			$parents[] .= $sql_result[table];
		}
	}
}
//>if $id is set file must exist in database so get data
if (isset($id) && $id <> ''){
	$admin_title = 'Edit Link';
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . $page . "` WHERE `id` = '$id'");
	while($sql_result = mysql_fetch_array($sql_query)){
		$article_date = $sql_result[date];
		$article_date = strftime("%a %d %b  %Y", strtotime($article_date));
		$order = $sql_result[order];
		$parent = $sql_result[parent];
		$child = $sql_result[child];
		$category = $sql_result[category];
		$link_url = $sql_result[link_url];

		$title_lan_1 = $sql_result[title_lan_1];
		$title_lan_2 = $sql_result[title_lan_2];
		$title_lan_3 = $sql_result[title_lan_3];
		$title_lan_4 = $sql_result[title_lan_4];
		$tool_tip_lan_1 = $sql_result[tool_tip_lan_1];
		$tool_tip_lan_2 = $sql_result[tool_tip_lan_2];
		$tool_tip_lan_3 = $sql_result[tool_tip_lan_3];
		$tool_tip_lan_4 = $sql_result[tool_tip_lan_4];

	}
	$article_ref = "index.php?page=$page&id=$id";

} else {
	//>page doesn't exist so no need to get data
	$admin_title= 'Add Link';
	if ($page == 'admin') {
		$parent = $all_tables[0];
	} else {
		$parent = $page;
	}
	$article_ref = "index.php?page=admin";
}

//>propogate parent drop down list
$parent_array = str_replace($parent, '', $all_tables);
$parent_array = str_replace('orphan', '', $all_tables);
$parent_list = "<select style=\"width:71%; float:right\" name='parent'><option value='$parent' checked='true'>$parent</option>";
foreach($parent_array as $value){
	if ($value !== $media_library) {
		$value = str_replace($value, "<option value='$value'>$value</option>", $value);
		$parent_list .= $value;
	}
}
$parent_list = str_replace('  ', '', $parent_list);
$parent_list .= '</select>';


?>
