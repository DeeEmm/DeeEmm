<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Check user priviledges
===========================================================================*/
require VALIDATE;

if ($user != 'ADMIN') header("Location: " . $default_path . "index.php");

switch ($action) {

/*===========================================================================
Move up
===========================================================================*/
	case 'move_up_category';
	//get current order value
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "structure` WHERE `table` = '$category'");
	while($sql_result = mysql_fetch_array($sql_query)) {
		$current_order = $sql_result[order];
		$new_order = $current_order - 1;
	}
	//swap order value with adjacent category
	mysql_query("UPDATE `" . $db_table_prefix . "structure` SET `order` = '$current_order' WHERE `order` = '$new_order'");
	mysql_query("UPDATE `" . $db_table_prefix . "structure` SET `order` = '$new_order' WHERE `table` = '$category'");

	//reorder results to get rid of blank / ambiguous results
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "structure` ORDER BY `order`");
	while($sql_result = mysql_fetch_array($sql_query)){
		$old_order[].= $sql_result[order];
	}
	$i = 1;
	foreach ($old_order as $temp){
		mysql_query("UPDATE `" . $db_table_prefix . "structure` SET `order` = '$i' WHERE `order` = '$temp'");
		$i = $i + 1;
	}
	header("Location: " . $default_url . $admin_dir . "index.php?action=edit_sitemap");
	break;


/*===========================================================================
Move up sub category
===========================================================================*/
	case 'move_up_subcategory';
	//get current order value
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "$category` WHERE `id` = '$id'");
	while($sql_result = mysql_fetch_array($sql_query)) {
		$current_order = $sql_result[order];
		$new_order = $current_order - 1;
	}
	//swap order value with adjacent category
	mysql_query("UPDATE `" . $db_table_prefix . "$category` SET `order` = '$current_order' WHERE `order` = '$new_order'");
	mysql_query("UPDATE `" . $db_table_prefix . "$category` SET `order` = '$new_order' WHERE `id` = '$id'");

	//reorder results to get rid of blank / ambiguous results
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "$category` ORDER BY `order`");
	while($sql_result = mysql_fetch_array($sql_query)){
		$old_order[].= $sql_result[order];
	}
	$i = 1;
	foreach ($old_order as $temp){
		mysql_query("UPDATE `" . $db_table_prefix . "$category` SET `order` = '$i' WHERE `order` = '$temp'");
		$i = $i + 1;
	}
	header("Location: " . $default_url . $admin_dir . "index.php?action=edit_sitemap");
	break;


/*===========================================================================
Move down
===========================================================================*/
	case 'move_down_category';
	//get current order value
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "structure` WHERE `table` = '$category'");
	while($sql_result = mysql_fetch_array($sql_query)) {
		$current_order = $sql_result[order];
		$new_order = $current_order + 1;
	}
	//swap order value with adjacent category
	mysql_query("UPDATE `" . $db_table_prefix . "structure` SET `order` = '$current_order' WHERE `order` = '$new_order'");
	mysql_query("UPDATE `" . $db_table_prefix . "structure` SET `order` = '$new_order' WHERE `table` = '$category'");

	//reorder results to get rid of blank / ambiguous results
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "structure` ORDER BY `order`");
	while($sql_result = mysql_fetch_array($sql_query)){
		$old_order[].= $sql_result[order];
	}
	$i = 1;
	foreach ($old_order as $temp){
		mysql_query("UPDATE `" . $db_table_prefix . "structure` SET `order` = '$i' WHERE `order` = '$temp'");
		$i = $i + 1;
	}
	header("Location: " . $default_url . $admin_dir . "index.php?action=edit_sitemap");
	break;


/*===========================================================================
Move down sub category
===========================================================================*/
	case 'move_down_subcategory';
	//get current order value
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "$category` WHERE `id` = '$id'");
	while($sql_result = mysql_fetch_array($sql_query)) {
		$current_order = $sql_result[order];
		$new_order = $current_order + 1;
	}
	//swap order value with adjacent category
	mysql_query("UPDATE `" . $db_table_prefix . "$category` SET `order` = '$current_order' WHERE `order` = '$new_order'");
	mysql_query("UPDATE `" . $db_table_prefix . "$category` SET `order` = '$new_order' WHERE `table` = '$category'");

	//reorder results to get rid of blank / ambiguous results
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "$category` ORDER BY `order`");
	while($sql_result = mysql_fetch_array($sql_query)){
		$old_order[].= $sql_result[order];
	}
	$i = 1;
	foreach ($old_order as $temp){
		mysql_query("UPDATE `" . $db_table_prefix . "$category` SET `order` = '$i' WHERE `order` = '$temp'");
		$i = $i + 1;
	}
	header("Location: " . $default_url . $admin_dir . "index.php?action=edit_sitemap");
	break;


/*===========================================================================
Delete category
===========================================================================*/
	case 'delete_category';
	$category = strtolower($_REQUEST['category']);
	mysql_query("DELETE FROM " . $db_table_prefix . "structure WHERE `table` = '$category'") or die ("<b>A fatal MySQL error occured</b>.\n<br />Query: " . $sql_query . "<br />\nError: (" . mysql_errno() . ") " . mysql_error());;
	mysql_query("DROP TABLE `" . $db_table_prefix . "$category`");
	//reorder id by recreating field
	if ($page != 'orphan') {
		mysql_query("ALTER TABLE `" . $db_table_prefix . "structure` DROP `id`");
		mysql_query("ALTER TABLE `" . $db_table_prefix . "structure` ADD `id` MEDIUMINT( 16 ) NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST");
		header("Location: " . $default_url . $admin_dir . "index.php?action=edit_sitemap");
	}
	break;


/*===========================================================================
Save category information
===========================================================================*/
	case 'save_categories';
	$type = strtolower($_REQUEST['category_type']);
	 
	$category = strtolower($_REQUEST['category_lan_1']);
	$old_category = $_REQUEST['old_category'];

	$media_library_default_view = $_REQUEST['media_library_default_view'];
	$num_slideshow_images = $_REQUEST['num_slideshow_images'];
	$imagebox_type = $_REQUEST['imagebox_type'];
	$display_in_margin = $_REQUEST['display_in_margin'];
	$display_in_sitemap = $_REQUEST['display_in_sitemap'];
	$allow_comments = $_REQUEST['allow_comments'];
	$category_lan_1 = $_REQUEST['category_lan_1'];
	$category_lan_2 = $_REQUEST['category_lan_2'];
	$category_lan_3 = $_REQUEST['category_lan_3'];
	$category_lan_4 = $_REQUEST['category_lan_4'];
	$tool_tip_lan_1 = $_REQUEST['tool_tip_lan_1'];
	$tool_tip_lan_2 = $_REQUEST['tool_tip_lan_2'];
	$tool_tip_lan_3 = $_REQUEST['tool_tip_lan_3'];
	$tool_tip_lan_4 = $_REQUEST['tool_tip_lan_4'];

	if ($old_category == '') {

		//save new category to structure table
		$order = $num_tables + 1;
			
		if (mysql_query("INSERT INTO " . $db_table_prefix . "structure VALUES(NULL,'$category','$order','$type', '$media_library_default_view', '$num_slideshow_images', '$imagebox_type', '$display_in_margin', '$display_in_sitemap', '$allow_comments', '$category_lan_1', '$tool_tip_lan_1', '$category_lan_2', '$tool_tip_lan_2', '$category_lan_3', '$tool_tip_lan_3', '$category_lan_4', '$tool_tip_lan_4')")) {
				
			//if (mkdir($media_library .'/'. $category, 0700)) echo 'test';

			//create new table for category
			mysql_query("CREATE TABLE `" . $db_table_prefix . "$category` (
  			`id` mediumint( 16 ) NOT NULL AUTO_INCREMENT ,
  			`date` date NOT NULL default '0000-00-00',
  			`order` mediumint( 16 ) NOT NULL default '1',
  			`parent` varchar( 60 ) NOT NULL default '',
  			`child` varchar( 60 ) NOT NULL default '',
  			`category` varchar( 60 ) NOT NULL default '',
  			`image` varchar( 60 ) default NULL,
				`link_url` varchar(200) NOT NULL default '',
				`display_in_navbar` varchar(50) NOT NULL default 'on',   			
  			`title_lan_1` varchar( 60 ) NOT NULL default '',
  			`tool_tip_lan_1` varchar( 60 ) NOT NULL default '',
  			`description_lan_1` text NOT NULL,
  			`title_lan_2` varchar( 60 ) NOT NULL default '',
  			`tool_tip_lan_2` varchar( 60 ) NOT NULL default '',
  			`description_lan_2` text NOT NULL ,
  			`title_lan_3` varchar( 60 ) NOT NULL default '',
  			`tool_tip_lan_3` varchar( 60 ) NOT NULL default '',
  			`description_lan_3` text NOT NULL,
  			`title_lan_4` varchar( 60 ) NOT NULL default '',
  			`tool_tip_lan_4` varchar( 60 ) NOT NULL default '',
  			`description_lan_4` text NOT NULL,
  			PRIMARY KEY ( `id` ) ) ENGINE = InnoDB DEFAULT CHARSET = latin1") or die ("<b>A fatal MySQL error occured</b>.\n<br />Query: " . $sql_query . "<br />\nError: (" . mysql_errno() . ") " . mysql_error());;
		}

	} else {

		//category exists - update values
		mysql_query("UPDATE `" . $db_table_prefix . "structure` SET `table` = '$category', `type` = '$type', `media_library_default_view` = '$media_library_default_view', `num_slideshow_images` = '$num_slideshow_images', `imagebox_type` = '$imagebox_type', `display_in_margin` = '$display_in_margin', `display_in_sitemap` = '$display_in_sitemap', `allow_comments` = '$allow_comments', `category_lan_1` = '$category_lan_1', `tool_tip_lan_1` = '$tool_tip_lan_1', `category_lan_2` = '$category_lan_2', `tool_tip_lan_2` = '$tool_tip_lan_2', `category_lan_3` = '$category_lan_3', `tool_tip_lan_3` = '$tool_tip_lan_3', `category_lan_4` = '$category_lan_4', `tool_tip_lan_4` = '$tool_tip_lan_4' WHERE `table` = '$old_category'");
		mysql_query("RENAME TABLE `" . $db_table_prefix . $old_category . "`  TO `" . $db_table_prefix . $category . "`");
	}
	header("Location: " . $default_url . $admin_dir . "index.php?action=edit_sitemap");
	break;

}//end switch case

?>