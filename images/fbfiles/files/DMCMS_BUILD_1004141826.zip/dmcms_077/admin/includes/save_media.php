<?php
defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Check user priviledges
===========================================================================*/
require VALIDATE;

if ($user != 'ADMIN') header("Location: " . $default_path . "index.php");



//>get data entered in form and propogate variables
//strip slashes just in case magic quotes on
$library = mysql_escape_string(stripslashes($_REQUEST['parent']));
$child = mysql_escape_string(stripslashes($_REQUEST['child']));
$category = mysql_escape_string(stripslashes($_REQUEST['selected_category']));
$title_lan_1 = mysql_escape_string(stripslashes($_REQUEST['title_lan_1']));
$title_lan_2 = mysql_escape_string(stripslashes($_REQUEST['title_lan_2']));
$title_lan_3 = mysql_escape_string(stripslashes($_REQUEST['title_lan_3']));
$title_lan_4 = mysql_escape_string(stripslashes($_REQUEST['title_lan_4']));
$tool_tip_lan_1 = mysql_escape_string(stripslashes($_REQUEST['tool_tip_lan_1']));
$tool_tip_lan_2 = mysql_escape_string(stripslashes($_REQUEST['tool_tip_lan_2']));
$tool_tip_lan_3 = mysql_escape_string(stripslashes($_REQUEST['tool_tip_lan_3']));
$tool_tip_lan_4 = mysql_escape_string(stripslashes($_REQUEST['tool_tip_lan_4']));
$description_lan_1 = mysql_escape_string(stripslashes($_REQUEST['description_lan_1']));
$description_lan_2 = mysql_escape_string(stripslashes($_REQUEST['description_lan_2']));
$description_lan_3 = mysql_escape_string(stripslashes($_REQUEST['description_lan_3']));
$description_lan_4 = mysql_escape_string(stripslashes($_REQUEST['description_lan_4']));


//>get parent field data from database entry if available
$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "$page` WHERE `id` = '$id'");
while($sql_result = mysql_fetch_array($sql_query)){
	$old_library = $sql_result[parent];
	$old_image = $sql_result[image];
	$old_date = $sql_result[date];
	$old_category = $sql_result[category];
}


if ($_FILES['file_data']['name']) {

	//>upload file
	$destination_filepath = $default_path . $media_dir;
	$form_name = 'file_data';
	$filename = upload_file($destination_filepath, $form_name);

	if (!$filename){
		header("Location: " . $default_url . 'index.php?page=messagebox&message=upload_failed');
		exit;
	}

} else {
	$filename = $old_image;
}

//>if page does not exist add data to database
if ($id == '' || !isset($id) || $page == 'admin') {

	mysql_query("INSERT INTO `" . $db_table_prefix . $library . "` VALUES(NULL,
  (now()),
  '$order',
  '$library',
  '$title_lan_1',
  '$category',
  '$filename',
	'',
	'on',
  '$title_lan_1',
  '$tool_tip_lan_1',
  '$description_lan_1',
  '$title_lan_2',
  '$tool_tip_lan_2',
  '$description_lan_2',
  '$title_lan_3',
  '$tool_tip_lan_3',
  '$description_lan_3',
  '$title_lan_4',
  '$tool_tip_lan_4',
  '$description_lan_4')") or die ("<b>A fatal MySQL error occured</b>.\n<br />Query: " . $sql_query . "<br />\nError: (" . mysql_errno() . ") " . mysql_error());;

	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "$library` WHERE `description_lan_1` = '$description_lan_1'");
	while($sql_result = mysql_fetch_array($sql_query)) $id = $sql_result[id];

	//$page already exists - update data in database
} else {

	//breakpoint("'".$description_lan_1."'");

	//>new and old parent fields are the same - update existing entry
	if ($old_library == $library){
		// sort out order and type fields
		mysql_query("UPDATE `" . $db_table_prefix . $library . "` SET
		`child` = '$title_lan_1',
		`category` = '$category',
		`image` = '$old_image',
		`title_lan_1` = '$title_lan_1',
		`tool_tip_lan_1` = '$tool_tip_lan_1',
		`description_lan_1` = '$description_lan_1',
		`title_lan_2` = '$title_lan_2',
		`tool_tip_lan_2` = '$tool_tip_lan_2',
		`description_lan_2` = '$description_lan_2',
		`title_lan_3` = '$title_lan_3',
		`tool_tip_lan_3` = '$tool_tip_lan_3',
		`description_lan_3` = '$description_lan_3',
		`title_lan_4` = '$title_lan_4',
		`tool_tip_lan_4` = '$tool_tip_lan_4',
		`description_lan_4` = '$description_lan_4' WHERE `id` = '$id'") or die ("<b>A fatal MySQL error occured</b>.\n<br />Query: " . $sql_query . "<br />\nError: (" . mysql_errno() . ") " . mysql_error());;

		//>else parent fields are different
	} else {
		//>so delete data from old table
		mysql_query("DELETE FROM `" . $db_table_prefix . "$old_library` WHERE `id` = '$id'");

		//>reorder id of old table by recreating field
		mysql_query("ALTER TABLE `" . $db_table_prefix . "$old_library` DROP `id`");
		mysql_query("ALTER TABLE `" . $db_table_prefix . "$old_library` ADD `id` MEDIUMINT( 16 ) NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST");

		//>add data to new table
		mysql_query("INSERT INTO `" . $db_table_prefix . "$library` VALUES(NULL,
    '$old_date',
    '$order',
    '$library',
    '$title_lan_1',
    '$category',
    '$old_image',
		'',
		'on',
    '$title_lan_1',
    '$tool_tip_lan_1',
    '$description_lan_1',
    '$title_lan_2',
    '$tool_tip_lan_2',
    '$description_lan_2',
    '$title_lan_3',
    '$tool_tip_lan_3',
    '$description_lan_3',
    '$title_lan_4',
    '$tool_tip_lan_4',
    '$description_lan_4')") or die ("<b>A fatal MySQL error occured</b>.\n<br />Query: " . $sql_query . "<br />\nError: (" . mysql_errno() . ") " . mysql_error());

		$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "$library` WHERE `description_lan_1` = '$description_lan_1'") or die ("<b>A fatal MySQL error occured</b>.\n<br />Query: " . $sql_query . "<br />\nError: (" . mysql_errno() . ") " . mysql_error());
		while($sql_result = mysql_fetch_array($sql_query)) $id = $sql_result[id];
	}
}
header("Location: " . $default_path . "index.php?page=$library&id=$id");
exit;
?>