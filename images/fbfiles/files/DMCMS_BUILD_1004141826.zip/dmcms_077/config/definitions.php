<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Define constants
===========================================================================*/

define('VALIDATE', $root_path . $core_dir . 'validate.php');

/*===========================================================================
[FIXME] need to change definitions below
===========================================================================*/
$backup_dmcms_tables_only = TRUE; 
$remote_support_enabled = TRUE; //issues with this on some servers
$version_check_enabled = TRUE;
$db_save_to_file = TRUE;

$short_date = date ("F j Y");
$year = date ("Y");
$long_date = date ("F j Y - g:i:s");
$long_time = date ("g:i:s");
$short_time = date ("g:i");
$crlf = "\r\n";
$lf = "\n";


$num_languages = 4; //should be dynamic as per V080


//Following should be depreciated - should be set via template!! 
$navigation_seperator = "&nbsp&nbsp&nbsp&nbsp";
$cookie_trial_seperator = ' > ';




?>