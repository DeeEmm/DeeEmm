<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Validate users
===========================================================================*/

$logged_in = false;

//get variables passed from login form
$username = $_GET["username"];
$password = $_GET["password"];


if(!isset($_COOKIE["deeemm"])) {

	//no cookie so reset cookie just in case
 	setcookie ("deeemm", "", time() - 3600);

} elseif (isset($_COOKIE["deeemm"])) {

 	//get data from cookie
  $user = explode(" ",$_COOKIE["deeemm"]);

	//compare data against database
  $sql_query = "SELECT * FROM `" . $db_table_prefix . "users` WHERE `user_name` = '$user[0]'";
  $result = mysql_db_query($db_name, $sql_query);

  if(!mysql_num_rows($result)) {
  	//user not in database so reset cookie
  	setcookie ("deeemm", "", time() - 3600);
    $user = '';
  } ELSE {

    //compare cookie against database info
	  $chkusr = mysql_fetch_array($result);

	  if(unserialize(base64_decode($user[1])) != $chkusr[1]) {

	  	//password does not match database so reset cookie
	  	setcookie ("deeemm", "", time() - 3600);
	    $user = '';
		} else {

			//password matches database so get user level
		  $sql_query = "SELECT * FROM `" . $db_table_prefix . "users` WHERE `user_name` = '$user[0]'";
	  	$result = mysql_fetch_array(mysql_db_query($db_name, $sql_query));
			$user = $result[user_level];
			$logged_in = true;

      //get other userdata
			$username = $result[user_name];
			$password = $result[password];
			$nickname = $result[nick_name];
			$user_rank = $result[user_rank];
			$is_active = $result[is_active];
			$bio = $result[bio];
			$signature = $result[signature];
		}
	}
}
?>