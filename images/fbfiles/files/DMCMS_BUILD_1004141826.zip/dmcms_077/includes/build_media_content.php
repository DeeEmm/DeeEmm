<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Get last modified date
===========================================================================*/
$media_library_last_modified = @mysql_result(mysql_query("SELECT max(date) FROM " . $db_table_prefix . $page),0);
$media_library_last_modified = strftime("%a %d %b  %Y", strtotime($media_library_last_modified));


/*===========================================================================
Get number of files in library
===========================================================================*/
$sql_result = mysql_query("select count(*) from `" . $db_table_prefix . $page . "`");
$media_library_num_images = @mysql_result($sql_result,0);


/*===========================================================================
Get navigation id info

 PLEASE NOTE!!

 id values are unique but may not be concurrent so we need to get actual
 values from database and not simply increment / decrement current id value!!!
===========================================================================*/

//create array of all id's
$file_id_array = array();
$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . $page . "` ORDER BY `id`");
while($sql_result = mysql_fetch_array($sql_query)){
	$file_id_array[] .= $sql_result[id];
}

//get position of current id in array
$position = array_search($id, $file_id_array);

//get value of first id
$file_first = $file_id_array[0];

//get value of last id
$file_last = end($file_id_array);
//$media_library_num_images - $media_library_thumbs_per_page + 1

//get id for previous file
$index = $position - 1;
if ($index < 0) {
	$file_prev = $file_first;
} else {
	$file_prev = $file_id_array[$index];
}

//get id for next file
$index = $position + 1;
if ($index >= count($file_id_array)) {
	$file_next = $file_last;
} else {
	$file_next = $file_id_array[$index];
}

//get id for first thumbnail file on page
$a = $id-1;

$media_library_index_first_image = ($a - ($a % $media_library_thumbs_per_page) + 1);
if ($media_library_index_first_image <= 0) $media_library_index_first_image = 1;
if ($media_library_index_first_image > $media_library_num_images) $media_library_index_first_image = $media_library_num_images;

//create general nav links
$media_nav = "<A href='./index.php?page=$page&amp;action=thumbnails' alt='[var]MEDIA[/var]' title='[var]MEDIA_TITLE[/var]'>$lan[thumbnails]</A><BR />";
$media_nav .= "<A href='./index.php?page=$page&amp;action=list' alt='[var]MEDIA[/var]' title='[var]MEDIA_TITLE[/var]'>$lan[filelist]</A><BR />";

/*===========================================================================
Get selection for default view for media library
===========================================================================*/
if ($action == '' && $id == '') {
	$sql_result = mysql_query("select count(*) from `" . $db_table_prefix . $page . "`");
	$media_library_num_images = @mysql_result($sql_result,0);

	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "structure` WHERE `table` = '$page'");
	while($sql_result = mysql_fetch_array($sql_query)){
		$action = $sql_result['media_library_default_view'];
	}

	switch ($action) {

		case 'thumbnails';
		$id = NULL;
		break;

		case 'list';
		break;

		case 'first';
		//get value of first id
		$id = $file_first;
		$action = NULL;
		break;

		case 'last';
		//get value of last id
		$id = $file_last;
		$action = NULL;
		break;

	}//end switch $action
}//endif

/*===========================================================================
Display image
===========================================================================*/
	IF ($id <> '' && !$action) {
		if ($nav_style == 'buttons') {
			$media_library_image_nav = $media_library_image_edit . "<A href='$default_url" . "index.php?page=$page&amp;id=$file_prev'><img class='icon' title='Previous' src='$default_url".$templates_dir."images/icons/previous.gif'></A> <A href='$default_url" . "index.php?page=$page&amp;action=thumbnails&amp;id=$media_library_index_first_image'><img class='icon' title='View Thumbnails' src='$default_url".$templates_dir."images/icons/view_thumbnails.gif'></A> <A href='$default_url" . "index.php?page=$page&amp;action=list'><img class='icon' title='View as List' src='$default_url".$templates_dir."images/icons/view_list.gif'></A> <A href='$default_url" . "index.php?page=$page&amp;id=$file_next'><img class='icon' title='Next' src='$default_url".$templates_dir."images/icons/next.gif'></A>" . $lf;
		} else {
			$media_library_image_nav = $media_library_image_edit . "<small>[ <A href='$default_url" . "index.php?page=$page&amp;id=$file_prev'>[lan]prev[/lan]</A> | <A href='$default_url" . "index.php?page=$page&amp;action=thumbnails&amp;id=$media_library_index_first_image'>[lan]thumbnails[/lan]</A> | <A href='$default_url" . "index.php?page=$page&amp;action=list'>[lan]list[/lan]</A> | <A href='$default_url" . "index.php?page=$page&amp;id=$file_next'>[lan]next[/lan]</A> ]</small>" . $lf;
		}
		$media_library_image_name = NULL;
		$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . $page . "` WHERE `id` = $id");
		while($sql_result = mysql_fetch_array($sql_query)){
			$sql_query2 = mysql_query("SELECT * FROM `" . $db_table_prefix . "structure` WHERE `table` = '$sql_result[category]'");
			while($sql_result2 = mysql_fetch_array($sql_query2)){
				$media_library_image_category = $sql_result2[category_lan_ . $language];
			}

			$media_library_image_title = $sql_result[title_lan_.$language];
			$media_library_image_description = $sql_result[description_lan_.$language];
			$media_library_image_date = $sql_result[date];
			$media_library_image_date = strftime("%a %d %b  %Y", strtotime($media_library_image_date));
			$media_library_image_name = $sql_result[image];
			$media_library_image_src = $media_dir . $sql_result[image];
		}

		//check if name exists
		if (!isset($media_library_image_name)){
			$media_library_image_src = $media_dir . 'image_unavailable.jpg';
		}

		//		if (stristr($media_library_image_name,".mpg")) $media_library_image_src = $media_dir . 'mpeg.jpg';
		//		if (stristr($media_library_image_name,".mov")) $media_library_image_src = $media_dir . 'quicktime.jpg';
		if (stristr($media_library_image_name,".zip")) $media_library_image_src = $media_dir . 'zip_file.jpg';
		if (stristr($media_library_image_name,".pdf")) $media_library_image_src = $media_dir . 'pdf_file.jpg';

		//limit image size to max size
		list($src_width, $src_height) = getimagesize($media_library_image_src);
		if ($src_width < $media_library_max_image_width) $media_library_max_image_width = $src_width;

		//get file extension
		$media_library_image_extension = strrchr($media_library_image_src, '.');

		//select template based on extension
		switch ($media_library_image_extension) {

			case '';
			case '.jpg';
			case '.gif';
			case '.png';
			case '.tif';
			case '.bmp';
			$content = $default_path . $templates_dir  ."media_display_image.tpl";
			break;

			case '.mpg';
			$content = $default_path . $templates_dir  ."media_display_mpeg.tpl";
			break;

			case '.mov';
			$content = $default_path . $templates_dir  ."media_display_mov.tpl";
			break;

			case '.pdf';
			$content = $default_path . $templates_dir  ."media_display_pdf.tpl";
			break;

			case '.zip';
			$content = $default_path . $templates_dir  ."media_display_image.tpl";
			break;

		}//end switch $media_library_image_extension

		//read template file
		$main = read_file($content);

		$media_library_image_num = $id;
		if ($media_library_image_category == '') $media_library_image_category = $lan[general];
		$page_title .= $cookie_trial_seperator .  $media_library_image_category . $cookie_trial_seperator . $media_library_image_title;
		$cookie_trial .= $cookie_trial_seperator .  $media_library_image_category . $cookie_trial_seperator . $media_library_image_title;
	}

/*===========================================================================
Display as list
===========================================================================*/
	IF ($action == 'list') {
		$last_media_library_category = '~!nothing!~';
		$content = $default_path . $templates_dir  . "media_index.tpl";
		$main = read_file($content);
		if ($nav_style == 'buttons') {
			$media_library_index_nav = "<A href='$default_url" . "index.php?page=$page&amp;action=thumbnails&amp;id=$media_library_index_first_image'><img class='icon' title='View Thumbnails' src='$default_url".$templates_dir."images/icons/view_thumbnails.gif'></A>" . $lf;
		} else {
			$media_library_index_nav = "<small>[ <A href='$default_url" . "index.php?page=$page&amp;action=thumbnails&amp;id=$media_library_index_first_image'>[lan]thumbnails[/lan]</A> ]</small>" . $lf;
		}

		$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . $page . "` ORDER BY `category`");
		while($sql_result = mysql_fetch_array($sql_query)){
			$media_library_image_name = $sql_result[image];

			$media_library_image_extension = strrchr($media_library_image_name, '.');

			switch ($media_library_image_extension) {

				case '.jpg';
				case '.gif';
				case '.png';
				case '.bmp';
				$media_library_image_title = $lan[picture] . ' - ';
				break;

				case '.mpg';
				$media_library_image_title = $lan[video] . ' - ';
				break;

				case '.mov';
				$media_library_image_title = $lan[video] . ' - ';
				break;

				case '.pdf';
				$media_library_image_title = $lan[pdf] . ' - ';
				break;

				case '.zip';
				$media_library_image_title = $lan[zip] . ' - ';
				break;

			}

			$media_library_image_title .= $sql_result[title_lan_.$language];
			$media_library_image_description = $sql_result[description_lan_.$language];
			$media_library_image_num = $sql_result[id];
			$media_library_image_date = $sql_result[date];
			$media_library_image_date = strftime("%a %d %b  %Y", strtotime($media_library_image_date));
			$media_library_category = $sql_result[category];



			//   	  $sql_query2 = mysql_query("SELECT * FROM `" . $db_table_prefix . "structure` WHERE `table` = '$sql_result[category]'");
			//
			//	    while($sql_result2 = mysql_fetch_array($sql_query2)){
			//  	    $media_library_category = $sql_result2[category_lan_ . $language];
			//	    }

			if ($last_media_library_category != $media_library_category) {
				if ($last_media_library_category <> '~!nothing!~') $main .= '	</DIV><BR>' . $lf;
				$main .= '	<DIV>' . $lf;

				if ($media_library_category == ''){
					$main .= "<H2>$lan[general]</H2>" . $lf;
				} ELSE {
					$main .= "<H2>$media_library_category</H2>" . $lf;
				}
			}
			$last_media_library_category = $media_library_category;
			$main .= "<small><a href='$default_url" . "index.php?page=$page&amp;id=$media_library_image_num'><span class='float_right'>$media_library_image_date</span>$media_library_image_title </A></small><br>";
			$media_library_image_description = truncate($media_library_image_description, 80);
	  }
	  if (isset($media_library_image_title) && $media_library_image_title <> '') {
	  	$main .= '  </DIV>' . $lf;
	  } else {
	  	$main .= '<br>';
	  	$main .= '<br>';
	  	$main .= '<center>' . $lan[no_media] . '<center>';
	  }
	  $main .= '</DIV>' . $lf;
		}

/*===========================================================================
Display as thumbnails
===========================================================================*/
		IF ($action == 'thumbnails') {
	  $content = $default_path . $templates_dir . "media_thumbs.tpl";
	  $main = read_file($content);
	  IF (!isset($id)){
	  	$curr_image = $media_library_num_images - $media_library_thumbs_per_page + 1;
	  	if ($curr_image <= 0) $curr_image = 1;
	  } ELSE {
	  	$curr_image = $id;
	  }
	  $media_library_first_thumb = $curr_image;
	  $media_library_last_thumb = $media_library_first_thumb + $media_library_thumbs_per_page -1 ;
	  if ($media_library_last_thumb > $media_library_num_images) $media_library_last_thumb = $media_library_num_images;
	  $media_library_page_prev = $curr_image - $media_library_thumbs_per_page;
	  if ($media_library_page_prev <= 0)$media_library_page_prev = 1;
	  $media_library_page_next = $curr_image + $media_library_thumbs_per_page;
	  if ($media_library_page_next >= $media_library_num_images)$media_library_page_next = $media_library_num_images - $media_library_thumbs_per_page;
	  if ($media_library_page_next <= 0)$media_library_page_next = 1;

	  if ($nav_style == 'buttons') {
	  	$media_library_index_nav = "$media_library_index_edit  <A href='$default_url" . "index.php?page=$page&amp;action=thumbnails&amp;id=1'><img class='icon' title='First' src='$default_url".$templates_dir."images/icons/first.gif'></A> <A href='$default_url" . "index.php?page=$page&amp;action=thumbnails&amp;id=$media_library_page_prev'><img class='icon' title='Previous' src='$default_url".$templates_dir."images/icons/previous.gif'></A> <A href='$default_url" . "index.php?page=$page&amp;action=list'><img class='icon' title='List' src='$default_url".$templates_dir."images/icons/view_list.gif'></A>  <A href='$default_url" . "index.php?page=$page&amp;action=thumbnails&amp;id=$media_library_page_next'><img class='icon' title='Next' src='$default_url".$templates_dir."images/icons/next.gif'></A> <A href='$default_url" . "index.php?page=$page&amp;action=thumbnails&amp;id=".($media_library_num_images - $media_library_thumbs_per_page + 1)."'><img class='icon' title='Last' src='$default_url".$templates_dir."images/icons/last.gif'></A>";
	  } else {
	  	$media_library_index_nav = "$media_library_index_edit  <small>[ <A href='$default_url" . "index.php?page=$page&amp;action=thumbnails&amp;id=1'>[lan]first[/lan]</A> | <A href='$default_url" . "index.php?page=$page&amp;action=thumbnails&amp;id=$media_library_page_prev'>[lan]prev[/lan]</A> | <A href='$default_url" . "index.php?page=$page&amp;action=list'>[lan]list[/lan]</A> | <A href='$default_url" . "index.php?page=$page&amp;action=thumbnails&amp;id=$media_library_page_next'>[lan]next[/lan]</A> | <A href='$default_url" . "index.php?page=$page&amp;action=thumbnails&amp;id=".($media_library_num_images - $media_library_thumbs_per_page + 1)."'>[lan]last[/lan]</A> ]</small>";
	  }

	  for($count=$curr_image;$count<$curr_image+$media_library_thumbs_per_page;$count++) {
	  	$id = $count-1;
	  	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . $page . "` WHERE `id` = '$file_id_array[$id]'");
	  	while($sql_result = mysql_fetch_array($sql_query)) {
	  		$media_library_image_title = $sql_result[title_lan_.$language];
	  		$media_library_image_description = $sql_result[description_lan_.$language];
	  		$media_library_image_num = $sql_result[id];
	  		$media_library_image_name = $sql_result[image];
	  		//check if image name exists
	  		if ($media_library_image_name == ''){
	  			$media_library_image_name = 'image_unavailable.jpg';
	  		}

	  		if (stristr($media_library_image_name,".mpg")) $media_library_image_name = 'mpeg.jpg';
	  		if (stristr($media_library_image_name,".mov")) $media_library_image_name = 'quicktime.jpg';
	  		if (stristr($media_library_image_name,".zip")) $media_library_image_name = 'zip_file.jpg';
	  		if (stristr($media_library_image_name,".pdf")) $media_library_image_name = 'pdf_file.jpg';
	  		$media_library_thumbs .= '<DIV class="media_thumb">' . $lf;
	  		$media_library_thumbs .= "	<center><a href='$default_url" . "index.php?page=$page&amp;id=$media_library_image_num'><img src='" . $default_url . $media_dir . "thumbnail.php?height=" . $media_library_thumb_height ."&amp;width=" . $media_library_thumb_width . "&amp;filename=$media_library_image_name' border=0></A></center><BR />" . $lf;
	  		$media_library_thumbs .= "	<small><center><span>$media_library_image_title</span></center></small>" . $lf;
	  		$media_library_thumbs .= "</DIV>\r\n" . $lf;
	  		//ROW CONTROL!!???
	  		//       if ($count == ($media_library_thumbs_per_page / $media_library_thumb_rows_per_page)) {
	  		if ((($count + 1) % $media_library_thumb_rows_per_page) == 1) {
	  			//         $media_library_thumbs .= "</br>";
	  		}
	    }
	  	}
	  	if (!isset($media_library_image_title) || $media_library_image_title == '') {
	  		$media_library_thumbs .= '<br>';
	  		$media_library_thumbs .= '<br>';
	  		$media_library_thumbs .= '<center>' . $lan[no_media] . '<center>';
	  	}
	  }
?>