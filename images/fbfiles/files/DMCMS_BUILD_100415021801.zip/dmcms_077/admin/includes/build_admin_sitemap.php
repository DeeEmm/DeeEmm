<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Check user priviledges
===========================================================================*/
require VALIDATE;

if ($user != 'ADMIN') header("Location: " . $default_url . "index.php");

$content = "templates/sitemap.tpl";
$main = read_file($content);

/*===========================================================================
Propogate the site map
============================================================================*/

//generate list with links for modifying category
foreach($all_tables as $value){
	$tables_list = '';
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "structure` WHERE `table` = '$value'");
	while($sql_result = mysql_fetch_array($sql_query)){
		$type = $sql_result[type];
		$media_library_default_view = $sql_result[media_library_default_view];
		$num_slideshow_images = $sql_result[num_slideshow_images];
		$imagebox_type = $sql_result[imagebox_type];
		$display_in_margin = $sql_result[display_in_margin];
		$display_in_sitemap = $sql_result[display_in_sitemap];
		$allow_comments = $sql_result[allow_comments];
		$category = $sql_result[category_lan_ . $language];
	}

	//>get highest order page
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "$value` WHERE `id` > 0 ORDER BY `order` LIMIT 1");
	if($sql_result = mysql_fetch_array($sql_query)){
		$id = $sql_result[id];
		$link_url = $sql_result[link_url];
	}

	//get main heading

	switch ($type) {

		case 'list';
		case 'normal';
			if (isset($link_url) && $link_url <> '') {
			$tables_list .= str_replace($value, 
			"<HR size='1px' color='#ddd' class='clear_both'>
			<span class='float_right'>
				<a href='$default_url".$admin_dir."index.php?action=add'>
					<img class='icon' title='Add Item to Category' src='$default_url"."admin/icons/article_add.gif'>
				</a> 
				<a href='$default_url".$admin_dir."index.php?action=add_link'>
					<img class='icon' title='Add Link to Category' src='$default_url"."admin/icons/link_add.gif'>
				</a> 
				<a href='$default_url".$admin_dir."index.php?category=$value&amp;action=move_down_category'>
					<img class='icon' title='Move Down' src='$default_url"."admin/icons/article_move_down.gif'>
				</a> 
				<a href='$default_url"."$admin_dir"."index.php?category=$value&amp;action=move_up_category'>
					<img class='icon' title='Move Up' src='$default_url"."admin/icons/article_move_up.gif'>
				</a>&nbsp
				<a href='$default_url"."$admin_dir"."index.php?action=edit_sitemap&amp;category=$value#1'>
					<img class='icon' title='Edit' src='$default_url"."admin/icons/article_edit.gif'>
				</a>&nbsp
				<a href='$default_url"."$admin_dir"."index.php?action=delete_category&amp;category=" . $value. "' onClick=\"javascript:return confirm('[lan]delete_warning[/lan] $value ?')\">
					<img class='icon' title='Delete' src='$default_url".$templates_dir."images/icons/article_delete.gif'>
				</a>
			</span>
			<img class='icon' title='$type' src='$default_url" . "admin/icons/$type.gif'>&nbsp;&nbsp;
				<a class='sitemap_item' href='" . $link_url . "'>" . $category . "</A>"
			, $value);
			
			} else {
			
			$tables_list .= str_replace($value, 
			"<HR size='1px' color='#ddd' class='clear_both'><span class='float_right'>
			<a href='$default_url".$admin_dir."index.php?action=add'>
				<img class='icon' title='Add Item to Category' src='$default_url"."admin/icons/article_add.gif'>
			</a> 
			<a href='$default_url".$admin_dir."index.php?action=add_link'>
				<img class='icon' title='Add Link to Category' src='$default_url"."admin/icons/link_add.gif'>
			</a> 
			<a href='$default_url".$admin_dir."index.php?category=$value&amp;action=move_down_category'>
				<img class='icon' title='Move Down' src='$default_url"."admin/icons/article_move_down.gif'>
			</a> 
			<a href='$default_ur"."$admin_dirl"."index.php?category=$value&amp;action=move_up_category'>
				<img class='icon' title='Move Up' src='$default_url"."admin/icons/article_move_up.gif'>
			</a>&nbsp
			<a href='$default_url"."$admin_dir"."index.php?action=edit_sitemap&amp;category=$value#1'>
				<img class='icon' title='Edit' src='$default_url"."admin/icons/article_edit.gif'>
			</a>&nbsp
			<a href='$default_url"."$admin_dir"."index.php?action=delete_category&amp;category=" . $value. "' onClick=\"javascript:return confirm('[lan]delete_warning[/lan] $value ?')\">
				<img class='icon' title='Delete' src='$default_url" . "admin/icons/article_delete.gif'>
			</a>
			</span>
				<img class='icon' title='$type' src='$default_url" . "admin/icons/$type.gif'>&nbsp;&nbsp;
			<a class='sitemap_item' href='$default_url"."index.php?page=" . $value . "&amp;id=$id'>" . $category . "</A>"
			, $value);
			}
		break;

		case 'media';
			$tables_list .= str_replace($value, "<HR size='1px' color='#ddd' class='clear_both'><span class='float_right'><a href='$default_url"."$admin_dir"."index.php?action=add_media'><img class='icon' title='Add Media to Category' src='$default_url"."admin/icons/article_add.gif'></a> <a href='$default_url"."$admin_dir"."index.php?category=$value&amp;action=move_down_category'><img class='icon' title='Move Up' src='$default_url"."admin/icons/article_move_down.gif'></a> <a href='$default_url".$admin_dir."index.php?category=$value&amp;action=move_up_category'><img class='icon' title='Move Up' src='$default_url"."admin/icons/article_move_up.gif'></a>&nbsp<a href='$default_url"."$admin_dir"."index.php?action=edit_sitemap&amp;category=$value#1'><img class='icon' title='Edit' src='$default_url"."admin/icons/article_edit.gif'></a>&nbsp<a href='$default_url"."$admin_dir"."index.php?action=delete_category&amp;category=" . $value . "' onClick=\"javascript:return confirm('[lan]delete_warning[/lan] $value ?')\"><img class='icon' title='Delete' src='$default_url" . "admin/icons/article_delete.gif'></a></span><img class='icon' title='$type' src='$default_url" . "admin/icons/$type.gif'>&nbsp;&nbsp;<a class='sitemap_item' href='$default_url"."index.php?page=" . $value . "'>" . $category . "</A>", $value);
		break;
	}


	//get sub heading
	$sql_query  = mysql_query("SELECT * FROM `" . $db_table_prefix . "$value` ORDER BY `order`");
	while ($sql_result = mysql_fetch_array($sql_query)){
		$title = $sql_result[title_lan_ . $language];
		$id = $sql_result[id];
		$link_url = $sql_result[link_url];

		if ($type == 'normal'){
			if (isset($link_url) && $link_url <> '') {
				$tables_list .= str_replace($value, "<ul><span class='float_right'><a href='$default_url"."$admin_dir"."index.php?id=$id&amp;category=$value&amp;action=move_down_subcategory'><img class='icon' title='Move Down' src='$default_url"."admin/icons/article_move_down.gif'></a> <a href='$default_url"."$admin_dir"."index.php?id=$id&amp;category=$value&amp;action=move_up_subcategory'><img class='icon' title='Move Up' src='$default_url"."admin/icons/article_move_up.gif'></a>&nbsp<a href='$default_url"."$admin_dir"."index.php?page=$value&amp;id=$id&amp;action=edit_link'><img class='icon' title='Edit' src='$default_url"."admin/icons/link_edit.gif'></a>&nbsp<a href='$default_url"."$admin_dir"."index.php?page=$value&amp;id=$id&amp;action=delete' onClick=\"javascript:return confirm('[lan]delete_warning[/lan]')\"><img class='icon' title='Delete' src='$default_url"."admin/icons/link_delete.gif'></a></span><img class='icon' title='link' src='$default_url" . "admin/icons/link.gif'>&nbsp;&nbsp;<a class='sitemap_item' href='$link_url'>" . $title . "</A></ul>", $value);
			} else {
				$tables_list .= str_replace($value, "<ul><span class='float_right'><a href='$default_url"."$admin_dir"."index.php?id=$id&amp;category=$value&amp;action=move_down_subcategory'><img class='icon' title='Move Down' src='$default_url"."admin/icons/article_move_down.gif'></a> <a href='$default_url"."$admin_dir"."index.php?id=$id&amp;category=$value&amp;action=move_up_subcategory'><img class='icon' title='Move Up' src='$default_url"."admin/icons/article_move_up.gif'></a>&nbsp<a href='$default_url"."$admin_dir"."index.php?page=$value&amp;id=$id&amp;action=edit'><img class='icon' title='Edit' src='$default_url"."admin/icons/article_edit.gif'></a>&nbsp<a href='$default_url"."$admin_dir"."index.php?page=$value&amp;id=$id&amp;action=delete' onClick=\"javascript:return confirm('[lan]delete_warning[/lan]')\"><img class='icon' title='Delete' src='$default_url"."admin/icons/article_delete.gif'></a></span><img class='icon' title='$type' src='$default_url" . "admin/icons/page.gif'>&nbsp;&nbsp;<a class='sitemap_item' href='../index.php?page=" . $value . "&amp;id=$id'>" . $title . "</A></ul>", $value);
			}
		}
	}
	$tables_list = str_replace('  ', '', $tables_list);
	if (isset($display_in_sitemap) && $display_in_sitemap <> ''){
		$sitemap_list .= $tables_list;
	} else {
		$non_sitemap_list .= $tables_list;
	}
}

//Add forum link if enabled
if ($forum_enabled == true) {
	$sitemap_list .= "<HR size='1px' color='#ddd' class='clear_both'><img class='icon' title='" . $lan[forum] . "' src='$default_url" . "admin/icons/page.gif'>&nbsp;&nbsp;<A href='" . $forum_path . "' title='" . $lan[forum] . "'>$forum_name</a>	";
}

/*===========================================================================
Sitemap admin functions
===========================================================================*/

$sitemap_editor = "templates/admin_mod_sitemap.tpl";
$sitemap_editor = read_file($sitemap_editor);


$editing_category_message = $lan[editing_category_message];

/*===========================================================================
Propogate the orphan page list
===========================================================================*/
$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "orphan`");
while($sql_result = @mysql_fetch_array($sql_query)){
	$title = $sql_result[title_lan_ . $language];
	$id = $sql_result[id];
		$orphan_list .= str_replace($value, "<span class='float_right'><a href='$default_url"."$admin_dir"."index.php?page=orphan&amp;action=edit&amp;id=" . $id . "'><img class='icon' title='Edit' src='$default_url"."admin/icons/article_edit.gif'></a>&nbsp<a href='$default_url"."$admin_dir"."index.php?page=orphan&amp;action=delete&amp;id=" . $id . "' onClick=\"javascript:return confirm('[lan]delete_warning[/lan] $value ?')\"><img class='icon' title='Delete' src='$default_url" . "admin/icons/article_delete.gif'></a></span><img class='icon' title='$type' src='$default_url" . "admin/icons/page.gif'>&nbsp;&nbsp;<a class='sitemap_item' href='$default_url"."index.php?page=orphan&amp;id=" . $id . "'>" . $title . "</A><br><br>", $value);
}

/*===========================================================================
Create and propogate the sitemap editor
===========================================================================*/

//check if category is being editied if so propogate text boxes
$category = strtolower($_REQUEST['category']);

if (isset($category) && $category <> '') {
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "structure` WHERE `table` = '$category'");
	while($sql_result = mysql_fetch_array($sql_query)){
		$display_in_margin = $sql_result[display_in_margin];
		$display_in_sitemap = $sql_result[display_in_sitemap];
		$media_library_default_view = $sql_result[media_library_default_view];
		$num_slideshow_images = $sql_result[num_slideshow_images];
		$imagebox_type = $sql_result[imagebox_type];
		$allow_comments = $sql_result[allow_comments];
		$category_lan_1 = $sql_result[category_lan_1];
		$tool_tip_lan_1 = $sql_result[tool_tip_lan_1];
		$category_lan_2 = $sql_result[category_lan_2];
		$tool_tip_lan_2 = $sql_result[tool_tip_lan_2];
		$category_lan_3 = $sql_result[category_lan_3];
		$tool_tip_lan_3 = $sql_result[tool_tip_lan_3];
		$category_lan_4 = $sql_result[category_lan_4];
		$tool_tip_lan_4 = $sql_result[tool_tip_lan_4];
	}

	if ($media_library_default_view == 'thumbnails') $sitemap_editor = str_replace('[var]thumbnails[/var]', 'checked="true"', $sitemap_editor);
	if ($media_library_default_view == 'list') $sitemap_editor = str_replace('[var]list_view[/var]', 'checked="true"', $sitemap_editor);
	if ($media_library_default_view == 'first') $sitemap_editor = str_replace('[var]first_image[/var]', 'checked="true"', $sitemap_editor);
	if ($media_library_default_view == 'last') $sitemap_editor = str_replace('[var]last_image[/var]', 'checked="true"', $sitemap_editor);
	if ($imagebox_type == 'slideshow') $sitemap_editor = str_replace('[var]slideshow[/var]', 'checked="true"', $sitemap_editor);
	if ($imagebox_type == 'random') $sitemap_editor = str_replace('[var]random[/var]', 'checked="true"', $sitemap_editor);
	if ($display_in_margin == 'on') $sitemap_editor = str_replace('[var]display_in_margin[/var]', 'checked="true"', $sitemap_editor);
	if ($display_in_sitemap == 'on') $sitemap_editor = str_replace('[var]display_in_sitemap[/var]', 'checked="true"', $sitemap_editor);
	if ($allow_comments == 'on') $sitemap_editor = str_replace('[var]allow_comments[/var]', 'checked="true"', $sitemap_editor);

	$old_category = $category;
	$editing_category_message = $lan[editing_category_message_1] . " '" . $category . "'";
}


/*===========================================================================
Generate the category type drop down menu
===========================================================================*/
$category_type = '';

$type = 'normal'; //set default list type to display
//get current type
$sql_query  = mysql_query("SELECT * FROM `" . $db_table_prefix . "structure` WHERE `table` LIKE '$category'");
while ($sql_result = mysql_fetch_array($sql_query)){
	$type = $sql_result[type];
}

//get all possible types from database + active type
$sql_query  = mysql_query("SHOW COLUMNS FROM `" . $db_table_prefix . "structure` LIKE 'type'");
$sql_result = mysql_fetch_row($sql_query);
preg_match_all("/'(.*?)'/", $sql_result[1], $temp_array);
$category_types = array_unique($temp_array);
sort($category_types);
//create drop down list
$category_type = "<select class='w100pcnt' name='category_type' onchange='setup_categories_form()'>". $crlf . "<option value='$type'>$type</option>" . $crlf;
foreach($category_types[0] as $value) {
	$value = str_replace('\'', '', $value);
	if ($value != $type){
		$category_type .= "<option value='$value'>$value</option>";
	}
}
$category_type = str_replace('  ', '', $category_type);
$category_type .= '</select>';


$sitemap_editor = replace_variables($sitemap_editor);


?>
