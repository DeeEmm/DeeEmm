<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Check user priviledges
===========================================================================*/
require VALIDATE;

if ($user != 'ADMIN') header("Location: " . $default_url . "index.php");

$db_filename = $_REQUEST['db_filename'];
	
	
	if ($db_filename == 'select_file') {
		//selection not changed upload file if selected
		$db_filename = $_REQUEST['local_db_filename'];
		$new_filename = upload_file($abs_path . $db_backup_dir . $db_filename, 'local_db');
		$db_file = read_file($abs_path . $db_backup_dir . $new_filename);
	} else {
		$db_file = read_file($abs_path . $db_backup_dir . $db_filename);
	}
	

	//split file line by line
	$db_file_array = preg_split('/\n/', $db_file);
	
	//breakpoint($db_file_array);
	
	//check each line
	foreach($db_file_array as $value){
		//if it's not a comment or blank line execute sql statement
		if (preg_match("/^[^#\s ]/", $value)) {
			mysql_query("$value") or die('effin thing');
			echo $value.'<br>';
		}else{
			echo $value.'<br>';
		}
	}
exit;

?>