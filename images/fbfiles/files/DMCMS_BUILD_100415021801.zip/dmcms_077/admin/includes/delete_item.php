<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Check user priviledges
===========================================================================*/
require VALIDATE;

if ($user != 'ADMIN') header("Location: " . $default_url . "index.php");



if ($action == 'delete') {
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "$page` WHERE `id` = '$id'");
	while($sql_result = mysql_fetch_array($sql_query)){
		$filename = $sql_result[image];
	}

	//	//check to make sure image stored in image field not used elsewhere
	//	//may need to only check this for media type articles
	//	$no_times_used = 1;
	//	for($count=0;$count<$num_tables+1;$count++){
	//	  $sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . $all_tables[$count] . "` WHERE `title_lan_" . $language . "` LIKE '%" . $filename . "%' OR `description_lan_" . $language . "` LIKE '%" . $filename . "%' ");
	//
	//	  while($sql_result = @mysql_fetch_array($sql_query)){
	//			//keep tally of number of times file used
	//	    $no_times_used += 1;
	//			//generate list of items for the messagebox
	//			$file_list .= '<a href = "' . $default_url . 'index.php?page=' . $all_tables[$count] . '&id=' . $sql_result[id] . '">' . $sql_result['title_lan_'.$language] . '</a><br>';
	//	  }
	//	}
	//
	//	if ($no_times_used > 1) {
	//		$page = 'messagebox';
	//		$warning_message = $lan['image_used'] . $file_list;
	//	} else {
	
	//delete image
	unlink ("$media_dir/$filename");
	
	//remove article
	mysql_query("DELETE FROM `" . $db_table_prefix . "$page` WHERE `id` = '$id'");
	
	//defragment table
	mysql_query("ALTER TABLE `" . $db_table_prefix . "$page` ENGINE=INNODB");
	
	//return to where you came from
 	header("Location: " . $default_url . "index.php");
	exit;
	//	}
}

?>
