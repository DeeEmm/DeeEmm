<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Check user priviledges
===========================================================================*/
require VALIDATE;

if ($user != 'ADMIN') header("Location: " . $default_url . "index.php");



//get data entered in form and propogate variables
$parent = mysql_escape_string(stripslashes($_REQUEST['parent']));
//$child = mysql_escape_string(stripslashes($_REQUEST['child']));
$link_url = $_REQUEST['link_url'];
$title_lan_1 = mysql_escape_string(stripslashes($_REQUEST['title_lan_1']));
$title_lan_2 = mysql_escape_string(stripslashes($_REQUEST['title_lan_2']));
$title_lan_3 = mysql_escape_string(stripslashes($_REQUEST['title_lan_3']));
$title_lan_4 = mysql_escape_string(stripslashes($_REQUEST['title_lan_4']));
$tool_tip_lan_1 = mysql_escape_string(stripslashes($_REQUEST['tool_tip_lan_1']));
$tool_tip_lan_2 = mysql_escape_string(stripslashes($_REQUEST['tool_tip_lan_2']));
$tool_tip_lan_3 = mysql_escape_string(stripslashes($_REQUEST['tool_tip_lan_3']));
$tool_tip_lan_4 = mysql_escape_string(stripslashes($_REQUEST['tool_tip_lan_4']));


//get parent field data from database entry if available
$sql_query = mysql_query("SELECT * FROM " . $db_table_prefix . "$page WHERE `id` = $id");
while($sql_result = @mysql_fetch_array($sql_query)){
	$old_parent = $sql_result[parent];
	$old_image = $sql_result[image];
	$old_date = $sql_result[date];
}


// calculate icon type from url (if url is local)
$link_type = $link_url;
$icon_type = '';


//get number of entries in new parent table
$sql_result = mysql_query("select count(*) from '$parent'");
$order = @mysql_result($sql_result,0) + 1;
if ($order < 1) $order = 1;

//if $page does not exist add data to database
if ($page == '' || !isset($page) || $page == 'admin') {

	mysql_query("INSERT INTO `" . $db_table_prefix . $parent . "` VALUES(NULL,
  (now()),
  '$order',
  '$parent',
  '$title_lan_1',
  '$title_lan_1',
  '$icon_path',
	'$link_url',
	'on',
  '$title_lan_1',
  '$tool_tip_lan_1',
  '',
  '$title_lan_2',
  '$tool_tip_lan_2',
  '',
  '$title_lan_3',
  '$tool_tip_lan_3',
  '',
  '$title_lan_4',
  '$tool_tip_lan_4',
  '')") or die ("<b>A fatal MySQL error occured</b>.\n<br />Query: " . $sql_query . "<br />\nError: (" . mysql_errno() . ") " . mysql_error());;

	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "$parent` WHERE `description_lan_1` = '$description_lan_1'");
	while($sql_result = mysql_fetch_array($sql_query)) $id = $sql_result[id];

	//$page already exists - update data in database
} else {

	//new and old parent fields are the same - update existing entry
	if ($old_parent == $parent){

		//breakpoint($description_lan_1);

		// sort out order and type fields
		mysql_query("UPDATE `" . $db_table_prefix . "$parent` SET
		`date` = '$old_date',
		`order` = '$order',
		`child` = '$title_lan_1',
		`category` = '$title_lan_1',
		`link_url` = '$link_url',
		`title_lan_1` = '$title_lan_1',
		`tool_tip_lan_1` = '$tool_tip_lan_1',
		`title_lan_2` = '$title_lan_2',
		`tool_tip_lan_2` = '$tool_tip_lan_2',
		`title_lan_3` = '$title_lan_3',
		`tool_tip_lan_3` = '$tool_tip_lan_3',
		`title_lan_4` = '$title_lan_4',
		`tool_tip_lan_4` = '$tool_tip_lan_4' WHERE `id` = '$id'") or die ("<b>A fatal MySQL error occured</b>.\n<br />Query: " . $sql_query . "<br />\nError: (" . mysql_errno() . ") " . mysql_error());;


		//else parent fields are different
	} else {
		//so delete data from old table
		mysql_query("DELETE FROM `" . $db_table_prefix . "$old_parent` WHERE `id` = '$id'");

		//reorder id of old table by recreating field
		mysql_query("ALTER TABLE `" . $db_table_prefix . "$old_parent` DROP `id`");
		mysql_query("ALTER TABLE `" . $db_table_prefix . "$old_parent` ADD `id` MEDIUMINT( 16 ) NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST");

		//add data to new table
		mysql_query("INSERT INTO `" . $db_table_prefix . "$parent` VALUES(NULL,
    '$old_date',
    '$order',
    '$parent',
    '$title_lan_1',
    '$title_lan_1',
    '$old_image',
		'$link_url',
		'on',
    '$title_lan_1',
    '$tool_tip_lan_1',
    '',
    '$title_lan_2',
    '$tool_tip_lan_2',
    '',
    '$title_lan_3',
    '$tool_tip_lan_3',
    '',
    '$title_lan_4',
    '$tool_tip_lan_4',
    '')") or die ("<b>A fatal MySQL error occured</b>.\n<br />Query: " . $sql_query . "<br />\nError: (" . mysql_errno() . ") " . mysql_error());

		$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "$parent` WHERE `description_lan_1` = '$description_lan_1'") or die ("<b>A fatal MySQL error occured</b>.\n<br />Query: " . $sql_query . "<br />\nError: (" . mysql_errno() . ") " . mysql_error());
		while($sql_result = mysql_fetch_array($sql_query)) $id = $sql_result[id];
	}
}
?>