<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Check cookie for language
===========================================================================*/
if (!isset($_COOKIE["deeemm_language"])) {
  $language = '1';
  session_start();
  $_SESSION['language'] = $language;
  header("Cache-control: private"); //IE6 session control fix
  header('P3P: CP="NOI ADM DEV PSAi COM NAV OUR OTRo STP IND DEM"'); //bypass 3rd party policy
  setcookie("deeemm_language" ,$language ,time()+60*60*12*365 );
}
  elseif (isset($_COOKIE["deeemm_language"])) {
  session_start();
  header("Cache-control: private"); //IE6 session control fix
  $language = $_COOKIE["deeemm_language"];
}


//>set session info - set cookie = language
if ($page=="1" || $page=="2" || $page=="3" || $page=="4") {
  $language = $page;
  setcookie("deeemm_language" ,$language ,time()-1 );
  setcookie("deeemm_language" ,$language ,time()+60*60*12*365 );
  $page='';
}

/*===========================================================================
Get flag names from database

[FIXME] change to assoc array
===========================================================================*/
  $sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "admin` WHERE `id` = 0");
  while($sql_result = mysql_fetch_array($sql_query)) {
    $language_1_flag = $sql_result[language_1_flag];
    $language_2_flag = $sql_result[language_2_flag];
    $language_3_flag = $sql_result[language_3_flag];
    $language_4_flag = $sql_result[language_4_flag];
  }



/*===========================================================================
Select current langauge file
===========================================================================*/
$language_file = $abs_path . $language_dir . ${'language_' . $language} . '.php';
require $language_file;



?>