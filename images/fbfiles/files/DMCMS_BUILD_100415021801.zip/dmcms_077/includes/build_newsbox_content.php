<?php
defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

$value = NULL;

//===========================================================================
//>create newsbox article
//===========================================================================
foreach ($newsbox_libraries as $value){

	//>get newsbox title in current language from structure
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "structure` WHERE `table` = '$value'");
	while ($sql_result = mysql_fetch_array($sql_query)){
  $newsbox_item_title = $sql_result[category_lan_ . $language];
  $newsbox_article = $sql_result[table];
	}

	//>get total number of articles in table
	$sql_result = mysql_query("select count(*) from `" . $db_table_prefix . "$value`");
	$num_newsarticles = mysql_result($sql_result,0);

	if ($num_newsarticles > 0) {

  //>read template + add to newsbox list
  $content = $default_url . $templates_dir . "newsbox.tpl";
  $newsbox .= read_file($content);

  //>get latest article
  $sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "$value` ORDER BY `date` DESC LIMIT 1");
  while($sql_result = mysql_fetch_array($sql_query)){
  	$news_image = $media_dir . $sql_result[image];
  	$headline_text = strip_tags($sql_result[title_lan_ . $language]);
  	$tool_tip = strip_tags($sql_result[tool_tip_lan_ . $language]);
  	$story_text = strip_tags($sql_result[description_lan_ . $language]);
  	$story_id = strip_tags($sql_result[id]);
  	$newsbox_item_date = strftime("%a %d %b  %Y", strtotime($sql_result[date]));
  }

  //>truncate characters and add link
  if(strlen($story_text) > 140) {
	  $story_text = truncate($story_text, 210);
	  $story_text = balanceTags($story_text);
	  $story_text .= '<A class="float_right" title="' . $tool_tip . '" href="' . $default_url . '?page=' .$value . '&amp;id=' . $story_id . '"> ...Read More</A><BR /><BR />';
  }
  $newsbox = replace_variables($newsbox);
	} else {
		$headline_text = $lan[no_news];
	}

}

$value = NULL;

?>