<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Check user priviledges
===========================================================================*/
require VALIDATE;

if ($user != 'ADMIN') header("Location: " . $default_url . "index.php");



$content = "templates/admin_mod_categories.tpl";
$main = read_file($content);

/*===========================================================================
Propogate the site map
============================================================================*/

//generate list with links for modifying category
foreach($all_tables as $value){
	$tables_list = '';
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "structure` WHERE `table` = '$value'");
	while($sql_result = mysql_fetch_array($sql_query)){
		$type = $sql_result[type];
		$media_library_default_view = $sql_result[media_library_default_view];
		$num_slideshow_images = $sql_result[num_slideshow_images];
		$imagebox_type = $sql_result[imagebox_type];
		$display_in_margin = $sql_result[display_in_margin];
		$display_in_sitemap = $sql_result[display_in_sitemap];
		$allow_comments = $sql_result[allow_comments];
		$category = $sql_result[category_lan_ . $language];
	}
}


$editing_category_message = $lan[editing_category_message];


/*===========================================================================
Generate the category type drop down menu
===========================================================================*/
$category_type = '';

$type = 'normal'; //set default list type to display

//get current type
$sql_query  = mysql_query("SELECT * FROM `" . $db_table_prefix . "structure` WHERE `table` LIKE '$category'");

while ($sql_result = mysql_fetch_array($sql_query)){
	$type = $sql_result[type];
}

//get all possible types from database + active type
$sql_query  = mysql_query("SHOW COLUMNS FROM `" . $db_table_prefix . "structure` LIKE 'type'");
$sql_result = mysql_fetch_row($sql_query);
preg_match_all("/'(.*?)'/", $sql_result[1], $temp_array);
$category_types = array_unique($temp_array);
sort($category_types);

//create drop down list
$category_type = "<select class='w100pcnt' name='category_type' onchange='setup_categories_form()'>". $crlf . "<option value='$type'>$type</option>" . $crlf;
foreach($category_types[0] as $value) {
	$value = str_replace('\'', '', $value);
	if ($value != $type){
		$category_type .= "<option value='$value'>$value</option>";
	}
}
$category_type = str_replace('  ', '', $category_type);
$category_type .= '</select>';


$sitemap_editor = replace_variables($sitemap_editor);


?>
