<?php
defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

$admin_email = convert2ascii($admin_email);

/*===========================================================================
Get site structure from database
===========================================================================*/
/*
$sql_query = mysql_query("SHOW TABLES");
while($sql_result = mysql_fetch_array($sql_query)){
	if ($sql_result[0] <> $db_table_prefix .'admin' && $sql_result[0] <> $db_table_prefix .'static_content' && $sql_result[0] <> $db_table_prefix .'admin' && $sql_result[0] <> $db_table_prefix .'users' && $sql_result[0] <> $db_table_prefix .'structure')
	$all_tables[] .= $sql_result[0];
}
*/

/*===========================================================================
Get site structure from database
===========================================================================*/
//count number of tables in structure
$sql_result = mysql_query("SELECT count(*) from `" . $db_table_prefix . "structure`");
$num_tables = @mysql_result($sql_result,0);

//create array of ALL pages in structure
$all_tables = array();
$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "structure` ORDER BY `order`");
while($sql_result = mysql_fetch_array($sql_query)){
	$all_tables[] .= $sql_result[table];
}

//create array of all MEDIA pages in structure
unset($imagebox_libraries);
$media_tables = array();
$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "structure` WHERE `type` = 'media' ORDER BY `order`");
while($sql_result = mysql_fetch_array($sql_query)){
	$media_tables[] .= $sql_result[table];
	//create array of all imagebox libraries
	if ($sql_result[display_in_margin] == 'on'){
		$imagebox_libraries[] .= $sql_result[table];
	}
}

//create array of all unique CATEGORIES in MEDIA LIBRARIES
$media_categories = array();
foreach($media_tables as $value){
	$sql_query = mysql_query("SELECT DISTINCT `category` FROM `" . $db_table_prefix . $value . "`");
	while($sql_result = mysql_fetch_array($sql_query)){
		if (!in_array($sql_result[category], $media_categories)){
			$media_categories[] .= $sql_result[category];
		}
	}
}

//create array of all LIST pages in structure
unset($newsbox_libraries);
$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "structure` WHERE `type` LIKE 'list' ORDER BY `order`");
while($sql_result = mysql_fetch_array($sql_query)){
	$list_tables[] .= $sql_result[table];
	//create array of all newsbox libraries
	if ($sql_result[display_in_margin] == 'on'){
		$newsbox_libraries[] .= $sql_result[table];
	}
}

//create array of all NORMAL pages in structure
$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "structure` WHERE `type` = 'normal' ORDER BY `order`");
while($sql_result = mysql_fetch_array($sql_query)){
	$normal_tables[] .= $sql_result[table];
}

//create array of all STATIC pages
$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "static_content`");
while($sql_result = mysql_fetch_array($sql_query)){
	$static_pages[] .= $sql_result[category];
}


/*===========================================================================
Get site status from database

[FIXME]change to assoc array to allow for dynamically adding settings
===========================================================================*/
$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "admin` WHERE `id` = 0");
while($sql_result = mysql_fetch_array($sql_query)){
	$version = $sql_result[version];
	$site_name = $sql_result[site_name];
	$site_description = $sql_result[site_description];
	$site_is_active = $sql_result[site_is_active];
	$db_editor_path = $sql_result[db_editor_path];
	$login_link_enabled = $sql_result[login_link_enabled];
	$admin_email = $sql_result[admin_email];
	$multi_language = $sql_result[multi_language];
	$search_enabled = $sql_result[search_enabled];
	$forum_enabled = $sql_result[forum_enabled];
	$forum_name = $sql_result[forum_name];
	$forum_path = $sql_result[forum_path];
	$forum_search_url = $sql_result[forum_search_url];
	$current_template = $sql_result[current_template];
	$hitcount = $sql_result[hitcount];
	$language_1 = $sql_result[language_1];
	$language_2 = $sql_result[language_2];
	$language_3 = $sql_result[language_3];
	$language_4 = $sql_result[language_4];
}

$templates_dir .=  $current_template . '/';




/*===========================================================================
Hitcounter
===========================================================================*/
if (!isset($_COOKIE['hitcounted'])) {
	++$hitcount;
	mysql_query("UPDATE `" . $db_table_prefix . "admin` SET	`hitcount` = '$hitcount'");
	setcookie("hitcounted" ,$hitcount );
}

?>