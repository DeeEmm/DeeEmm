<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );


/*===========================================================================
Check user priviledges
===========================================================================*/
require VALIDATE;

if ($user != 'ADMIN') header("Location: " . $default_url . "index.php");

/*===========================================================================
Get page details
===========================================================================*/
$page_title .= ' :: ' . $lan[site_administration];
$cookie_trial .= ' :: ' . $lan[site_administration];
$admin_title = $lan[change_site_settings];
$content = "templates/admin_mod_settings.tpl";
$main = read_file($content);

/*===========================================================================
Get administration functions
===========================================================================*/
if ($site_is_active) $main = str_replace('[var]site_is_active[/var]', 'checked="true"', $main);
if ($multi_language) $main = str_replace('[var]multi_language[/var]', 'checked="true"', $main);
if ($search_enabled) $main = str_replace('[var]search_enabled[/var]', 'checked="true"', $main);
if ($forum_enabled) $main = str_replace('[var]forum_enabled[/var]', 'checked="true"', $main);
if ($login_link_enabled) $main = str_replace('[var]login_link_enabled[/var]', 'checked="true"', $main);

/*===========================================================================
Get installed templates
===========================================================================*/
$directory = @opendir('../templates');
while(false !== ($file = readdir( $directory))) {
	if(!strpos($file, '.') && $file != '.' && $file != '..'){
		$templates_array[].= $file;
	}
}
closedir($directory);

//Get current template from database

$templates_list = "<select style='width:300px; float:right' name='current_template'>". $crlf . "<option selected value='$current_template'>$current_template</option>" . $crlf;

//create templates drop down
foreach($templates_array as $value){
	if ($value <> $current_template){
		$templates_list .= "<option value='$value'>$value</option>";
	}
}

$templates_list = str_replace('  ', '', $templates_list);
$templates_list .= '</select>';

/*===========================================================================
Get saved backups
===========================================================================*/
$backups_array = array();
$directory = @opendir('../db_backups');
	while(false !== ($file = readdir( $directory))) 
	{
		if((strpos($file, '.sql') || strpos($file, '.SQL'))&& $file != '.' && $file != '..')
		{
			$db_backup_list .= '<span style="float:right"><a href="' . $default_url . $admin_dir . 'index.php?action=restore_db&db_filename=' . $file . '"> Restore </a>|<a href="' . $default_url . $admin_dir .'index.php?action=delete_db&db_filename=' . $file . '"> Delete </a></span><a href="' . $default_url . $db_backup_dir . $file . '"><b>' . $file . '</b></a><small><em> Saved on ' . date("d F Y \\a\\t H:i:s", filemtime('../db_backups/' . $file)) . '</small></em><br>';
		}
	}
closedir($directory);

/*===========================================================================
Check for remote update
===========================================================================*/
/*if ($version_check_enabled)
{
	$current_version = (int) str_replace('.', '', $version);

	//get latest version
	if ($latest_version = file_get_contents("http://www.deeemm.com/broadcast/dmcms_latest_version.txt"))
	{
		//compare versions
		if ($latest_version > $current_version)
		{
			$update_check = '<span style="color:red">VERSION ' . $latest_version .  ' NOW AVAILABLE! CLICK <span style="color:blue"><a href="http://sourceforge.net/project/platformdownload.php?group_id=189064">HERE</a></span> TO DOWNLOAD.</span>';
		} ELSE {
			$update_check = '<span style="color:Green">THIS DMCMS INSTALLATION IS UP TO DATE</span>';
		}
	} else {
		$update_check = '<span style="color:red">UPDATE SERVER UNREACHABLE - PLEASE CHECK LATER</span>';
	}
}*/


/*===========================================================================
Check for remote news
===========================================================================*/
if ($remote_support_enabled)
{

//	$dmcms_support = '<iframe width=100% frameborder="0" src="http://www.deeemm.com/broadcast/dmcms_support.htm"> Sorry, your browser cannot display IFrames.</iframe>';

}
	
/*===========================================================================
Check if update available
===========================================================================*/
//need to add more checks for correct file etc
$updates_dir = $abs_path . $updates_dir;
$directory = @opendir($updates_dir);
while(false !== ($file = readdir($directory))) {
	if(strpos($file, '.') && $file != '.' && $file != '..'){
		$update_file = $_REQUEST["update_file"];
		$current_version = (int) str_replace('.', '', $version);
		$filename_part = explode('-', $file);
		$update_from = (int) $filename_part[1];
		$update_to = (int) $filename_part[2];

		if ($update_to > $current_version && $update_from == $current_version) {
			if ($update_file == $file) {
				echo '<div style="background:red; color:white; font-weight:bold; padding-left:10px; padding-right:10px; border: 2px solid black"><br>';
				echo 'Update file -> ' . $update_file . '<br><br>';
				require 'updates/' . $file;
				echo '<br>Database Updated Successfully !!<br><br><a href="./index.php?action=edit_settings">Click here to return to the Administration Panel<br><br>';
				echo '</div>';
				exit;
			} else {
				echo '<div style="background:red; color:white; font-weight:bold; padding-left:10px; padding-right:10px; border: 2px solid black; font:arial"><br>';
				echo "<FORM style=\"float:right\" action=\"./$default_url"."index.php?action=edit_settings&update_file=$file\" method=\"post\">";
				echo '  <input style="width:78px" border="0" TYPE="submit" value="Update">';
				echo '</FORM>';
				echo '!!!!! If you have uploaded the version ' . $filename_part[2] . ' updated files, press the button to update the database<br><br>';
				echo '</div>';
				exit;
			}
		}
	}
}
closedir($directory);

	

?>
