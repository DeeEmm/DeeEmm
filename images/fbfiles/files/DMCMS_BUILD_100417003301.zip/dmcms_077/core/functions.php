<?php
defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );


/*===========================================================================
Read URL result into string
===========================================================================*/
function read_url ($file_name) {
	$html_file=fopen($file_name,"r");
	if(!$html_file){
		echo '<br><br> ' . $file_name . 'is not responding at the moment.';
	}
	while(!feof($html_file)){
		$decoded_html.=fgets($html_file,255);
	}
	fclose($html_file);
	return $decoded_html;
}


/*===========================================================================
Write string into a file
===========================================================================*/
function write_file ($filename, $string) {
	$buffer = fopen($filename, 'w');
	fwrite($buffer, $string);
	fclose($buffer);
}


/*===========================================================================
Read a file into a string
===========================================================================*/
function read_file ($file_name) {
	global $status_mssg;
	$str_template = '';
	$buffer = fopen($file_name, 'r');
	if(!is_resource($buffer)) {
		//    $status_mssg = 'Sorry. Template file ' . $file_name . ' does not exist</BR>';
	}
	while($str_file = fread($buffer, 2048)) {
		$str_template .= $str_file;
	}
	fclose($buffer);
	return $str_template;
}


/*===========================================================================
Upload file
===========================================================================*/
function upload_file ($destination_filepath, $form_name) {
	$filename = strtolower(basename($_FILES[$form_name]['name']));
	$new_filename = $filename;

	if ($filename) {
		$destination_file = $destination_filepath . $filename;
	}

	if (file_exists($destination_file)) {
		$count = 1;
		while(file_exists($destination_file)) {
			$new_filename = $count . '_' .  $filename;
			$destination_file = $destination_filepath . $new_filename;
			$count++;
		}
	}

	if ($filename && !file_exists($destination_file)) {
		if (!move_uploaded_file($_FILES[$form_name]['tmp_name'], $destination_file)) {
			echo '<br>' . "Upload failed!" .'<br>';
			echo $destination_file .'<br>';
			echo ($_FILES[$form_name]['name']) .'<br>';
			echo ($_FILES[$form_name]['tmp_name']) .'<br>';
			echo ($_FILES[$form_name]['size']) .'<br>';
			echo ($_FILES[$form_name]['type']) .'<br>';
			echo ($_FILES[$form_name]['error']) .'<br>';
			//print_r ($_FILES);
			exit;
		}
	}

	//check file upload ok
	if ($_FILES[$form_name]['error'] == 0 ){
		return $new_filename;
	} else {
		return  FALSE;
	}
	exit;
}

/*===========================================================================
Truncate string
===========================================================================*/
function truncate ($str, $length=100, $trailing='...') {
	// take off chars for the trailing
	$length-=strlen($trailing);
	if (strlen($str) > $length)
	{
		// string exceeded length, truncate and add trailing dots
		return substr($str,0,$length).$trailing;
	}
	else
	{
		// string was already short enough, return the string
		$res = $str;
	}
	return $res;
}


/*===========================================================================
Breakpoint - test / debug function
===========================================================================*/
function breakpoint($var) {
	echo 'Break on line ' . __LINE__ . ' of ' . __FILE__ . '<BR>';
	if (isset($var)) {
		if (is_array($var)){
			for ($i=0;$i<count($var);$i++){
				echo $var[$i] . '<BR>';
			}
		} else {
			echo $var . '<BR>';
		}
	}
	exit;
}

/*===========================================================================
Convert2ascii (convert string to ascii)
===========================================================================*/
function convert2ascii($input_string)
{
	$converted_string = '';
	$length = strlen($input_string);
	for ($i = 0; $i < $length; $i++) {
		$converted_string .= "&#".ord($input_string[$i]).";";
	}
	return $converted_string;
}


/*===========================================================================
Convert text for rich text editor
===========================================================================*/
function rteSafe($strText) {
	//returns safe code for preloading in the RTE
	$tmpString = $strText;

	//convert all types of single quotes
	$tmpString = str_replace(chr(145), chr(39), $tmpString);
	$tmpString = str_replace(chr(146), chr(39), $tmpString);
	$tmpString = str_replace("'", "&#39;", $tmpString);

	//convert all types of double quotes
	$tmpString = str_replace(chr(147), chr(34), $tmpString);
	$tmpString = str_replace(chr(148), chr(34), $tmpString);

	//replace carriage returns & line feeds
	$tmpString = str_replace(chr(10), " ", $tmpString);
	$tmpString = str_replace(chr(13), " ", $tmpString);

	return $tmpString;
}

/*===========================================================================
Convert text for xml files
===========================================================================*/
function xmlSafe($strText) {
	//replace illegal characters for use in xml filetypes
	$tmpString = $strText;

	$tmpString = str_replace('&', '&amp;', $tmpString);
	$tmpString = str_replace('<', '&ls;', $tmpString);
	$tmpString = str_replace('>', '&gt;', $tmpString);
	$tmpString = str_replace('"', '&quot;', $tmpString);
	$tmpString = str_replace("'", '&apos;', $tmpString);

	return $tmpString;
}

/*===========================================================================
Replace variables
===========================================================================*/
function replace_variables($input_text) {
	$temp_text = $input_text;

	//replace variables
	preg_match_all('/\[var\](.*?)\[\/var\]/', $temp_text, $temp_array);
	foreach ($temp_array[1] as $marker) {
		$variable_marker = strtolower($marker);
		global ${$variable_marker};
		if (!get_magic_quotes_gpc()) {
			$input_text = str_replace( '[var]'.$marker.'[/var]', ${$variable_marker}, $input_text);
		} else {
			$input_text = str_replace( '[var]'.$marker.'[/var]', ${$variable_marker}, $input_text);
		}
	}

	//replace language elements
	preg_match_all('/\[lan\](.*?)\[\/lan\]/', $temp_text, $temp_array);
	foreach ($temp_array[1] as $marker) {
		$language_marker = strtolower($marker);
		global $lan;
		if (!get_magic_quotes_gpc()) {
			$input_text = str_replace( '[lan]'.$marker.'[/lan]', $lan[$language_marker], $input_text);
		} else {
			$input_text = str_replace( '[lan]'.$marker.'[/lan]', $lan[$language_marker], $input_text);
		}
	}

	//replace masked elements (replace text between tags with ascii values)
	preg_match_all('/\[mask\](.*?)\[\/mask\]/', $temp_text, $temp_array);
	foreach ($temp_array[1] as $marker) {
		$mask_marker = strtolower($marker);
		$input_text = str_replace( '[mask]'.$marker.'[/mask]', convert2ascii($mask_marker), $input_text);
	}

	return $input_text;
}

//match html tag regex '/\<mytag([^>]*)\>(.*?)\<\/mytag\>/is'


/*===========================================================================
Replace language
===========================================================================*/
function replace_language($input_text) {
	$temp_text = $input_text;

	//replace language elements
	preg_match_all('/\[lan\](.*?)\[\/lan\]/', $temp_text, $temp_array);
	foreach ($temp_array[1] as $marker) {
		$language_marker = strtolower($marker);
		global $lan;
		if (!get_magic_quotes_gpc()) {
			$input_text = str_replace( '[lan]'.$marker.'[/lan]', addslashes($lan[$language_marker]), $input_text);
		} else {
			$input_text = str_replace( '[lan]'.$marker.'[/lan]', $lan[$language_marker], $input_text);
		}
	}
	return $input_text;
}

/*===========================================================================
Replace DM Code markers.

Code marker whitelist stored in templates directory - dm.code
Allows control of variables used within template system
===========================================================================*/
function replace_dm_code($input_text) {
	global $core_dir;
	global $templates_dir;
	
	$temp_text = $input_text;

	//>replace 'dm code' (same as replace vars but only for allowed variables)
	preg_match_all('/\[dm\](.*?)\[\/dm\]/', $temp_text, $temp_array);
	foreach ($temp_array[1] as $marker) {
		$variable_marker = strtolower($marker);
		//get allowed variables from file
		$dm_code = read_file($templates_dir  . "dm.code");
		if(stristr($dm_code, $marker)) {
			global ${$variable_marker};
			if (!get_magic_quotes_gpc()) {
				$input_text = str_replace( '[dm]'.$marker.'[/dm]', addslashes(${$variable_marker}), $input_text);
			} else {
				$input_text = str_replace( '[dm]'.$marker.'[/dm]', ${$variable_marker}, $input_text);
			}
		}
	}


	return $input_text;
}


/*===========================================================================
Balance tags

Closes opened tags - for use with truncated text

Version 1.5 - 01 July 2006
Modified By Mick Percy (DeeEmm) for use with DMCMS

- Removed references to WP variables

Based on version obtained from :-
http://www.coffee2code.com/wp-content/files/fixed-balanceTags.phps

Original header...

===========================================================================

balanceTags

Balances Tags of string using a modified stack.

@param text      Text to be balanced
@return          Returns balanced text
@author          Leonard Lin (leonard@acm.org)
@version         v1.1
@date            November 4, 2001
@license         GPL v2.0
@notes
@changelog


===========================================================================

Modified by Scott Reilly (coffee2code) 02 Aug 2004
1.2  ***TODO*** Make better - change loop condition to $text
1.1  Fixed handling of append/stack pop order of end text
Added Cleaning Hooks
1.0  First Version
	 
===========================================================================*/
function balanceTags($text, $is_comment = 0) {

	$tagstack = array(); $stacksize = 0; $tagqueue = ''; $newtext = '';

	# WP bug fix for comments - in case you REALLY meant to type '< !--'
	$text = str_replace('< !--', '<    !--', $text);
	# WP bug fix for LOVE <3 (and other situations with '<' before a number)
	$text = preg_replace('#<([0-9]{1})#', '&lt;$1', $text);

	while (preg_match("/<(\/?\w*)\s*([^>]*)>/",$text,$regex)) {
  $newtext .= $tagqueue;

  $i = strpos($text,$regex[0]);
  $l = strlen($regex[0]);

  // clear the shifter
  $tagqueue = '';
  // Pop or Push
  if ($regex[1][0] == "/") { // End Tag
  	$tag = strtolower(substr($regex[1],1));
  	// if too many closing tags
  	if($stacksize <= 0) {
  		$tag = '';
  		//or close to be safe $tag = '/' . $tag;
  	}
  	// if stacktop value = tag close value then pop
  	else if ($tagstack[$stacksize - 1] == $tag) { // found closing tag
  		$tag = '</' . $tag . '>'; // Close Tag
  		// Pop
  		array_pop ($tagstack);
  		$stacksize--;
  	} else { // closing tag not at top, search for it
  		for ($j=$stacksize-1;$j>=0;$j--) {
  			if ($tagstack[$j] == $tag) {
  				// add tag to tagqueue
  				for ($k=$stacksize-1;$k>=$j;$k--){
  					$tagqueue .= '</' . array_pop ($tagstack) . '>';
  					$stacksize--;
  				}
  				break;
  			}
  		}
  		$tag = '';
  	}
  } else { // Begin Tag
  	$tag = strtolower($regex[1]);

  	// Tag Cleaning

  	// If self-closing or '', don't do anything.
  	if((substr($regex[2],-1) == '/') || ($tag == '')) {
  	}
  	// ElseIf it's a known single-entity tag but it doesn't close itself, do so
  	elseif ($tag == 'br' || $tag == 'img' || $tag == 'hr' || $tag == 'input') {
  		$regex[2] .= '/';
  	} else {    // Push the tag onto the stack
  		// If the top of the stack is the same as the tag we want to push, close previous tag
  		if (($stacksize > 0) && ($tag != 'div') && ($tagstack[$stacksize - 1] == $tag)) {
  			$tagqueue = '</' . array_pop ($tagstack) . '>';
  			$stacksize--;
  		}
  		$stacksize = array_push ($tagstack, $tag);
  	}

  	// Attributes
  	$attributes = $regex[2];
  	if($attributes) {
  		$attributes = ' '.$attributes;
  	}
  	$tag = '<'.$tag.$attributes.'>';
  	//If already queuing a close tag, then put this tag on, too
  	if ($tagqueue) {
  		$tagqueue .= $tag;
  		$tag = '';
  	}
  }
  $newtext .= substr($text,0,$i) . $tag;
  $text = substr($text,$i+$l);
	}

	// Clear Tag Queue
	$newtext .= $tagqueue;

	// Add Remaining text
	$newtext .= $text;

	// Empty Stack
	while($x = array_pop($tagstack)) {
  $newtext .= '</' . $x . '>'; // Add remaining tags to close
	}

	// WP fix for the bug with HTML comments
	$newtext = str_replace("< !--","<!--",$newtext);
	$newtext = str_replace("<    !--","< !--",$newtext);

	return $newtext;
}

/*===========================================================================
Strip html

 created from code obtained from :-
 http://www.zend.com/manual/function.preg-replace.php

 This will remove HTML tags, javascript sections and white space. It will also
 convert some common HTML entities to their text equivalent.
===========================================================================*/

function strip_html($text) {
	$search = array ('@<script[^>]*?>.*?</script>@si', // Strip out javascript
	'@<[\/\!]*?[^<>]*?>@si',          // Strip out HTML tags
	'@([\r\n])[\s]+@',                // Strip out white space
	'@&(quot|#34);@i',                // Replace HTML entities
	'@&(amp|#38);@i',
	'@&(lt|#60);@i',
	'@&(gt|#62);@i',
	'@&(nbsp|#160);@i',
	'@&(iexcl|#161);@i',
	'@&(cent|#162);@i',
	'@&(pound|#163);@i',
	'@&(copy|#169);@i',
	'@&#(\d+);@e');                    // evaluate as php

	$replace = array ('',
	'',
	'\1',
	'"',
	'&',
	'<',
	'>',
	' ',
	chr(161),
	chr(162),
	chr(163),
	chr(169),
	'chr(\1)');

	$text = preg_replace($search, $replace, $text);
	return $text;
}

/*===========================================================================
Protect user inputted text against injection
===========================================================================*/
function anti_inject($value) {	
	
	if(strpos($value,"'")) {
		echo 'Possible Hack Attempt';
		exit;
	}	
	
	if(get_magic_quotes_gpc()) {
		$value = stripslashes($value);
	}
	if(function_exists("mysql_real_escape_string") && (!is_numeric($value))) {
		$value = mysql_real_escape_string($value);
	} else {
		//for PHP version < 4.3.0 use addslashes
		$value = addslashes($value);
	}
	return $value;
}


/*===========================================================================
Image create from bmp function (tried to use for bmp/thumbnails but does not work)


Original header...

Fonction: ImageCreateFromBMP              
Author:  DHKold                          
Contact:  admin@dhkold.com                
Date:    The 15th of June 2005          
Version:  2.0B                            

===========================================================================*/


function ImageCreateFromBMP($filename)
{
 //Ouverture du fichier en mode binaire
 if (! $f1 = fopen($filename,"rb")) return FALSE;

 //1 : Chargement des ent?tes FICHIER
 $FILE = unpack("vfile_type/Vfile_size/Vreserved/Vbitmap_offset", fread($f1,14));
 if ($FILE['file_type'] != 19778) return FALSE;

 //2 : Chargement des ent?tes BMP
 $BMP = unpack('Vheader_size/Vwidth/Vheight/vplanes/vbits_per_pixel'.
 '/Vcompression/Vsize_bitmap/Vhoriz_resolution'.
 '/Vvert_resolution/Vcolors_used/Vcolors_important', fread($f1,40));
 $BMP['colors'] = pow(2,$BMP['bits_per_pixel']);
 if ($BMP['size_bitmap'] == 0) $BMP['size_bitmap'] = $FILE['file_size'] - $FILE['bitmap_offset'];
 $BMP['bytes_per_pixel'] = $BMP['bits_per_pixel']/8;
 $BMP['bytes_per_pixel2'] = ceil($BMP['bytes_per_pixel']);
 $BMP['decal'] = ($BMP['width']*$BMP['bytes_per_pixel']/4);
 $BMP['decal'] -= floor($BMP['width']*$BMP['bytes_per_pixel']/4);
 $BMP['decal'] = 4-(4*$BMP['decal']);
 if ($BMP['decal'] == 4) $BMP['decal'] = 0;

 //3 : Chargement des couleurs de la palette
 $PALETTE = array();
 if ($BMP['colors'] < 16777216)
 {
 	$PALETTE = unpack('V'.$BMP['colors'], fread($f1,$BMP['colors']*4));
 }

 //4 : Cr?ation de l'image
 $IMG = fread($f1,$BMP['size_bitmap']);
 $VIDE = chr(0);

 $res = imagecreatetruecolor($BMP['width'],$BMP['height']);
 $P = 0;
 $Y = $BMP['height']-1;
 while ($Y >= 0)
 {
 	$X=0;
 	while ($X < $BMP['width'])
 	{
 		if ($BMP['bits_per_pixel'] == 24)
 		$COLOR = unpack("V",substr($IMG,$P,3).$VIDE);
 		elseif ($BMP['bits_per_pixel'] == 16)
 		{
 			$COLOR = unpack("n",substr($IMG,$P,2));
 			$COLOR[1] = $PALETTE[$COLOR[1]+1];
 		}
 		elseif ($BMP['bits_per_pixel'] == 8)
 		{
 			$COLOR = unpack("n",$VIDE.substr($IMG,$P,1));
 			$COLOR[1] = $PALETTE[$COLOR[1]+1];
 		}
 		elseif ($BMP['bits_per_pixel'] == 4)
 		{
 			$COLOR = unpack("n",$VIDE.substr($IMG,floor($P),1));
 			if (($P*2)%2 == 0) $COLOR[1] = ($COLOR[1] >> 4) ; else $COLOR[1] = ($COLOR[1] & 0x0F);
 			$COLOR[1] = $PALETTE[$COLOR[1]+1];
 		}
 		elseif ($BMP['bits_per_pixel'] == 1)
 		{
 			$COLOR = unpack("n",$VIDE.substr($IMG,floor($P),1));
 			if    (($P*8)%8 == 0) $COLOR[1] =  $COLOR[1]        >>7;
 			elseif (($P*8)%8 == 1) $COLOR[1] = ($COLOR[1] & 0x40)>>6;
 			elseif (($P*8)%8 == 2) $COLOR[1] = ($COLOR[1] & 0x20)>>5;
 			elseif (($P*8)%8 == 3) $COLOR[1] = ($COLOR[1] & 0x10)>>4;
 			elseif (($P*8)%8 == 4) $COLOR[1] = ($COLOR[1] & 0x8)>>3;
 			elseif (($P*8)%8 == 5) $COLOR[1] = ($COLOR[1] & 0x4)>>2;
 			elseif (($P*8)%8 == 6) $COLOR[1] = ($COLOR[1] & 0x2)>>1;
 			elseif (($P*8)%8 == 7) $COLOR[1] = ($COLOR[1] & 0x1);
 			$COLOR[1] = $PALETTE[$COLOR[1]+1];
 		}
 		else
 		return FALSE;
 		imagesetpixel($res,$X,$Y,$COLOR[1]);
 		$X++;
 		$P += $BMP['bytes_per_pixel'];
 	}
 	$Y--;
 	$P+=$BMP['decal'];
 }

 //Fermeture du fichier
 fclose($f1);

 return $res;
}


/*===========================================================================
 //>miscellaneous / unused
 ===========================================================================*/

//$str = preg_replace('/\s\s+/', ' ', $str); // strip excess whitespace

?>