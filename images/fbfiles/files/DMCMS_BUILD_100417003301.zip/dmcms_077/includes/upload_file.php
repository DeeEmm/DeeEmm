<?php
defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );


//===========================================================================
//>check user priviledges
//===========================================================================
require 'validate.php';


//transfer file
$filename = strtolower(basename($_FILES['file_data']['name']));

if ($filename) {
	$destination_file = $default_url . $media_dir . $filename;
	echo strtolower(basename($_FILES['file_data']['name']));
}

if (file_exists($destination_file)) {
	$count = 1;
	while(file_exists($destination_file)) {
		$filename = $count . '_' .  $filename;
		$destination_file = $default_url . $media_dir . $filename ;
		$count++;
	}
}


if ($filename && !file_exists($destination_file)) {
	if (!move_uploaded_file($_FILES['file_data']['tmp_name'], $destination_file)) {
		echo '<br>' . "Upload failed!" .'<br>';
		echo $destination_file .'<br>';
		echo ($_FILES['file_data']['name']) .'<br>';
		echo ($_FILES['file_data']['tmp_name']) .'<br>';
		echo ($_FILES['file_data']['size']) .'<br>';
		echo ($_FILES['file_data']['type']) .'<br>';
		echo ($_FILES['file_data']['error']) .'<br>';
		//print_r ($_FILES);
		exit;
	}
}

//check file upload ok then update database
if ($_FILES['file_data']['error'] == 0 ){
	$file_uploaded = TRUE;
} else {
	$file_uploaded = FALSE;
	//file upload not ok
	header("Location: " . $default_url . $admin_dir . '$default_url"."index.php?page=messagebox&message=no_data');
	exit;
}
?>