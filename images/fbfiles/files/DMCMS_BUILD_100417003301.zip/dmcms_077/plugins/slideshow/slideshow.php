<?php
$INDM = TRUE;
defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );


/*===========================================================================
 //>required files
 ===========================================================================*/
require './initialise.php';
require './config.php';
require './functions.php';
require './db_access.php';
require './site_status.php';


$pattern="(\.jpg$)|(\.jpeg$)"; //valid image extensions

//echo file header
header('Content-Type: text/xml');
echo'<gallery timer="5" order="random" fadetime="3" looping="yes" xpos="0" ypos="0">';

$value = NULL;

foreach($imagebox_libraries as $value){

	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "structure` WHERE `table` = '$value'");
	while($sql_result = mysql_fetch_array($sql_query)){
		$media_library_enabled = $sql_result[media_library_enabled];
		$media_library_default_view = $sql_result[media_library_default_view];
		$num_slideshow_images = $sql_result[num_slideshow_images];
		$imagebox_type = $sql_result[imagebox_type];
	}

	//get imagelist from media library
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . $value . "` ORDER BY `date` DESC");
	$count = 0;
	while(($sql_result = @mysql_fetch_array($sql_query)) && ($count < $num_slideshow_images)){
		$slideshow_image_name = $sql_result[image];
		if(eregi($pattern, $slideshow_image_name)) {
			$count = $count + 1;
			$slideshow_image_title = $sql_result[title_lan_.$language];
			$slideshow_image_description = $sql_result[description_lan_.$language];
			$slideshow_image_num = $sql_result[id];
			$slideshow_image_name = $sql_result[image];

			echo"<image path='./" . $media_dir . "thumbnail.php?height=288&amp;width=432&amp;filename=" . $slideshow_image_name . "' link='$default_url" . "index.php?page=" . $value . "&amp;id=$slideshow_image_num' /> ";

		}
	}
}

echo'</gallery>';

$value = NULL;

?>