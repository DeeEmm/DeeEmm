/**
 * $Id: editor_plugin_src.js,v 1.2 2008/07/04 11:17:34 deeemm Exp $
 *
 * Experimental plugin for new Cleanup routine, this logic will be moved into the core ones it's stable enougth.
 *
 * @author Moxiecode
 * @copyright Copyright � 2004-2007, Moxiecode Systems AB, All rights reserved.
 */

/* Dummy file since cleanup is now moved to core */
