<?php
defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Check user priviledges
===========================================================================*/
require VALIDATE;

if ($user != 'ADMIN') header("Location: " . $default_url . "index.php");



//get user input
$site_name = $_REQUEST['site_name'];
$site_description = $_REQUEST['site_description'];
$site_is_active = $_REQUEST['site_is_active'];
$admin_email = $_REQUEST['admin_email'];
$db_editor_path = $_REQUEST['db_editor_path'];
$login_link_enabled = $_REQUEST['login_link_enabled'];
$multi_language = $_REQUEST['multi_language'];
$search_enabled = $_REQUEST['search_enabled'];
$forum_enabled = $_REQUEST['forum_enabled'];
$forum_name = $_REQUEST['forum_name'];
$forum_path = $_REQUEST['forum_path'];
$forum_search_url = $_REQUEST['forum_search_url'];
$current_template = $_REQUEST['current_template'];
$language_1 = $_REQUEST['language_1'];
$language_1_flag = $_REQUEST['language_1_flag'];
$language_2 = $_REQUEST['language_2'];
$language_2_flag = $_REQUEST['language_2_flag'];
$language_3 = $_REQUEST['language_3'];
$language_3_flag = $_REQUEST['language_3_flag'];
$language_4 = $_REQUEST['language_4'];
$language_4_flag = $_REQUEST['language_4_flag'];

//save stuff to database
mysql_query("UPDATE " . $db_table_prefix . "admin SET
`site_name` = '$site_name',
`site_description` = '$site_description',
`site_is_active` = '$site_is_active',
`db_editor_path` = '$db_editor_path',
`login_link_enabled` = '$login_link_enabled',
`admin_email` = '$admin_email',
`multi_language` = '$multi_language',
`search_enabled` = '$search_enabled',
`forum_enabled` = '$forum_enabled',
`forum_name` = '$forum_name',
`forum_path` = '$forum_path',
`forum_search_url` = '$forum_search_url',
`current_template` = '$current_template',
`language_1` = '$language_1',
`language_1_flag` = '$language_1_flag',
`language_2` = '$language_2',
`language_2_flag` = '$language_2_flag',
`language_3` = '$language_3',
`language_3_flag` = '$language_3_flag',
`language_4` = '$language_4',
`language_4_flag` = '$language_4_flag' WHERE `id` = 0");


?>