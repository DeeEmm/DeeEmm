<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Create / Initialise variables
===========================================================================*/

$main = '';
$page_title = '';
$cookie_trial = '';
$hidden_header = '';
$list_item_href = '';
$return_link = '';
$news_article_edit = '';
$list_article_edit = '';
$list_index_edit = '';
$media_library_index_edit = '';
$media_library_image_edit = '';
$media_href = '';
$admin_nav = '';
$h_nav_menu = '';
$v_nav_menu = '';


?>