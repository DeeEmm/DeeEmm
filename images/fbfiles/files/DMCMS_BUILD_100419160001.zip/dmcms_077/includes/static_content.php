<?php
defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

foreach($static_pages as $value){

	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "static_content` WHERE `category` = '$value'");
	while($sql_result = mysql_fetch_array($sql_query)){
		${$value.'_content'} = rtesafe($sql_result[description_lan_1]);
	}
}


?>