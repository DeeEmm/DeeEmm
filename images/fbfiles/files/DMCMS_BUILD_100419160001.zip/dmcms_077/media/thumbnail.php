<?php

//===========================================================================
//>generate thumbnail image.
//===========================================================================
$src_pic_url = $_GET["filename"];
$thumb_width = $_GET["width"];
$thumb_height = $_GET["height"];

$thumb = imagecreatetruecolor($thumb_width, $thumb_height);

$image_type = strrchr($src_pic_url, '.');


if (list($src_width, $src_height) = getimagesize($src_pic_url)) {

  switch ($image_type) {

  	case '.jpg';
      header('Content-type: image/jpeg');
      $src_image = imagecreatefromjpeg($src_pic_url);
      imagecopyresampled($thumb, $src_image, 0, 0, 0, 0, $thumb_width, $thumb_height, $src_width, $src_height);
      ImageJPEG($thumb, null, 100);
  	break;

  	case '.gif';
      header('Content-type: image/gif');
      $src_image = imagecreatefromgif($src_pic_url);
      imagecopyresampled($thumb, $src_image, 0, 0, 0, 0, $thumb_width, $thumb_height, $src_width, $src_height);
      Imagegif($thumb, null, 100);
  	break;

  	case '.png';
      header('Content-type: image/png');
      $src_image = imagecreatefrompng($src_pic_url);
      imagecopyresampled($thumb, $src_image, 0, 0, 0, 0, $thumb_width, $thumb_height, $src_width, $src_height);
      Imagepng($thumb);
  	break;

  	default;
      $white = imagecolorallocate($thumb, 0xFF, 0xFF, 0xFF);
      imagestring($thumb,2,2,2,$src_pic_url, $white);
      imagestring($thumb,2,2,15,'not found', $white);
      imageGIF($thumb);
  }

} else {
  $white = imagecolorallocate($thumb, 0xFF, 0xFF, 0xFF);
  imagestring($thumb,2,2,2,$src_pic_url, $white);
  imagestring($thumb,2,2,15,'not found', $white);
  imageGIF($thumb);
}



imagedestroy($thumb);

?>