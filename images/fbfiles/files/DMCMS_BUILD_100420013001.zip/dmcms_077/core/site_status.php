<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Get site status from database

[FIXME]change to assoc array to allow for dynamically adding settings
===========================================================================*/
$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "core_settings` WHERE `id` = 0");
while($sql_result = mysql_fetch_array($sql_query)){
	$version = $sql_result[version];
	$site_name = $sql_result[site_name];
	$site_description = $sql_result[site_description];
	$site_is_active = $sql_result[site_is_active];
	$db_editor_path = $sql_result[db_editor_path];
	$login_link_enabled = $sql_result[login_link_enabled];
	$admin_email = $sql_result[admin_email];
	$multi_language = $sql_result[multi_language];
	$search_enabled = $sql_result[search_enabled];
	$forum_search_url = $sql_result[forum_search_url];
	$current_template = $sql_result[current_template];
	$hitcount = $sql_result[hitcount];
	$language_1 = $sql_result[language_1];
	$language_2 = $sql_result[language_2];
	$language_3 = $sql_result[language_3];
	$language_4 = $sql_result[language_4];
}

$templates_dir .=  $current_template . '/';




/*===========================================================================
Hitcounter
===========================================================================*/
if (!isset($_COOKIE['hitcounted'])) {
	++$hitcount;
	mysql_query("UPDATE `" . $db_table_prefix . "core_settings` SET	`hitcount` = '$hitcount'");
	setcookie("hitcounted" ,$hitcount );
}

?>