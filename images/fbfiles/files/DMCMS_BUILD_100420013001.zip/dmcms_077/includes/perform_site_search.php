<?php
defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );


//===========================================================================
//>perform site search
//===========================================================================

$page = 'search';
$search_matches = 0;
$search_result = 0;
$search_results_page = 0;
$search_result_start = 1;

$search_results_page = mysql_escape_string(stripslashes($_REQUEST['search_results_page']));

$content = $default_url . $templates_dir  . "search.tpl";
$main = read_file($content);
$content = $default_url . $templates_dir  . "search_results.tpl";


//get all search results
for($count=0;$count<$num_tables+1;$count++){
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . $all_tables[$count] . "` WHERE `title_lan_" . $language . "` LIKE '%" . $search_text . "%' OR `description_lan_" . $language . "` LIKE '%" . $search_text . "%' ORDER BY `date` DESC");
	while($sql_result = @mysql_fetch_array($sql_query)){

		$sql_query2 = mysql_query("SELECT * FROM `" . $db_table_prefix . "core_structure` WHERE `table` = '$all_tables[$count]'");
		while($sql_result2 = mysql_fetch_array($sql_query2)) {
			$type = $sql_result2[type];
		}
		$search_matches = $search_matches + 1;

		$search_result = read_file($content);

		if ($type=='list' || $type=='list + newsbox' ){
			$search_item_href = 'index.php?page='.$all_tables[$count].'&amp;id=' . $sql_result[id];
		} elseif ($type=='media'){
			$search_item_href = 'index.php?page='.$all_tables[$count].'&amp;id=' . $sql_result[id];
		} else {
			$search_item_href = 'index.php?page='.$all_tables[$count].'&amp;id='. $sql_result[id];
		}

		//format text for search result
		//			$formatted_search_result = balanceTags(truncate($sql_result[description_lan_.$language], $search_result_length));
		//	    $formatted_search_result = preg_replace('/\n|\r|\n\r/',' ',$formatted_search_result);
		$formatted_search_result = strip_tags(balanceTags(truncate($sql_result[description_lan_.$language], $search_result_length)));
		$search_result = str_replace('[var]search_item_href[/var]', $search_item_href, $search_result);
		$search_result = str_replace('[var]search_date[/var]', strftime("%a %d %b %y", strtotime($sql_result[date])), $search_result);
		$search_result = str_replace('[var]search_title[/var]', $search_matches .'. '. $sql_result[parent] . ' > ' . $sql_result[title_lan_.$language], $search_result);
		$search_result = str_replace('[var]search_body[/var]', $formatted_search_result, $search_result);
		//      $search_result = str_replace($search_text, '<span class="highlight">'.$search_text.'</span>', $search_result);

		$search_results_array[] .= $search_result;
	}
}


if ($search_results_page > 1){
	$search_result_start = ($search_results_page - 1) * $num_search_results_per_page + 1;
}

//no matches
if ($search_matches == 0){
	$search_result_start = 0;
	$search_result_end = 0;
	$search_warning = $lan[search_warning_text];

	//first results page ???
} elseif ($search_results_page == 1 || $search_results_page == 0) {
	$search_result_end = $search_result_start + $num_search_results_per_page - 1;
	if ($search_result_end > $search_matches) $search_result_end = $search_matches;
	for($count=$search_result_start-1;$count<$num_search_results_per_page;$count++){
		$search_results .= $search_results_array[$count];
	}
	$search_warning = '';

	//multiple pages
} else {
	$search_result_end = ($search_results_page * $num_search_results_per_page);
	if ($search_result_end > $search_matches) $search_result_end = $search_matches;
	for($count=$search_result_start-1;$count<$search_result_end;$count++){
		$search_results .= $search_results_array[$count];
	}
}


//too many matches
if ($search_matches > $max_search_results){
	$search_warning = $lan[search_warning_text];
}

//check number of results to format page display and choose language elements
if ($search_matches == 1){
	$search_matches .= ' ' . $lan[match];
	$search_result_end = 1;
} else {
	$search_matches .= ' ' . $lan[matches];
}

//format search text for use in url
$search_text = str_replace(' ', '+', $search_text);


//generate navigation links
if ($search_matches > 0){
	$search_results_nav = '<span class="float_right">Page ';
	for($count=1;$count<$search_matches+1;$count+=$num_search_results_per_page){
		$num_pages = $num_pages + 1;
		$search_results_nav .= '<a href="' . $default_url . 'index.php?search=' . $search_text . '&amp;search_results_page=' . $num_pages . '"> ' . $num_pages . ' </a>';

	}
	$search_results_nav .= '</span>';
	$search_results_nav .= '<br>';
}


$main = replace_variables($main);
?>