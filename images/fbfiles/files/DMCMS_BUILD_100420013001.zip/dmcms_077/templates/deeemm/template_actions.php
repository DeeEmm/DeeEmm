<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Standard template actions
===========================================================================*/

function construct($template_elements){
global $page;

switch ($page) {

	case 'login' : 
  		$page_html = $template_elements['header'] . $template_elements['banner'] . $template_elements['main'] . $template_elements['footer'];
	break;

	default : 
		$page_html = $template_elements['header'] . $template_elements['banner'] . $template_elements['main'] . $template_elements['left_column'] . $template_elements['right_column'] . $template_elements['footer'];
}
return $page_html;

}

/*===========================================================================
Custom template actions
===========================================================================*/



?>