<?php
defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Check user priviledges
===========================================================================*/
require VALIDATE;

if ($user != 'ADMIN') header("Location: " . $default_url . "index.php");


//get user input
$conf[site_name] = $_REQUEST['site_name'];
$conf[site_description] = $_REQUEST['site_description'];
$conf[site_is_active] = $_REQUEST['site_is_active'];
$conf[admin_email] = $_REQUEST['admin_email'];
$conf[db_editor_path] = $_REQUEST['db_editor_path'];
$conf[login_link_enabled] = $_REQUEST['login_link_enabled'];
$conf[multi_language] = $_REQUEST['multi_language'];
$conf[search_enabled] = $_REQUEST['search_enabled'];
$conf[forum_search_url] = $_REQUEST['forum_search_url'];
$conf[current_template] = $_REQUEST['current_template'];

//[FIXME - LANGUAGE HANDLING CHANGED - SPLIT INTO SEPERATE SECTION]
/*
$conf[language_1] = $_REQUEST['language_1'];
$conf[language_1_flag] = $_REQUEST['language_1_flag'];
$conf[language_2] = $_REQUEST['language_2'];
$conf[language_2_flag] = $_REQUEST['language_2_flag'];
$conf[language_3] = $_REQUEST['language_3'];
$conf[language_3_flag] = $_REQUEST['language_3_flag'];
$conf[language_4] = $_REQUEST['language_4'];
$conf[language_4_flag] = $_REQUEST['language_4_flag'];*/

//save stuff to database
foreach ($conf as $key => $value){
	mysql_query("UPDATE `" . $db_table_prefix . "core_conf` SET `value` = '$value' WHERE `name` = '$key'") ;
}


?>