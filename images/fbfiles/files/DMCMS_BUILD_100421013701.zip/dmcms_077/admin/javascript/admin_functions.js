
/*===========================================================================
display username search results in popup window
//===========================================================================
function username_search() {
document.namesearch.submit();
submitted_name = document.getElementById('find_name').value;
search_url = 'index.php?action=find_user&find_name=' + submitted_name;
popup = window.open(search_url,'popup','width=400,height=200');
}

/*===========================================================================
Administration Help Popup
===========================================================================*/
function helpop(helpfile) {
	helpfile = './help/' + helpfile ;
	popup = window.open(helpfile,'popup','width=600,height=600');
}

/*===========================================================================
Tiny MCE setup
===========================================================================*/

	tinyMCE.init({
		// General options
		mode : "textareas",
		theme : "advanced",
		file_browser_callback : "tinyBrowser",

		plugins : "pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template,wordcount,advlist,autosave",

		// Theme options
		theme_advanced_buttons1 : "save,newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,styleselect,formatselect,fontselect,fontsizeselect",
		theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
		theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen",
		theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,pagebreak,restoredraft",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_statusbar_location : "bottom",
		theme_advanced_resizing : true,

		// Example content CSS (should be your site CSS)
		content_css : "css/content.css",

		// Drop lists for link/image/media/template dialogs
		template_external_list_url : "lists/template_list.js",
		external_link_list_url : "lists/link_list.js",
		external_image_list_url : "lists/image_list.js",
		media_external_list_url : "lists/media_list.js",

		// Style formats
		style_formats : [
			{title : 'Bold text', inline : 'b'},
			{title : 'Red text', inline : 'span', styles : {color : '#ff0000'}},
			{title : 'Red header', block : 'h1', styles : {color : '#ff0000'}},
			{title : 'Example 1', inline : 'span', classes : 'example1'},
			{title : 'Example 2', inline : 'span', classes : 'example2'},
			{title : 'Table styles'},
			{title : 'Table row 1', selector : 'tr', classes : 'tablerow1'}
		],

		// Replace values for the template plugin
		template_replace_values : {
			username : "Some User",
			staffid : "991234"
		}
	});



function submitForm()
{
	tinyMCE.triggerSave();
	document.forms[0].submit();
}

/*===========================================================================
hover function - dynamic drop down menu - start of son of suckerfish java - from - http://www.htmldog.com/articles/suckerfish/dropdowns/
===========================================================================*/

//sfHover = function() {
//	var sfEls = document.getElementById("navmenu").getElementsByTagName("li");
//	for (var i=0; i<sfEls.length; i++) {
//		sfEls[i].onmouseover=function() {
//			this.className+=" sfhover";
//		}
//		sfEls[i].onmouseout=function() {
//			this.className=this.className.replace(new RegExp(" sfhover\\b"), "");
//		}
//	}
//}
//
////if (window.attachEvent) window.attachEvent("onload", sfHover);
//
//if (document.all) { //MS IE
//if (window.attachEvent) window.attachEvent("onload", sfHover);
//else { //IE 5.2 Mac does not support attachEvent
//var old = window.onload;
//window.onload = function() { if (old) old(); sfHover(); }
//}
//}

/*===========================================================================
Add Text Function
===========================================================================*/
function AddText(window, texttoadd) {
	window.value = window.value + texttoadd;
}

/*===========================================================================
translate function
===========================================================================*/
function test() {
	alert('test');
}

/*===========================================================================
Translate Function
===========================================================================*/
function Translate(window_title_lan_2, window_title_lan_3, window_title_lan_4,	window_text_de, window_text_fr, window_text_es, titletotranslate, texttotranslate) {

//	win_title_lan_2 = window_title_lan_2;
//	win_title_lan_3 = window_title_lan_3;
//	win_title_lan_4 = window_title_lan_4;
//	win_text_de = window_text_de;
//	win_text_fr = window_text_fr;
//	win_text_es = window_text_es;
//	update_delay = 3000; //delay in millisecs

//English/Spanish
//English/French
//English/German
//English/Italian
//English/Portuguese
//English/Norwegian
//Spanish/English
//French/English
//German/English
//Italian/English
//Portuguese/English

//http://ets.freetranslation.com?language=english/German&sequence=core&srctext=translate

//call translate.php to get translation
//	frames['title_trans_de'].location.href = 'translate.php?language=english/german&text=' + titletotranslate;
//	frames['title_trans_fr'].location.href = 'translate.php?language=english/french&text=' + titletotranslate;
//	frames['title_trans_es'].location.href = 'translate.php?language=english/spanish&text=' + titletotranslate;
//	frames['text_trans_de'].location.href = 'translate.php?language=english/german&text=' + texttotranslate;
//	frames['text_trans_fr'].location.href = 'translate.php?language=english/french&text=' + texttotranslate;
//	frames['text_trans_es'].location.href = 'translate.php?language=english/spanish&text=' + texttotranslate;

//delay transferring data from iframes to textarea to allow iframes to load
//	setTimeout("transfer(win_title_lan_2, win_title_lan_3, win_title_lan_4, win_text_de, win_text_fr, win_text_es)", update_delay);

}

/*===========================================================================
Transfer Function
===========================================================================*/
function transfer(title_lan_2, title_lan_3, title_lan_4, text_de, text_fr, text_es) {
//	title_lan_2.value = frames('title_trans_de').document.body.innerHTML;
//	title_lan_3.value = frames('title_trans_fr').document.body.innerHTML;
//	title_lan_4.value = frames('title_trans_es').document.body.innerHTML;
//	text_de.value = frames('text_trans_de').document.body.innerHTML;
//	text_fr.value = frames('text_trans_fr').document.body.innerHTML;
//	text_es.value = frames('text_trans_es').document.body.innerHTML;
}

/*===========================================================================
Clear data from categories form
===========================================================================*/
function clear_categories_form() {
document.edit_categories.old_category.value = "";
document.edit_categories.editing_category_message.value = "";
document.edit_categories.category_lan_1.value = "";
document.edit_categories.tool_tip_lan_1.value = "";
document.edit_categories.category_lan_2.value = "";
document.edit_categories.tool_tip_lan_2.value = "";
document.edit_categories.category_lan_3.value = "";
document.edit_categories.tool_tip_lan_3.value = "";
document.edit_categories.category_lan_4.value = "";
document.edit_categories.tool_tip_lan_4.value = "";
document.edit_categories.display_in_margin.type = hidden;
}

/*===========================================================================
show / hide hidden divs
===========================================================================*/
function ReverseContentDisplay(d) {
if(document.getElementById(d).style.display == "none") { document.getElementById(d).style.display = "block"; }
else { document.getElementById(d).style.display = "none"; }
}

function HideContent(d) {
document.getElementById(d).style.display = "none";
}

function ShowContent(d) {
document.getElementById(d).style.display = "block";
}

/*===========================================================================
Show / hide language editors
===========================================================================*/
function select_language(lan) {

	switch(lan)
	{
		case 1:
		{
			ShowContent('lan_1_controls');
			HideContent('lan_2_controls');
			HideContent('lan_3_controls');
			HideContent('lan_4_controls');
			break;
		}
		case 2:
		{
			HideContent('lan_1_controls');
			ShowContent('lan_2_controls');
			HideContent('lan_3_controls');
			HideContent('lan_4_controls');
			break;
		}
		case 3:
		{
			HideContent('lan_1_controls');
			HideContent('lan_2_controls');
			ShowContent('lan_3_controls');
			HideContent('lan_4_controls');
			break;
		}
		case 4:
		{
			HideContent('lan_1_controls');
			HideContent('lan_2_controls');
			HideContent('lan_3_controls');
			ShowContent('lan_4_controls');
			break;
		}
	}
}

/*===========================================================================
Show / hide media controls on categories form
===========================================================================*/
function setup_categories_form() {
	if (document.edit_categories.category_type.value == 'media')
	{
		ShowContent('hidden_media_controls');
	} else {
		HideContent('hidden_media_controls');
	}
}


/*===========================================================================
add option to category list
===========================================================================*/
function addOption(){
	oCombo = document.edit_media.category;
	oselected_category = document.edit_media.selected_category;

	if(oselected_category.value != "") {
		//First search for duplicates
		for(var i = 0; i < oCombo.options.length ; i++){
			if(oCombo.options[i].text == oselected_category.value)
				return;
		}
		// Add new one
		oCombo.options[oCombo.options.length] = new Option
(oselected_category.value, oselected_category.value);
	}
}



// lose focus {document.getElementById('myAnchor').blur()}