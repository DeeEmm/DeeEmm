<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Get configuration variables from database and store in associative array
===========================================================================*/

$conf = array();
$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "core_conf`");

while($row = mysql_fetch_assoc( $sql_query )){

	$conf[$row[name]] = $row[value];
//	${$row[name]} = $row[value];
}
mysql_free_result($sql_query);


/*foreach ($conf as $key => $value){
	echo $key;
	echo $value;
}*

/*===========================================================================
Hitcounter
===========================================================================*/
if (!isset($_COOKIE['hitcounted'])) {
	++$conf[hitcount];
	mysql_query("UPDATE `" . $db_table_prefix . "core_settings` SET	`hitcount` = '$conf[hitcount]'");
	setcookie("hitcounted" ,$conf[hitcount] );
	$hitcount = $conf[hitcount];
}

?>