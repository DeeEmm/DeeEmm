<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );


/*===========================================================================
Setup admin links
===========================================================================*/
if ($user == 'ADMIN'){

	if ($page == '' || !isset($page)) {
		$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "core_structure` WHERE `order` = 1");
		while($sql_result = mysql_fetch_array($sql_query)) {
			$page = $sql_result[table];
		}

		$sql_query = mysql_query("SELECT DISTINCT `id` FROM `" . $db_table_prefix . 'cat_' . $page . "` WHERE `order` = 1");
		while($sql_result = @mysql_fetch_array($sql_query)) {
			$id = $sql_result[id];
		}

	}

	//16-06-08
	//if $id not set get highest ranking page by order
	if ($id == '' || !isset($id)) {
		$sql_query = mysql_query("SELECT DISTINCT * FROM `" . $db_table_prefix . 'cat_' . $page . "` WHERE `order` > 0");
		while($sql_result = @mysql_fetch_array($sql_query)) {
			$id = $sql_result[id];
		}
	}

		$empty_normal_page_admin_href = "<A href='$default_url".$admin_dir.""."index.php?action=add'><img class='icon' title='Add' src='$default_url".$templates_dir."images/icons/article_add.gif'></A> <A href='$default_url".$admin_dir."index.php?action=add_link'><img class='icon' title='Add' src='$default_url".$templates_dir."images/icons/link_add.gif'></A>";
		$normal_page_admin_href = "<A href='$default_url".$admin_dir.""."index.php?action=add'><img class='icon' title='Add' src='$default_url".$templates_dir."images/icons/article_add.gif'></A> <A href='$default_url".$admin_dir."index.php?action=add_link'><img class='icon' title='Add' src='$default_url".$templates_dir."images/icons/link_add.gif'></A> <A href='$default_url".$admin_dir."index.php?page=$page&amp;id=$id&amp;action=edit'><img class='icon' title='Edit' src='$default_url"."$templates_dir"."images/icons/article_edit.gif'></A> <A href='$default_url".$admin_dir."index.php?page=$page&amp;id=$id&amp;action=delete' onClick=\"javascript:return confirm('[lan]delete_warning[/lan]')\"><img class='icon' title='Delete' src='$default_url".$templates_dir."images/icons/article_delete.gif'></A>";

		$empty_media_page_admin_href = "<A href='$default_url".$admin_dir.""."index.php?action=add_media'><img class='icon' title='Add' src='$default_url".$templates_dir."images/icons/image_add.gif'></A> ";
		$media_page_admin_href = "<A href='$default_url".$admin_dir.""."index.php?action=add_media'><img class='icon' title='Add' src='$default_url".$templates_dir."images/icons/image_add.gif'></A> <A href='$default_url".$admin_dir. "index.php?page=$page&amp;id=$id&amp;action=edit'><img class='icon' title='Edit' src='$default_url"."$templates_dir"."images/icons/image_edit.gif'></A> <A href='$default_url".$admin_dir. "index.php?page=$page&amp;id=$id&amp;action=delete' onClick=\"javascript:return confirm('[lan]delete_warning[/lan]')\"><img class='icon' title='Delete' src='$default_url".$templates_dir."images/icons/image_delete.gif'></A>";
		$media_library_image_edit = "<A href='$default_url".$admin_dir. "index.php?page=$page&amp;action=add_media'><img class='icon' title='Add' src='$default_url".$templates_dir."images/icons/image_add.gif'></A> <A href='$default_url" . $admin_dir. "index.php?page=$page&amp;action=edit_media&amp;id=$id'><img class='icon' title='Edit' src='$default_url"."$templates_dir"."images/icons/image_edit.gif'></A> <a href='$default_url" . $admin_dir. "index.php?page=$page&amp;id=$id&amp;action=delete' onClick=\"javascript:return confirm('[lan]delete_warning[/lan]')\"><img class='icon' title='Delete' src='$default_url".$templates_dir."images/icons/image_delete.gif'></A>&nbsp&nbsp&nbsp" . $lf;
		$media_library_index_edit = "<A href='$default_url".$admin_dir."index.php?page=$page&amp;action=add_media'><img class='icon' title='Add' src='$default_url".$templates_dir."images/icons/image_add.gif'></A>&nbsp&nbsp&nbsp" . $lf;
		$media_href = "<A href='$default_url".$admin_dir."index.php?page=$page&amp;action=add_media'><img class='icon' title='Add' src='$default_url".$templates_dir."images/icons/image_add.gif'></A>" . $lf;

//		$admin_nav = '<A href="'.$default_url.$admin_dir.'" title="Modify Admin Settings">[lan]admin[/lan]</A>';

		$list_article_edit = "<A href='$default_url".$admin_dir."index.php?page=$page&amp;action=add'><img class='icon' title='Add' src='$default_url".$templates_dir."images/icons/article_add.gif'></A> <A href='$default_url" . $admin_dir. "index.php?page=$page&amp;action=edit&amp;id=$id'><img class='icon' title='Edit' src='$default_url"."$templates_dir"."images/icons/article_edit.gif'></A> <a href='$default_url".$admin_dir. "index.php?page=$page&amp;id=$id&amp;action=delete' onClick=\"javascript:return confirm('[lan]delete_warning[/lan]')\"><img class='icon' title='Delete' src='$default_url".$templates_dir."images/icons/article_delete.gif'></A>" . $lf;
		$list_index_edit = "<A href='$default_url".$admin_dir."index.php?page=$page&amp;action=add'><img class='icon' title='Add' src='$default_url".$templates_dir."images/icons/article_add.gif'></A>" . $lf;

		$sitemap_category_edit = '';
		$sitemap_subcategory_edit = '';

}

/*===========================================================================
Create main menu categories links from table array
===========================================================================*/
foreach($all_tables as $value){

	//get main menu item data
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "core_structure` WHERE `table` = '$value' ORDER BY `order`");
	while($sql_result = mysql_fetch_array($sql_query)) {
		$type = $sql_result[type];
		$category = $sql_result[category_lan_ . $language];
		$tool_tip = $sql_result[tool_tip_lan_ . $language];
		$display_in_sitemap = $sql_result[display_in_sitemap];
	}

	//get highest order page
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . 'cat_' . "$value` WHERE `id` > 0 ORDER BY `order` LIMIT 1");
	if($sql_result = mysql_fetch_array($sql_query)){
		$nav_id = $sql_result[id];
		$page_exists = TRUE;
	} else {
		$page_exists = FALSE;
	}

	if (isset($display_in_sitemap) && $display_in_sitemap <> ''){


		switch ($type) {

			//suppress sub menus if list type
			case 'list';
			if($page_exists){
				$navmenu .= "<li><A href='$default_url"."index.php?page=$value' title='".$tool_tip."'>".$category.$navigation_seperator."</a>";
			} ELSE {
				$navmenu .= "<li><A href='$default_url"."index.php?page=messagebox&amp;message=no_data' title='".$tool_tip."'>".$category.$navigation_seperator."</a>";
			}
			break;


			//suppress sub menus if media type
			case 'media';
			if($page_exists){
				$navmenu .= "<li><A href='$default_url"."index.php?page=$value' title='".$tool_tip."'>".$category.$navigation_seperator."</a>";
			} ELSE {
				$navmenu .= "<li><A href='$default_url"."index.php?page=messagebox&amp;message=no_media' title='".$tool_tip."'>".$category.$navigation_seperator."</a>";
			}
			break;


			case 'normal';
			//get top link
			$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . 'cat_' . "$value` WHERE `id` > 0 ORDER BY `order` LIMIT 1");
			if($page_exists){
				//if page is link type, display link
				if (isset($sql_result[link_url]) && $sql_result[link_url] <> '') {
					$navmenu .= "<li><a href='$sql_result[link_url]' title='" . $sql_result[tool_tip_lan_ . $language] . "'>".$category.$navigation_seperator."</a>";
				} else {
					$nav_id = $sql_result[id];
					$navmenu .= "<li><a href='$default_url"."index.php?page=$value&amp;id=$nav_id' title='".$tool_tip."'>".$category.$navigation_seperator."</a>";
				}

			} else {
				//no data
				$navmenu .= "<li><A href='$default_url"."index.php?page=messagebox&amp;message=no_data' title='".$tool_tip."'>".$category.$navigation_seperator."</a>";
			}

			//get sub menu data from database and create array of sub menu categories
			$sub_tables = '';
			$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . 'cat_' . "$value` WHERE `parent` = '$value' ORDER BY `order`");
			while($sql_result = mysql_fetch_array($sql_query)){
				$sub_tables[] .= $sql_result[category];
			}

			//if array has more than one category create a sub menu item for it
			if (count($sub_tables) > 1){
				$navmenu .= "<ul>";
				foreach($sub_tables as $sub_value){
					$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . 'cat_' . "$value` WHERE `category` = '$sub_value'");
					while($sql_result = mysql_fetch_array($sql_query)){
						if (isset($sql_result[link_url]) && $sql_result[link_url] <> '') {
							$navmenu .= "<li><a href='$sql_result[link_url]' title='" . $sql_result[tool_tip_lan_ . $language] . "'>" . $sql_result[title_lan_ . $language] . "</a></li>";
						} else {
							$navmenu .= "<li><a href='$default_url"."index.php?page=$sql_result[parent]&amp;id=$sql_result[id]' title='" . $sql_result[tool_tip_lan_ . $language] . "'>" . $sql_result[title_lan_ . $language] . "</a></li>";
						}
					}
				}
				$navmenu .= "</ul>";
			}
			break;

		}//endif $display_in_sitemap
	}//end select $type
	$navmenu .= "</li>";
}


//Add log in/out link if enabled
if ($conf[login_link_enabled]) {
	if ($logged_in == true) {
		$navmenu .= "<li><A href='$default_url"."index.php?page=logout' title='Log Out'>Log Out".$navigation_seperator."</a></li>";
	} else  {
		$navmenu .= "<li><A href='$default_url"."index.php?page=login' title='Log In'>Log In".$navigation_seperator."</a></li>";
	}
}


//$navmenu .= "<li>$admin_nav"."</li>";

?>
