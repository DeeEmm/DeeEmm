<?php
/*[Info]=====================================================================
 index.php
 Original File Created on 24/12/04 20:15 by Mick Percy

 DMCMS is an open source Content Management System (CMS) provided free for use
 under the GNU General Public License.

 ==[Support]=====================================================================
 Support for DMCMS is provided via the following channels:
 The DeeEmm forum at http://www.deeemm.com/forum
 The DeeEmm wiki at http://www.deeemm.com/wiki
 The DMCMS support tracker hosted at the DMCMS SourceForge project page at
 http://sourceforge.net/projects/dmcms/

 ==[Bug Tracking / Feature Requests]=============================================
	Please report all bugs using the tracker which can be found at
	http://sourceforge.net/tracker/?group_id=189064

==[Copyright]===================================================================
	DMCMS (Also known as DeeEmm CMS), and all constituent files including
	this file are copyright (C) 2007 Mick Percy. All rights reserved.

==[License]=====================================================================
	This file is part of DMCMS (Also known as DeeEmm CMS).
	DMCMS is free software; you can redistribute it and/or modify it under
	the terms of the GNU General Public License as published by the Free
	Software Foundation; either version 2 of the License, or (at your option)
	any later version.
	DMCMS is distributed in the hope that it will be useful, but WITHOUT ANY
	WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
	FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
	details.
	You should have received a copy of the GNU General Public License along
	with DMCMS; if not, write to the Free Software Foundation, Inc.,
	51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA or alternatively
	you can visit http://www.gnu.org/copyleft/gpl.html

==[Changelog]===================================================================
	Please refer to README.TXT for the changelog

==[Installation]================================================================
	Please refer to README.TXT for installation instructions

==============================================================================*/

ob_start();
session_start();

define('_INDM', TRUE);

/*===========================================================================
Required files
===========================================================================*/
require 'config.php';
require $abs_path . $core_dir . 'definitions.php';
require $abs_path . $core_dir . 'initialisations.php';
require $abs_path . $core_dir . 'functions.php';
require $abs_path . $core_dir . 'db_access.php';
require $abs_path . $core_dir . 'site_structure.php';
require $abs_path . $core_dir . 'variables.php';
require $abs_path . $core_dir . 'language.php';

require $abs_path . $includes_dir . 'static_content.php';

$templates_dir .=  $conf[current_template] . '/';

require $abs_path . $templates_dir . 'template_config.php';
require $abs_path . $templates_dir . 'template_actions.php';


/*===========================================================================
Get navigation string query from browser
===========================================================================*/
$page = anti_inject(htmlspecialchars($_GET["page"], ENT_QUOTES));
$child = anti_inject(htmlspecialchars($_GET["child"], ENT_QUOTES));
$category = anti_inject(htmlspecialchars($_GET["category"], ENT_QUOTES));
$id = anti_inject(htmlspecialchars($_GET["id"], ENT_QUOTES));
$search_text = anti_inject(htmlspecialchars($_GET["search"], ENT_QUOTES));
$action = anti_inject(htmlspecialchars($_GET["action"], ENT_QUOTES));
$popmess = anti_inject(htmlspecialchars($_GET["popmess"], ENT_QUOTES));
$popban = anti_inject(htmlspecialchars($_GET["popban"], ENT_QUOTES));

/*===========================================================================
Check $id only contains numbers
===========================================================================*/
if (preg_match_all("/[^0-9]/", $id, $matches)){
	echo 'Possible Hack Attempt';
	exit;	
}

/*===========================================================================
Check $page only contains valid characters
===========================================================================*/
if (preg_match_all("/[^ _A-Za-z0-9]/", $page, $matches)){
	echo 'Possible Hack Attempt';
	exit;	
}


/*===========================================================================
Process any messages
===========================================================================*/
if ($popban) {
	$popban = $lan[$popban];
	$popup_banner = read_file($default_url . $templates_dir  ."popup_banner.tpl");
	$popup_banner = replace_variables($popup_banner);
}

if ($popmess) {
	$popmess = $lan[$popmess];
	$popup_message = read_file($default_url . $templates_dir  ."popup_message.tpl");
	$popup_message = replace_variables($popup_message);
	$javascript_onload .= 'popup_message();$("#popup_messageClose").click(function(){disablePopup();});';
}

/*===========================================================================
Check user priviledges
===========================================================================*/
require VALIDATE;


/*===========================================================================
If user is admin - show admin navbar
===========================================================================*/
if ($user == 'ADMIN') {
  	$content = $default_url . $admin_dir  . "templates/admin_navbar.tpl";
  	$admin_navbar = read_file($content);	
	$admin_navbar = replace_variables($admin_navbar);
}
   
/*===========================================================================
If maintenance mode send maintenance page to browser

[TODO] make maintenance page a 'static page'
===========================================================================*/
if ($conf[site_is_active] !== 'on' && $user !== 'ADMIN' && $page !== 'login') {
	$page = 'maintenance';
	$page_title .= $cookie_trial_seperator . $lan[maintenance];
}


/*===========================================================================
Set the page title + cookie trial
===========================================================================*/
if ($page !== 'login' && $page !== 'maintenance')  {

	$cookie_trial = '<a href="' . $default_url . 'index.php?page=sitemap">[ ' . $lan[sitemap] . ' ]</a>' . $cookie_trial_seperator . '<a href="' . $default_url . '">' . $conf[site_name] . '</A>';

	$page_title = $cookie_trial_seperator . ucfirst($page);
	if ($page !== 'orphan' && $page !== '') {
		$cookie_trial .= $cookie_trial_seperator . '<a href = "' . $default_url . 'index.php?page=' . $page . '&id=1">' . ucfirst($page) . '</a>';
	}
} else {
		$cookie_trial = "<A class='navmenulinks' href='$default_url"."index.php?page=login' title='Log In'>[ Log In ]</A>";
}

/*===========================================================================
Set page metadata

[TODO]get metadata from database and add to metadata vars
===========================================================================*/
$meta_title = $page_title;
$meta_description = $meta_description;
$meta_keywords = $meta_keywords;
$meta_description = $meta_description;

/*===========================================================================
Get standard page header
===========================================================================*/
$header = read_file($default_url . $templates_dir  . "header.tpl");


/*===========================================================================
Get standard page banner
===========================================================================*/
$banner = read_file($default_url . $templates_dir  . "banner.tpl");


/*===========================================================================
If site active or user is admin get content
===========================================================================*/
if ($conf[site_is_active] || $user == 'ADMIN') {

/*
[FIXME]columns only for current template - need to make layout dynamic
*/
	//get left and right columns
	$left_column = read_file($default_url . $templates_dir  . "left_column.tpl");
	$right_column = read_file($default_url . $templates_dir  . "right_column.tpl");


	//if search enabled add searchbox
	if ($conf[search_enabled]) {
		$searchbox = read_file($default_url . $templates_dir  ."searchbox.tpl");
		$searchbox = replace_variables($searchbox);
	} else {
		$searchbox = '';
	}

/*
[FIXME]change this to a plugin
*/
	//select random list item(s)
	if (count($newsbox_libraries) > 0) {
		include $includes_dir . 'build_newsbox_content.php';
	}

/*
[FIXME]change this to a plugin
*/
	//select random media library picture(s)
	if (count($imagebox_libraries) > 0) {
		include $includes_dir . 'build_imagebox_content.php';
	}

/*
[FIXME]change multilanguage to dynamic
*/
	//if enabled create multi language navigation box
	if ($conf[multi_language]) {
		$content = $default_url . $templates_dir . "multi_language_nav.tpl";
		$multi_language_nav = read_file($content);
		$multi_language_nav = replace_variables($multi_language_nav);
	} else {
		$multi_language_nav = '';
	}

	if ($conf[login_link_enabled]) {
		$login_link = "<A class='navmenulinks' href='$default_url"."index.php?page=login' title='Log In'>Log In</A>";
	} else {
		$login_link = '';
	}
}


/*===========================================================================
USER functions
===========================================================================*/

//check if active user
if ($user=='USER' || $user=='ADMIN'){
	switch ($action) {

		//    //edit / save profile
		//    case 'edit_profile';
		//    case 'save_profile';
		//      require $includes_dir . 'edit_profile.php';
		//    break;

	}
}


/*===========================================================================
Build navigation menu
===========================================================================*/
if ($conf[site_is_active] == 'on' || $user == 'ADMIN') {
	include $includes_dir . 'build_navigation.php';
}


/*===========================================================================
Perform search if search string present

[FIXME] - don't like way this works
===========================================================================*/
if (strlen($search_text) > 0){
	include $includes_dir . 'perform_site_search.php';
} else {


/*===========================================================================
Generate page from navigation query result
===========================================================================*/
	switch ($page) {

  //add cases here where you do not want any action to be carried out
  //otherwise case '$page' will pick up all not specified

  case 'messagebox';
  	$content = $default_url . $templates_dir  . "message_box.tpl";
  	$main = read_file($content);
	$admin_href = $empty_media_page_admin_href;
  break;
  
  case 'maintenance';
 	 $main = read_file($default_url . $templates_dir . "maintenance.tpl");
  break;  

  case 'user';
  break;

  //rss2 feed create
  case 'rss2';
  case 'rss1';
  case 'atom';
 	 include $includes_dir . 'build_rss_feed.php';
 	 exit;
  break;

  //display sitemap content
  case 'sitemap';
 	 include $includes_dir . 'build_sitemap.php';
  break;

  //check login / display login form
	  case 'login';
	  include $includes_dir . 'login.php';
  break;

  //check logout / cancel session
  case 'logout';
 	 setcookie ("deeemm", "", time() - 3600);
	 header("Location: " . $default_url . "index.php");
  exit;

  //build pages based on type
  case $page :

  	if ($page == 'orphan') $type = 'orphan';

  	//if no page set use page ranked highest by order (i.e. index / home page)
  	if ($page == '' || !isset($page)) {
  		unset($action);
  		$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "core_structure` WHERE `order`=(select min(`order`) FROM `" . $db_table_prefix . "core_structure`)");
  		while($sql_result = mysql_fetch_array($sql_query)) {
  			$page = $sql_result[table];
  		}
  		$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . 'cat_' . $page . "` WHERE `order`=(select min(`order`) FROM `" . $db_table_prefix . "core_structure`)");
  		while($sql_result = mysql_fetch_array($sql_query)) {
  			$id = $sql_result[id];
  		}
  	}

  	if (!$id || $id == 'id') { //fix for strange bug where $id becomes id!!?!
  		$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . 'cat_' . $page . "` WHERE `order`=(select min(`order`) FROM `" . $db_table_prefix . "core_structure`)");
  		while($sql_result = mysql_fetch_array($sql_query)) {
  			$id = $sql_result[id];
  		}
  	}


  	//get page type from database
  	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "core_structure` WHERE `table` = '$page'");
  	while($sql_result = mysql_fetch_array($sql_query)) {
  		$type = $sql_result[type];
  	}

  	//process page type
  	switch ($type) {

  		//build normal / home pages
  		case 'normal' :
  		case 'orphan' :
  			include $includes_dir . 'build_normal_content.php';
  			break;

  			//build news / list / blog type page
  		case 'list' :
  		case 'list + newsbox' :
  			include $includes_dir . 'build_list_content.php';
  			break;

  			//build media pages
  		case 'media' :
  			include $includes_dir . 'build_media_content.php';
  			break;

  			//build forum
  		case 'forum' :
  			//include $includes_dir . 'build_normal_content.php';
  			break;

  			//if no other cases match
  		default :
  			//        include $includes_dir . 'build_normal_content.php';
  			break;

  	} 
  } 
}


/*===========================================================================
Build standard page footer
===========================================================================*/
$footer = read_file($default_url . $templates_dir  ."footer.tpl");


/*===========================================================================
Construct the page

template elements need to be generated automatically!!
===========================================================================*/


$template_elements = array(
	"header" => $header, 
	"banner" => $banner,
	"main" => $main,
	"left_column" => $left_column,
	"right_column" => $right_column,
	"footer" => $footer
);


$page_html = construct($template_elements);


/*===========================================================================
Replace template markers with variables
===========================================================================*/
	$page_html = replace_variables($page_html);
	$page_html = replace_dm_code($page_html);
	$page_html = replace_language($page_html);

/*===========================================================================
Send page to browser
===========================================================================*/
	echo $page_html;

/*===========================================================================
Tidy up
===========================================================================*/
	mysql_close($db_connection);
	ob_end_flush();
?>