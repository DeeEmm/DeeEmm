var popupStatus = 0;

function loadPopup(){
	if(popupStatus==0){
		$("#popup_message_bg").css({
			"opacity": "0.7"
		});
		$("#popup_message_bg").fadeIn("slow");
		$("#popup_message").fadeIn("slow");
		popupStatus = 1;
	}
}

function disablePopup(){
	if(popupStatus==1){
		$("#popup_message_bg").fadeOut("slow");
		$("#popup_message").fadeOut("slow");
		popupStatus = 0;
	}
}

function centerPopup(){
	var windowWidth = document.documentElement.clientWidth;
	var windowHeight = document.documentElement.clientHeight;
	var popupHeight = $("#popup_message").height();
	var popupWidth = $("#popup_message").width();
	$("#popup_message").css({
		"position": "absolute",
		"top": windowHeight/2-popupHeight/2,
		"left": windowWidth/2-popupWidth/2
	});
	
	$("#popup_message_bg").css({
		"height": windowHeight
	});
	
}

function popup_message(){
		centerPopup();
		loadPopup();
}

