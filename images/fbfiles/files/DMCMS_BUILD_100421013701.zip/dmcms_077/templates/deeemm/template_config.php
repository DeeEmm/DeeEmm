<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Template settings
===========================================================================*/

$media_library_thumbs_per_page = 8;
$media_library_thumb_rows_per_page = 2;
$media_library_max_image_width = 80;
$media_library_thumb_width = 90;
$media_library_thumb_height = 70;
$media_library_video_width = 350;
$media_library_video_height = 300;
$max_upload_filesize = 100000000;

$max_search_results = 100;
$search_result_length = 400;
$num_search_results_per_page = 5;
$nav_seperator = " :: ";

/*===========================================================================
Setup template variables
===========================================================================*/
$site_name = $conf[site_name];
$site_description = $conf[site_description];



?>