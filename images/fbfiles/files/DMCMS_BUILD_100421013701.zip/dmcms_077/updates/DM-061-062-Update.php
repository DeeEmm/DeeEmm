<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

//===========================================================================

$new_version = '0.6.2 (BETA)';

/*===========================================================================
//>update version number
===========================================================================*/
mysql_query("UPDATE `" . $db_table_prefix . "admin` SET `version` = '$new_version' WHERE `id` = 0") OR DIE ("<b>A fatal MySQL error occured</b>.\n<br />Query: " . $sql_query . "<br />\nError: (" . mysql_errno() . ") " . mysql_error());
echo $version . ' -> ' . $new_version . ' Update<br><br>';    


/*===========================================================================
//>update control tables in database
===========================================================================*/
//admin
//orphan
//static_content
//stats
//structure
//users
//mysql_query("ALTER TABLE `" . $db_table_prefix . "core_structure` ADD `href_only` varchar(10) NOT NULL AFTER `display_in_margin`") OR DIE ("<b>A fatal MySQL error occured</b>.\n<br />Query: " . $sql_query . "<br />\nError: (" . mysql_errno() . ") " . mysql_error());


/*===========================================================================
//>update non control (content) tables in database
===========================================================================*/
$sql_query = mysql_query("SHOW TABLES FROM $db_name");
  while($sql_result = mysql_fetch_array($sql_query)) {
		if ($sql_result[0] != $db_table_prefix.'admin' && $sql_result[0] != $db_table_prefix.'orphan' && $sql_result[0] != $db_table_prefix.'static_content' && $sql_result[0] != $db_table_prefix.'stats' && $sql_result[0] != $db_table_prefix.'structure' && $sql_result[0] != $db_table_prefix.'users'){
			mysql_query("ALTER TABLE `" . $sql_result[0] . "` ADD `link_url` varchar(200) NOT NULL AFTER `image`") OR DIE ("<b>A fatal MySQL error occured</b>.\n<br />Query: " . $sql_query . "<br />\nError: (" . mysql_errno() . ") " . mysql_error());
			mysql_query("ALTER TABLE `" . $sql_result[0] . "` ADD `display_in_navabar` varchar(50) DEFAULT 'on' NOT NULL AFTER `link_url`") OR DIE ("<b>A fatal MySQL error occured</b>.\n<br />Query: " . $sql_query . "<br />\nError: (" . mysql_errno() . ") " . mysql_error());
			echo 'Updated -> ' . $sql_result[0] . '<br>';
		}
  }
?>