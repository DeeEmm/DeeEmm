<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Check user priviledges
===========================================================================*/
require VALIDATE;

if ($user != 'ADMIN') header("Location: " . $default_url . "index.php");


$content = "templates/admin_mod_media.tpl";
$main = read_file($content);


/*===========================================================================
If $id is set file must exist in database so get data
===========================================================================*/
if (isset($id) && $id != ''){
	$admin_title = $lan[edit_media];
	$page = str_replace("%20", " ", $page);
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . 'cat_' . $page . "` WHERE `id` = $id");
	while($sql_result = mysql_fetch_array($sql_query)){
		$article_date = $sql_result[date];
		$article_date = strftime("%a %d %b  %Y", strtotime($article_date));
		$order = $sql_result[order];
		$parent = $sql_result[parent];
		$child = $sql_result[child];
		$category = $sql_result[category];

		$title_lan_1 = $sql_result[title_lan_1];
		$title_lan_2 = $sql_result[title_lan_2];
		$title_lan_3 = $sql_result[title_lan_3];
		$title_lan_4 = $sql_result[title_lan_4];
		$tool_tip_lan_1 = $sql_result[tool_tip_lan_1];
		$tool_tip_lan_2 = $sql_result[tool_tip_lan_2];
		$tool_tip_lan_3 = $sql_result[tool_tip_lan_3];
		$tool_tip_lan_4 = $sql_result[tool_tip_lan_4];
		$description_lan_1 = $sql_result[description_lan_1];
		$description_lan_2 = $sql_result[description_lan_2];
		$description_lan_3 = $sql_result[description_lan_3];
		$description_lan_4 = $sql_result[description_lan_4];
		$media_file_name = $sql_result[image];

		//Check media type and make sure we display them correctly
		if (stristr($media_file_name,".png")) $media_display = "<img src='".$media_dir."thumbnail.php?height=120&width=180&filename=$media_file_name' border=1>";
		if (stristr($media_file_name,".jpg")) $media_display = "<img src='".$media_dir."thumbnail.php?height=120&width=180&filename=$media_file_name' border=1>";
		if (stristr($media_file_name,".bmp")) $media_display = "<img src='".$media_dir."thumbnail.php?height=120&width=180&filename=$media_file_name' border=1>";
		if (stristr($media_file_name,".gif")) $media_display = "<img src='".$media_dir."thumbnail.php?height=120&width=180&filename=$media_file_name' border=1>";
		if (stristr($media_file_name,".mpg")) $media_display = "<center><OBJECT ID='MediaPlayer1' height='163' width='183' classid='CLSID:22D6F312-B0F6-11D0-94AB-0080C74C7E95'	codebase='http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=6,0,02,902' standby='Loading Microsoft Windows Media Player components...' type='application/x-oleobject'><param name='src' value='".$media_dir."$media_file_name'><PARAM NAME='FileName' VALUE='$media_file_name'><PARAM NAME='AutoStart' VALUE='false'><EMBED type='application/x-mplayer2' pluginspage = 'http://www.microsoft.com/Windows/MediaPlayer/index.php'></EMBED></OBJECT></center>";
		if (stristr($media_file_name,".mov")) $media_display = "<center><OBJECT CLASSID='clsid:02BF25D5-8C17-4B23-BC80-D3488ABDDC6B' WIDTH='183px' HEIGHT='163px' CODEBASE='http://www.apple.com/qtactivex/qtplugin.cab'><PARAM name='SRC' VALUE='".$media_dir."$media_file_name'><PARAM name='AUTOPLAY' VALUE='false'><PARAM name='CONTROLLER' VALUE='true'><EMBED SRC='".$media_dir."$media_file_name'WIDTH='183px' HEIGHT='163px' AUTOPLAY='false' CONTROLLER='true' PLUGINSPAGE='http://www.apple.com/quicktime/download/'></EMBED></OBJECT></center>";

		//prevent pdf from displaying!!??
		if (stristr($media_file_name,".pdf")) $media_display = "<a target='_blank' href='./$media_dir"."$media_file_name'><img border=0 src='./theme/logo_pdf.gif'></a>";
	}

	$article_ref = "index.php?page=$page&id=$id";

/*===========================================================================
Propogate drop down lists
===========================================================================*/
	$media_library_list = "<select style=\"width:71%; float:right\" length=20 name='parent'>";
	foreach($media_tables as $value){
		//propogate media library option list
		if ($value == $page){
			$media_library_list .= "<option selected value='$value'>$value</option>";
		} else {
			$media_library_list .= "<option>$value</option>";
		}
	}
	$media_library_list = str_replace('  ', '', $media_library_list);
	$media_library_list .= '</select>';

	$media_category_list = "<select name=\"category\" onChange=\"this.form.selected_category.value = this.options[this.selectedIndex].text\"	style=\"position:absolute;z-index:1;width:190px;clip:rect(0px,190px, 22px, 80px)\"><option selected value='$category'>$category</option>";
	foreach($media_categories as $value){
		//propogate category type option list
		if ($value != $category) {
			$media_category_list .= "<option>$value</option>";
		}
	}
	$media_category_list = str_replace('  ', '', $media_category_list);
	$media_category_list .= '</select>';
	$selected_category = $category;
}//end if $id




?>
