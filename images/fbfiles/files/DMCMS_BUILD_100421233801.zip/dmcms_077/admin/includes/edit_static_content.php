<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Check user priviledges
===========================================================================*/
require VALIDATE;

if ($user != 'ADMIN') header("Location: " . $default_url . "index.php");

$content = "templates/admin_mod_static_content.tpl";
$admin_title = $lan[$action];

//$description_lan_1 = mysql_escape_string(stripslashes($_REQUEST['description_lan_1']));
$description_lan_1 = $_REQUEST['description_lan_1'];

$action = str_replace( 'edit_', '', $action);

switch ($action) {

	case 'save_static_content';
	$page = $_REQUEST['page'];
	mysql_query("UPDATE `" . $db_table_prefix . "static_content` SET `description_lan_1` = '$description_lan_1' WHERE `category` = '$page'");
	header("Location: " . $default_url . "index.php");
	break;

	case $action;
	$page = $action;
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "static_content` WHERE `category` = '$page'");
	while($sql_result = mysql_fetch_array($sql_query)){
		$description_lan_1 = rtesafe($sql_result[description_lan_1]);
	}
	$rte_editor_rows = '30';
	$rte_editor_width = '100%';
	break;

	default :
		break;

}

$main = read_file($content);

/*===========================================================================
 //>replace template markers with variables
 ===========================================================================*/
$main = replace_variables($main);



?>
