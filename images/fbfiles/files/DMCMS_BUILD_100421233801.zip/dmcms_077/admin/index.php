<?php

ob_start();
session_start();

define('_INDM', TRUE);
define('ADMIN_PATH', dirname(__FILE__).'/');

/*===========================================================================
Required files
===========================================================================*/
require '../config.php';

/*[FIXME] Need to check if database is available / installed + check if update is available
if update available - install / ask to install
if not installed - allow to install / restore database */

require $abs_path . $core_dir . 'definitions.php';
require $abs_path . $core_dir . 'initialisations.php';
require $abs_path . $core_dir . 'functions.php';
require $abs_path . $core_dir . 'db_access.php';
require $abs_path . $core_dir . 'structure.php';
require $abs_path . $core_dir . 'variables.php';
require $abs_path . $core_dir . 'language.php';

require $abs_path . $includes_dir . 'static_content.php';

$templates_dir .=  $conf[current_template] . '/';

require $abs_path . $templates_dir . 'template_config.php';
require $abs_path . $templates_dir . 'template_actions.php';

/*===========================================================================
Check user priviledges
===========================================================================*/
require VALIDATE;

if ($user !== 'ADMIN') {
	header("Location: http://localhost/dmcms_077/index.php?page=login");
	exit;
}

/*===========================================================================
Get navigation string query from browser
===========================================================================*/
$page = anti_inject(htmlspecialchars($_GET["page"], ENT_QUOTES));
$child = anti_inject(htmlspecialchars($_GET["child"], ENT_QUOTES));
$category = anti_inject(htmlspecialchars($_GET["category"], ENT_QUOTES));
$id = anti_inject(htmlspecialchars($_GET["id"], ENT_QUOTES));
$search_text = anti_inject(htmlspecialchars($_GET["search"], ENT_QUOTES));
$action = anti_inject(htmlspecialchars($_GET["action"], ENT_QUOTES));
$popmes = anti_inject(htmlspecialchars($_GET["popmes"], ENT_QUOTES));

/*===========================================================================
Check $id only contains numbers
===========================================================================*/
if (preg_match_all("/[^0-9]/", $id, $matches)){
	echo 'Possible Hack Attempt';
	exit;	
}

/*===========================================================================
Check $page only contains valid characters
===========================================================================*/
if (preg_match_all("/[^ _A-Za-z0-9]/", $page, $matches)){
	echo 'Possible Hack Attempt';
	exit;	
}


/*===========================================================================
Get admin navbar
===========================================================================*/
$content = $default_url . $admin_dir  . "templates/admin_navbar.tpl";
$admin_navbar = read_file($content);
$admin_navbar = replace_variables($admin_navbar);
  
/*===========================================================================
Perform action based on query string
===========================================================================*/

//set link to admin javascript functions
$admin_javascript_link = '<script language="javascript"  type="text/javascript" src="./javascript/admin_functions.js"></script>';

	
	switch ($action) {
	
  		case 'logout';
 			setcookie ("deeemm", "", time() - 3600);
  			header("Location: " . $default_url . "index.php");
  		exit;

		case 'messagebox';
			$message = $lan[warning];
			$warning_message = $lan[delete_warning];
	
			$content = $default_url . $templates_dir  . "message_box.tpl";
			$main = read_file($content);
		break;

		//edit  sitemap
		case 'edit_sitemap';
			require 'includes/build_admin_sitemap.php';
		break;

		//edit Cateories
		case 'edit_categories';
			require 'includes/edit_categories.php';
		break;

		//change settings
		case 'edit_settings';
			require 'includes/edit_settings.php';
		break;

		//content = edit static content
		case 'edit_left_column';
		case 'edit_right_column';
		case 'edit_banner';
		case 'edit_footer';
		case 'save_static_content';
			require 'includes/edit_static_content.php';
		break;

		//save settings
		case 'save_settings';
			require 'includes/save_settings.php';
			header("Location: " . $default_url . $admin_dir . "index.php?action=edit_settings");
		break;
		
	    case 'delete_db';
	    	$db_filename = $abs_path . $db_backup_dir . $_REQUEST['db_filename'];
	    	@fclose($db_filename);
	    	unlink($db_filename);
	    	header("Location: index.php?action=edit_settings");
	    break;
	    
		//restore database
		case 'restore_db';
			require 'includes/db_restore.php';
			header("Location: index.php?action=edit_settings");
		break;

		//backup database
		case 'backup_db';
			$db_save_to_file = $_REQUEST['db_save_to_file'];
			require 'includes/db_backup.php';
			header("Location: index.php?action=edit_settings");
		break;

		//display server settings
		case 'phpinfo';
			$content = $admin_url . "templates/phpinfo.tpl";
			$main = read_file($content);
			ob_start();
			phpinfo();                                                                                                        
			$info = ob_get_contents();                                                                                        
			ob_end_clean();                                                                                                   
			$phpinfo = preg_replace('%^.*<body>(.*)</body>.*$%ms', '$1', $info); 
		break;

		//edit users
		case 'find_user';
		case 'user_mod';
		case 'save_user';
		case 'delete_user';
			require 'includes/user_mod.php';
		break;

		//content = edit categories
		case 'move_up_category';
		case 'move_down_category';
		case 'move_up_subcategory';
		case 'move_down_subcategory';
		case 'delete_category';
		case 'save_categories';
		case 'edit_sitemap';
		case 'change_categories';
			require 'includes/edit_sitemap.php';
		break;

		//content = edit / add normal page
		case 'edit';
		case 'add';
			require 'includes/edit_content.php';
		break;

		//content = display add media page
		case 'add_media';
			require 'includes/add_media.php';
		break;

		//content = display add link page
		case 'add_link';
		case 'edit_link';
			require 'includes/edit_link.php';
		break;

		//content = display add link page
		case 'save_link';
			require 'includes/save_link.php';
		break;

		//content = display edit media page
		case 'edit_media';
			require 'includes/edit_media.php';
		break;

		//delete current article data
		case 'delete';
			require 'includes/delete_item.php';
		break;

		//save media article data
		case 'save_media';
			require 'includes/save_media.php';
		break;

		//save current article data
		case 'save_content';
			require 'includes/save_content.php';
		break;

		//edit / save profile
		case 'edit_profile';
			case 'save_profile';
			require 'includes/edit_profile.php';
		break;

//		$article_ref = "index.php?page=$page&child=$child";

		default;
			require 'includes/edit_settings.php';
		break;

	} //end switch $action



/*===========================================================================
Construct the page
===========================================================================*/
$header = read_file("templates/admin_header.tpl");
$banner = read_file("templates/admin_banner.tpl");
$footer = read_file("templates/admin_footer.tpl");
$layout = $header . $banner . $main . $footer;


/*===========================================================================
Replace template markers with variables
===========================================================================*/
$layout = replace_variables($layout);
$layout = replace_language($layout);


/*===========================================================================
Send page to browser
===========================================================================*/
echo $layout;


/*===========================================================================
Tidy Up
===========================================================================*/
mysql_close($db_connection);
ob_end_flush();

?>