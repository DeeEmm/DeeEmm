<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

//===========================================================================

//===========================================================================
//>translate text
//===========================================================================

	//can also use following url directly
	//http://ets.freetranslation.com?language=english/German&sequence=core&srctext=translate

	//language elements
	//English/Spanish
	//English/French
	//English/German
	//English/Italian
	//English/Portuguese
	//English/Norwegian
	//Spanish/English
	//French/English
	//German/English
	//Italian/English
	//Portuguese/English

	$lang_pair = $_GET["lang_pair"];
	$text = $_GET["text"];
  $html_file=fopen("http://translate.google.com/translate_t?lang_pair=$lang_pair&text=$text","r");
  if(!$html_file){
    echo 'The translation server is not responding at the moment - Please try later.';
		exit;
  }
  while(!feof($html_file)){
    $decoded_html.= fgets($html_file);
  }
  fclose($html_file);

//===========================================================================
//<get data from the string
//===========================================================================
	//set search strings
  $start = 'wrap=PHYSICAL>';
  $end = '</textarea>';

	//decode
	$start_position=strpos($decoded_html, $start)+strlen($start);
	$end_position=strpos($decoded_html, $end);
	$length=$end_position-$start_position;
	//get text from string
	$translation=substr($decoded_html, $start_position, $length);
	//return $translation;
	echo $translation;

?>