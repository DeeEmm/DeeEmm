<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Get configuration variables from database and store in associative array

Database table comprises of name => value pair:

Usage

$value = $conf[name];
===========================================================================*/

$conf = array();
$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "core_conf`");

while($row = mysql_fetch_assoc( $sql_query )){

	$conf[$row[name]] = $row[value];
//	${$row[name]} = $row[value];
}
mysql_free_result($sql_query);


/*
foreach ($conf as $key => $value){
	echo $key;
	echo $value;
}
*/


?>