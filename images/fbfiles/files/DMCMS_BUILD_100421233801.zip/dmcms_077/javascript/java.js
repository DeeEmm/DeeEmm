
window.name = "main_window";

//===========================================================================
//>Tiny MCE setup
//===========================================================================

	tinyMCE.init({
		mode : "textareas",
//		elements : "description_lan_1",
		theme : "basic",
		
		plugins : "style,layer,table,save,advhr,advimage,advlink,emotions,iespell,insertdatetime,preview,flash,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,ibrowser",
		theme_advanced_buttons1_add : "separator,insertdate,inserttime,preview,separator",
		theme_advanced_buttons1_add_before : "save,newdocument,separator",
		theme_advanced_buttons2_add : "ibrowser",
		theme_advanced_buttons2_add_before: "cut,copy,paste,pastetext,pasteword,separator,search,replace,separator",
		theme_advanced_buttons3_add_before : "tablecontrols,separator",
		theme_advanced_buttons3_add : "emotions,iespell,flash,advhr",
		theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops",
		theme_advanced_buttons4_add : "print,separator,ltr,rtl,separator,fullscreen",
		theme_advanced_buttons4_add_before : "fontselect,fontsizeselect,forecolor,backcolor",
		
		theme_advanced_disable : "image",

		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
    plugin_insertdate_dateFormat : "%Y-%m-%d",
    plugin_insertdate_timeFormat : "%H:%M:%S",
		extended_valid_elements : "hr[class|width|size|noshade],font[face|size|color|style],span[class|align|style]",
		theme_advanced_styles : "Header 1=header1;Header 2=header2;Header 3=header3;Table Row=tableRow1", // Theme specific setting CSS classes

		debug : false
});		



function submitForm() {
tinyMCE.triggerSave();
document.forms[0].submit();
}

//===========================================================================
//>hover function - dynamic drop down menu - start of son of suckerfish java - from - http://www.htmldog.com/articles/suckerfish/dropdowns/
//===========================================================================

sfHover = function() {
	var sfEls = document.getElementById("navmenu").getElementsByTagName("LI");
	for (var i=0; i<sfEls.length; i++) {
		sfEls[i].onmouseover=function() {
			this.className+=" sfhover";
		}
		sfEls[i].onmouseout=function() {
			this.className=this.className.replace(new RegExp(" sfhover\\b"), "");
		}
	}
}
if (window.attachEvent) window.attachEvent("onload", sfHover);


//===========================================================================
//>Add Text Function
//===========================================================================
function AddText(window, texttoadd) {
	window.value = window.value + texttoadd;
}

//===========================================================================
//>translate function
//===========================================================================
function test() {
	alert('test');
}

//===========================================================================
//>Translate Function
//===========================================================================
function Translate(window_title_lan_2, window_title_lan_3, window_title_lan_4,	window_text_de, window_text_fr, window_text_es, titletotranslate, texttotranslate) {

//	win_title_lan_2 = window_title_lan_2;
//	win_title_lan_3 = window_title_lan_3;
//	win_title_lan_4 = window_title_lan_4;
//	win_text_de = window_text_de;
//	win_text_fr = window_text_fr;
//	win_text_es = window_text_es;
//	update_delay = 3000; //delay in millisecs

//English/Spanish
//English/French
//English/German
//English/Italian
//English/Portuguese
//English/Norwegian
//Spanish/English
//French/English
//German/English
//Italian/English
//Portuguese/English

//http://ets.freetranslation.com?language=english/German&sequence=core&srctext=translate

//call translate.php to get translation
//	frames['title_trans_de'].location.href = 'translate.php?language=english/german&text=' + titletotranslate;
//	frames['title_trans_fr'].location.href = 'translate.php?language=english/french&text=' + titletotranslate;
//	frames['title_trans_es'].location.href = 'translate.php?language=english/spanish&text=' + titletotranslate;
//	frames['text_trans_de'].location.href = 'translate.php?language=english/german&text=' + texttotranslate;
//	frames['text_trans_fr'].location.href = 'translate.php?language=english/french&text=' + texttotranslate;
//	frames['text_trans_es'].location.href = 'translate.php?language=english/spanish&text=' + texttotranslate;

//delay transferring data from iframes to textarea to allow iframes to load
//	setTimeout("transfer(win_title_lan_2, win_title_lan_3, win_title_lan_4, win_text_de, win_text_fr, win_text_es)", update_delay);

}

//===========================================================================
//>Transfer Function
//===========================================================================
function transfer(title_lan_2, title_lan_3, title_lan_4, text_de, text_fr, text_es) {
//	title_lan_2.value = frames('title_trans_de').document.body.innerHTML;
//	title_lan_3.value = frames('title_trans_fr').document.body.innerHTML;
//	title_lan_4.value = frames('title_trans_es').document.body.innerHTML;
//	text_de.value = frames('text_trans_de').document.body.innerHTML;
//	text_fr.value = frames('text_trans_fr').document.body.innerHTML;
//	text_es.value = frames('text_trans_es').document.body.innerHTML;
}

//===========================================================================
//>Clear data from categories form
//===========================================================================
function clear_categories_form() {
document.edit_categories.old_category.value = "";
document.edit_categories.editing_category_message.value = "";
document.edit_categories.category_lan_1.value = "";
document.edit_categories.tool_tip_lan_1.value = "";
document.edit_categories.category_lan_2.value = "";
document.edit_categories.tool_tip_lan_2.value = "";
document.edit_categories.category_lan_3.value = "";
document.edit_categories.tool_tip_lan_3.value = "";
document.edit_categories.category_lan_4.value = "";
document.edit_categories.tool_tip_lan_4.value = "";
document.edit_categories.display_in_margin.type = hidden;
}

//===========================================================================
//>show / hide hidden divs
//===========================================================================
function ReverseContentDisplay(d) {
if(document.getElementById(d).style.display == "none") { document.getElementById(d).style.display = "block"; }
else { document.getElementById(d).style.display = "none"; }
}

function HideContent(d) {
document.getElementById(d).style.display = "none";
}

function ShowContent(d) {
document.getElementById(d).style.display = "block";
}

//===========================================================================
//>Show / hide language editors
//===========================================================================
function select_language(lan) {

	switch(lan)
	{
		case 1:
		{
			ShowContent('lan_1_controls');
			HideContent('lan_2_controls');
			HideContent('lan_3_controls');
			HideContent('lan_4_controls');
			break;
		}
		case 2:
		{
			HideContent('lan_1_controls');
			ShowContent('lan_2_controls');
			HideContent('lan_3_controls');
			HideContent('lan_4_controls');
			break;
		}
		case 3:
		{
			HideContent('lan_1_controls');
			HideContent('lan_2_controls');
			ShowContent('lan_3_controls');
			HideContent('lan_4_controls');
			break;
		}
		case 4:
		{
			HideContent('lan_1_controls');
			HideContent('lan_2_controls');
			HideContent('lan_3_controls');
			ShowContent('lan_4_controls');
			break;
		}
	}
}

//===========================================================================
//>Show / hide media controls on categories form
//===========================================================================
function setup_categories_form() {
	if (document.edit_categories.category_type.value == 'media') 
	{
		ShowContent('hidden_media_controls');
	} else {
		HideContent('hidden_media_controls');
	}
}


//===========================================================================
//>add option to category list
//===========================================================================
function addOption(){
	oCombo = document.edit_media.category;
	oselected_category = document.edit_media.selected_category;

	if(oselected_category.value != "") {
		//First search for duplicates
		for(var i = 0; i < oCombo.options.length ; i++){
			if(oCombo.options[i].text == oselected_category.value)
				return;
		}
		// Add new one
		oCombo.options[oCombo.options.length] = new Option
(oselected_category.value, oselected_category.value);
	}
}



// lose focus {document.getElementById('myAnchor').blur()}