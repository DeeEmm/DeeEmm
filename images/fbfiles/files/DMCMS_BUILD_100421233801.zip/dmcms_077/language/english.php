<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
English.php

This file contains the non-content language elements
===========================================================================*/


/*===========================================================================
Html meta tag in page header
===========================================================================*/
$lan['content_language'] = 'en';

$lan['language_1'] = 'Language 1';
$lan['language_2'] = 'Language 2';
$lan['language_3'] = 'Language 3';
$lan['language_4'] = 'Language 4';

$lan['language_1_flag'] = 'Language 1 Flag';
$lan['language_2_flag'] = 'Language 2 Flag';
$lan['language_3_flag'] = 'Language 3 Flag';
$lan['language_4_flag'] = 'Language 4 Flag';

/*===========================================================================
Language elements
===========================================================================*/
$lan['sitemap'] = 'Site Map';
$lan['admin_sitemap'] = 'Navigation / Site Map';
$lan['admin'] = 'Admin';
$lan['site_administration'] = 'Site Administration';
$lan['change_site_settings'] = 'Change Site Settings';
$lan['media_library'] = 'Media Library';
$lan['archive'] = 'Archive';
$lan['home'] = 'Home';
$lan['warning'] = 'Warning !';
$lan['sorry'] = 'Sorry !';
$lan['general'] = 'General';
$lan['yes'] = 'Yes';
$lan['no'] = 'No';
$lan['add'] = 'Add';
$lan['edit'] = 'Edit';
$lan['delete'] = 'Delete';
$lan['static_content'] = 'Static Content';
$lan['delete_warning'] = 'Are you sure you want to delete';
$lan['media_library_settings'] = 'Media Library Settings';
$lan['language_file_settings'] = 'Language File Settings';
$lan['site_details'] = 'Site Details';
$lan['home_title'] = 'DeeEmm Content Management System';
$lan['change_password'] = 'Change Password';
$lan['old_password'] = 'Old Password';
$lan['new_password'] = 'New Password';
$lan['password_not_changed'] = 'Sorry the password fields did not match, your password has not been changed';
$lan['password_changed'] = 'Your password has been changed';
$lan['confirm_password'] = 'Confirm Password';
$lan['admin_functions'] = 'Admin Functions';
$lan['edit_content'] = 'Edit Content';
$lan['edit_static_content'] = 'Edit Static Content';
$lan['edit_profile'] = 'Edit Profile';
$lan['index'] = 'Home';
$lan['media'] = 'Media';
$lan['select_file'] = 'Select File...';
$lan['browse_to_file'] = 'Browse to File...';
$lan['filelist'] = 'File List';
$lan['copyright'] = 'Copyright';
$lan['trademark_notice'] = 'Notice of Trademarks';
$lan['news'] = 'News';
$lan['login'] = 'Login';
$lan['no_news'] = 'Sorry there are currently no news stories';
$lan['latest_news'] = 'Latest News';
$lan['search_results'] = 'Search Results';
$lan['search_results_for'] = 'Search results for';
$lan['found'] = 'found';
$lan['showing_results'] = 'Showing Results';
$lan['to'] = 'to';
$lan['of'] = 'of';
$lan['with'] = 'with';
$lan['restore'] = 'Restore';
$lan['search_for'] = 'Search for';
$lan['google'] = 'Google';
$lan['search_for'] = 'Search for';
$lan['or'] = 'or';
$lan['search_the'] = 'Search the';
$lan['search'] = 'Search';
$lan['site_search'] = 'Site Search';
$lan['description'] = 'Description';
$lan['index_title'] = 'Welcome';
$lan['media_title'] = 'Media Files';
$lan['view_thumbnails'] = 'View Thumbnails';
$lan['num_files_in_library'] = 'Number of files in Library';
$lan['last_file_added'] = 'Last file added';
$lan['file_no'] = 'File number';
$lan['added_on'] = 'Added on';
$lan['picture'] = 'Picture';
$lan['video'] = 'Video';
$lan['pdf'] = 'PDF';
$lan['zip'] = 'ZIP';
$lan['edit_media'] = 'Edit Media';
$lan['add_media'] = 'Add Media';
$lan['add_article'] = 'Add Article';
$lan['previous_articles'] = 'Previous Articles';
$lan['next'] = 'Next';
$lan['last'] = 'Last';
$lan['list'] = 'List';
$lan['first'] = 'First';
$lan['prev'] = 'Prev';
$lan['news_title'] = 'News';
$lan['news_headlines'] = 'News Headlines';
$lan['site_design'] = '<a href=http://www.deeemm.com>DeeEmm CMS</a>';
$lan['site_name'] = 'Site Name';
$lan['site_description'] = 'Site Description';
$lan['site_admin_email'] = 'Site Admin Email';
$lan['match'] = 'match';
$lan['forum_name'] = 'Forum Name';
$lan['forum_search_url'] = 'Forum Search URL';
$lan['path_to_forum'] = 'Path to Forum';
$lan['db_editor_path'] = 'Database Editor Path';
$lan['matches'] = 'matches';
$lan['hint'] = 'Hint';
$lan['search_warning_text'] = "(The search has returned more than $max_search_results results, please refine your search.)";
$lan['search_tips'] = "Try to refine your search by using the following tips... To reduce the number of search results use a more exact phrase or try to use a more specific word. To increase the number of search results use a less exact phrase or a more general word.";
$lan['mod_category_tool_tip'] = 'Will be displayed when you hover mouse over link';
$lan['mod_category_title_tip'] = 'Max Length = 20 Characters';
$lan['modify_categories'] = 'Modify Categories';
$lan['deeemm_admin_panel'] = 'DeeEmm Admin Panel';
$lan['modify_category'] = 'Modify Category';
$lan['add_edit_category'] = 'Add / Edit Category';
$lan['title'] = 'Title';
$lan['link'] = 'Link';
$lan['tool_tip'] = 'Tool Tip';
$lan['category'] = 'Category';
$lan['select_category'] = 'Select Category';
$lan['main_category'] = 'Main Category';
$lan['media_category'] = 'Media Category';
$lan['category_type'] = 'Category Type';
$lan['other_related_categories'] = 'Other Related Categories';
$lan['related_media_files'] = 'Related Media Files';
$lan['related_categories_tip'] = 'File will appear as thumbnail in `Related Files` section for all checked categories';
$lan['image_size_tip'] = 'Only use images with maximum size of 640*480';
$lan['general_configuration'] = 'General Configuration';
$lan['slideshow'] = 'Slideshow';
$lan['random'] = 'Random';
$lan['num_slideshow_images'] = 'Number of images in slideshow';
$lan['default_media_library_view'] = 'Default Media Library View';
$lan['default_imagebox_view'] = 'Default Imagebox View';
$lan['imagebox_settings'] = 'Imagebox Settings';
$lan['random_media_library_image'] = 'Random Media Library Image (Imagebox)';
$lan['thumbnails_per_page'] = 'Thumbnails Per Page';
$lan['thumbnail_rows_per_page'] = 'Thumbnail Rows Per Page';
$lan['video_hieght'] = 'Video Height';
$lan['video_width'] = 'Video Width';
$lan['upload_file'] = 'Upload File';
$lan['file'] = 'File';
$lan['maximum_upload_file_size'] = 'Max Upload Filesize';
$lan['thumbnail_mask'] = 'Thumbnail Mask';
$lan['forum_configuration'] = 'Forum Configuration';
$lan['enable_forum'] = 'Enable Forum Link';
$lan['enable_login_link'] = 'Enable LogIn Link';
$lan['forum'] = 'Forum';
$lan['current_template'] = 'Current Template';
$lan['forum_integration'] = 'Forum Integration';
$lan['thumbnail_mask_tip'] = '(Hide non-displayable items in thumbnail view)';
$lan['image'] = 'Image';
$lan['display_in_navigation'] = 'Display In Navigation';
$lan['not_in_navigation'] = 'Not In Navigation';
$lan['orphan_pages'] = 'Orphan Pages';
$lan['last_image'] = 'Last Image';
$lan['first_image'] = 'First Image';
$lan['thumbnails'] = 'Thumbnails';
$lan['list_view'] = 'List View';
$lan['history'] = 'History';
$lan['banner'] = 'Banner';
$lan['right_column'] = 'Right Column';
$lan['left_column'] = 'Left Column';
$lan['footer'] = 'Footer';
$lan['editing_category_message_1'] = 'You are editing the category';
$lan['editing_category_message'] = 'To create new category, select type, then add new details below and click save. To edit category click on edit buttons above.';
$lan['edit_banner'] = 'Edit Banner';
$lan['edit_right_column'] = 'Edit Right Column';
$lan['edit_column'] = 'Edit Column';
$lan['edit_left_column'] = 'Edit Left Column';
$lan['edit_footer'] = 'Edit Footer';
$lan['edit_copyright'] = 'Edit Copyright';
$lan['random_image'] = 'Random Image';
$lan['enable_imagebox'] = 'Enable Imagebox';
$lan['enable_media_library'] = 'Enable Media Library';
$lan['select_media_library'] = 'Select Library';
$lan['enable_search'] = 'Enable Site Search Box';
$lan['display_in_margin'] = 'Display in Margin';
$lan['enable_newsbox'] = 'Enable Newsbox';
$lan['enable_multi_language'] = 'Enable Multi-language Support';
$lan['enable_site'] = 'Site is active (Uncheck to disable site)';
$lan['backup'] = 'Backup';
$lan['save_to_file'] = 'Save To File';
$lan['restore_db'] = 'Restore Database';
$lan['backup_db'] = 'Backup Database';
$lan['server_info'] = 'Server Info';
$lan['edit_database'] = 'Edit Database';
$lan['categories'] = 'Categories';
$lan['password'] = 'Password';
$lan['add_user'] = 'Add User';
$lan['delete_user'] = 'Delete User';
$lan['edit_user'] = 'Edit User';
$lan['find_user'] = 'Find User';
$lan['user_mod'] = 'User Mod';
$lan['user_name'] = 'User Name';
$lan['administrator'] = 'Administrator';
$lan['moderator'] = 'Moderator';
$lan['user'] = 'User';
$lan['user_type'] = 'User Type';
$lan['show_comments'] = 'Show Comments';
$lan['allow_comments'] = 'Allow Comment Contributions';
$lan['save_settings'] = 'Save Settings';
$lan['login_prompt'] = 'Please Enter Your Login Details';
$lan['logout'] = 'Logout';
$lan['matching_user_names'] = 'Matching User Names';
$lan['maintenance'] = 'Maintanance';
$lan['maintenance_message'] = 'Sorry the website is unavailable at the moment due to site maintenance. We apologise for any inconvenience';
$lan['maintenance_contact'] = 'If you wish to contact us please send an email to ';

/*===========================================================================
Message box elements
===========================================================================*/
$lan['no_data'] = 'Sorry, there is currently no information in this category.';
$lan['no_media'] = 'Sorry there are currently no media items in this category';
$lan['upload_failed'] = 'Sorry the file upload failed';
$lan['file_exists'] = 'Sorry the file name already exists<br>Please rename the file before uploading or delete existing file';
$lan['image_used'] = 'Cannot Delete Media File - File referred to elsewhere in site -<br> Please remove any association from the items listed below and then try again <br>';
$lan['cannot_delete_user'] = 'Cannot Delete User ';
$lan['user_added'] = 'User Added - ';
$lan['user_deleted'] = 'User Deleted - ';

/*===========================================================================
POPUP MESSAGES
===========================================================================*/
$lan['loginfail'] = 'ERROR! - Login incorrect. Please try again';


?>
