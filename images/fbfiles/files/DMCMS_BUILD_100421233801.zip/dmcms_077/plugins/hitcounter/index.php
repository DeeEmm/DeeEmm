<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Hitcounter

Checks cookie to see if if visit to site is unique
Stores hitcount in configuration parameter $plugin_conf[[hitcounter_value]
Updates cookie to prevent double hits
===========================================================================*/
if (!isset($_COOKIE['hitcounted'])) {
	
	//increment count
	++$plugin_conf[hitcounter_value];
	
	//update database
	mysql_query("UPDATE `" . $db_table_prefix . "plugin_conf` SET`value` = '$plugin_conf[hitcounter_value]' WHERE `name` = 'hitcounter_value'");

	//set cookie
	setcookie("hitcounted" , $plugin_conf[hitcounter_value] );

}

//set variable for use in template
$hitcount = $plugin_conf[hitcounter_value];

?>