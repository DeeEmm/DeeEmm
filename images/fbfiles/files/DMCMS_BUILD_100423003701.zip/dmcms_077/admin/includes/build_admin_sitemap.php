<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Check user priviledges
===========================================================================*/
require VALIDATE;

if ($user != 'ADMIN') header("Location: " . $default_url . "index.php");

$content = "templates/admin_mod_sitemap.tpl";
$main = read_file($content);

/*===========================================================================
Propogate the site map
============================================================================*/

//generate list with links for modifying category
foreach($all_tables as $value){
	$tables_list = '';
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "core_structure` WHERE `table` = '$value'");
	while($sql_result = mysql_fetch_array($sql_query)){
		$type = $sql_result[type];
		$media_library_default_view = $sql_result[media_library_default_view];
		$num_slideshow_images = $sql_result[num_slideshow_images];
		$imagebox_type = $sql_result[imagebox_type];
		$display_in_margin = $sql_result[display_in_margin];
		$display_in_sitemap = $sql_result[display_in_sitemap];
		$allow_comments = $sql_result[allow_comments];
		$category = $sql_result[category_lan_ . $language];
	}

	//get highest order page
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . 'cat_' . "$value` WHERE `id` > 0 ORDER BY `order` LIMIT 1");
	if($sql_result = mysql_fetch_array($sql_query)){
		$id = $sql_result[id];
		$link_url = $sql_result[link_url];
	}

	//get main heading

	switch ($type) {

		case 'list';
		case 'normal';
			if (isset($link_url) && $link_url <> '') {
			$tables_list .= str_replace($value, 
			"<HR size='1px' color='#ddd' class='clear_both'>
			<div class='nav_entry'><span class='float_right'>
				<a href='$default_url".$admin_dir."index.php?action=add'>
					<img class='icon' title='Add Item to Category' src='$default_url"."admin/icons/article_add.gif'>
				</a> 
				<a href='$default_url".$admin_dir."index.php?action=add_link'>
					<img class='icon' title='Add Link to Category' src='$default_url"."admin/icons/link_add.gif'>
				</a> 
				<a href='$default_url".$admin_dir."index.php?category=$value&amp;action=move_down_category'>
					<img class='icon' title='Move Down' src='$default_url"."admin/icons/article_move_down.gif'>
				</a> 
				<a href='$default_url"."$admin_dir"."index.php?category=$value&amp;action=move_up_category'>
					<img class='icon' title='Move Up' src='$default_url"."admin/icons/article_move_up.gif'>
				</a>&nbsp;
				<a href='$default_url"."$admin_dir"."index.php?action=edit_categories&amp;category=$value#1'>
					<img class='icon' title='Edit' src='$default_url"."admin/icons/article_edit.gif'>
				</a>&nbsp;
				<a href='$default_url"."$admin_dir"."index.php?action=delete_category&amp;category=" . $value. "' onClick=\"javascript:return confirm('[lan]delete_warning[/lan] $value ?')\">
					<img class='icon' title='Delete' src='$default_url".$templates_dir."images/icons/article_delete.gif'>
				</a>
			</span>
			<img class='icon' title='$type' src='$default_url" . "admin/icons/$type.gif'>&nbsp;&nbsp;
				<a class='sitemap_item' href='" . $link_url . "'>" . $category . "</A></div>"
			, $value);
			
			} else {
			
			$tables_list .= str_replace($value, 
			"<HR size='1px' color='#ddd' class='clear_both'>
			<div class='nav_entry'><span class='float_right'>
			<a href='$default_url".$admin_dir."index.php?action=add'>
				<img class='icon' title='Add Item to Category' src='$default_url"."admin/icons/article_add.gif'>
			</a> 
			<a href='$default_url".$admin_dir."index.php?action=add_link'>
				<img class='icon' title='Add Link to Category' src='$default_url"."admin/icons/link_add.gif'>
			</a> 
			<a href='$default_url".$admin_dir."index.php?category=$value&amp;action=move_down_category'>
				<img class='icon' title='Move Down' src='$default_url"."admin/icons/article_move_down.gif'>
			</a> 
			<a href='$default_ur"."$admin_dirl"."index.php?category=$value&amp;action=move_up_category'>
				<img class='icon' title='Move Up' src='$default_url"."admin/icons/article_move_up.gif'>
			</a>&nbsp;
			<a href='$default_url"."$admin_dir"."index.php?action=edit_categories&amp;category=$value#1'>
				<img class='icon' title='Edit' src='$default_url"."admin/icons/article_edit.gif'>
			</a>&nbsp;
			<a href='$default_url"."$admin_dir"."index.php?action=delete_category&amp;category=" . $value. "' onClick=\"javascript:return confirm('[lan]delete_warning[/lan] $value ?')\">
				<img class='icon' title='Delete' src='$default_url" . "admin/icons/article_delete.gif'>
			</a>
			</span>
				<img class='icon' title='$type' src='$default_url" . "admin/icons/$type.gif'>&nbsp;&nbsp;
			<a class='sitemap_item' href='$default_url"."index.php?page=" . $value . "&amp;id=$id'>" . $category . "</A></div>"
			, $value);
			}
		break;

		case 'media';
			$tables_list .= str_replace($value, 
			"<HR size='1px' color='#ddd' class='clear_both'>
			<div class='nav_entry'><span class='float_right'>
			<a href='$default_url"."$admin_dir"."index.php?action=add_media'>
				<img class='icon' title='Add Media to Category' src='$default_url"."admin/icons/article_add.gif'>
			</a> 
			<a href='$default_url"."$admin_dir"."index.php?category=$value&amp;action=move_down_category'>
				<img class='icon' title='Move Up' src='$default_url"."admin/icons/article_move_down.gif'>
			</a> 
			<a href='$default_url".$admin_dir."index.php?category=$value&amp;action=move_up_category'>
				<img class='icon' title='Move Up' src='$default_url"."admin/icons/article_move_up.gif'>
			</a>&nbsp;
			<a href='$default_url"."$admin_dir"."index.php?action=edit_categories&amp;category=$value#1'>
				<img class='icon' title='Edit' src='$default_url"."admin/icons/article_edit.gif'>
			</a>&nbsp;
			<a href='$default_url"."$admin_dir"."index.php?action=delete_category&amp;category=" . $value . "' onClick=\"javascript:return confirm('[lan]delete_warning[/lan] $value ?')\">
				<img class='icon' title='Delete' src='$default_url" . "admin/icons/article_delete.gif'>
			</a>
			</span>
			<img class='icon' title='$type' src='$default_url" . "admin/icons/$type.gif'>&nbsp;&nbsp;
			<a class='sitemap_item' href='$default_url"."index.php?page=" . $value . "'>" . $category . "</A></div>", $value);
		break;
	}


	//get sub heading
	$sql_query  = mysql_query("SELECT * FROM `" . $db_table_prefix . 'cat_' . "$value` ORDER BY `order`");
	while ($sql_result = mysql_fetch_array($sql_query)){
		$title = $sql_result[title_lan_ . $language];
		$id = $sql_result[id];
		$link_url = $sql_result[link_url];

		if ($type == 'normal'){
			if (isset($link_url) && $link_url <> '') {
				$tables_list .= str_replace($value, 
				"<div class='nav_entry'>
				<ul><span class='float_right'>
				<a href='$default_url"."$admin_dir"."index.php?id=$id&amp;category=$value&amp;action=move_down_subcategory'>
				<img class='icon' title='Move Down' src='$default_url"."admin/icons/article_move_down.gif'>
				</a> 
				<a href='$default_url"."$admin_dir"."index.php?id=$id&amp;category=$value&amp;action=move_up_subcategory'>
				<img class='icon' title='Move Up' src='$default_url"."admin/icons/article_move_up.gif'>
				</a>&nbsp;
				<a href='$default_url"."$admin_dir"."index.php?page=$value&amp;id=$id&amp;action=edit_link'>
				<img class='icon' title='Edit' src='$default_url"."admin/icons/link_edit.gif'>
				</a>&nbsp;
				<a href='$default_url"."$admin_dir"."index.php?page=$value&amp;id=$id&amp;action=delete' onClick=\"javascript:return confirm('[lan]delete_warning[/lan]')\">
				<img class='icon' title='Delete' src='$default_url"."admin/icons/link_delete.gif'>
				</a>
				</span>
				<img class='icon' title='link' src='$default_url" . "admin/icons/link.gif'>&nbsp;&nbsp;
				<a class='sitemap_item' href='$link_url'>" . $title . "</A></ul></div>", $value);
			} else {
				$tables_list .= str_replace($value, 
				"<div class='nav_entry'>
				<ul><span class='float_right'>
				<a href='$default_url"."$admin_dir"."index.php?id=$id&amp;category=$value&amp;action=move_down_subcategory'>
				<img class='icon' title='Move Down' src='$default_url"."admin/icons/article_move_down.gif'>
				</a> 
				<a href='$default_url"."$admin_dir"."index.php?id=$id&amp;category=$value&amp;action=move_up_subcategory'>
				<img class='icon' title='Move Up' src='$default_url"."admin/icons/article_move_up.gif'>
				</a>&nbsp;
				<a href='$default_url"."$admin_dir"."index.php?page=$value&amp;id=$id&amp;action=edit'>
				<img class='icon' title='Edit' src='$default_url"."admin/icons/article_edit.gif'>
				</a>&nbsp;
				<a href='$default_url"."$admin_dir"."index.php?page=$value&amp;id=$id&amp;action=delete' onClick=\"javascript:return confirm('[lan]delete_warning[/lan]')\">
				<img class='icon' title='Delete' src='$default_url"."admin/icons/article_delete.gif'>
				</a>
				</span><img class='icon' title='$type' src='$default_url" . "admin/icons/page.gif'>&nbsp;&nbsp;
				<a class='sitemap_item' href='../index.php?page=" . $value . "&amp;id=$id'>" . $title . "</A></ul></div>", $value);
			}
		}
	}
	
	$tables_list = str_replace('  ', '', $tables_list);
	
	if (isset($display_in_sitemap) && $display_in_sitemap <> ''){
		$sitemap_list .= $tables_list;
	} else {
		$non_sitemap_list .= $tables_list;
	}
}
if (!$non_sitemap_list) $non_sitemap_list = "<span><center>No content available</center></span>";


/*===========================================================================
Propogate the static content list
===========================================================================*/
$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "static_content`");
while($sql_result = @mysql_fetch_array($sql_query))
{
	$title = $sql_result[title_lan_ . $language];
	$id = $sql_result[id];
	$static_content_list .= str_replace($value, "<div class='nav_entry'><span class='float_right'><a href='$default_url".$admin_dir."index.php?page=static_content&amp;action=edit&amp;id=" . $id . "'><img class='icon' title='Edit' src='$default_url"."admin/icons/article_edit.gif'></a>&nbsp<a href='$default_url".$admin_dir."index.php?page=static_content&amp;action=delete&amp;id=" . $id . "' onClick=\"javascript:return confirm('$lan[delete_warning] $value ?')\"><img class='icon' title='Delete' src='$default_url"."admin/icons/article_delete.gif'></a></span><img class='icon' title='$type' src='$default_url".$templates_dir."images/icons/page.gif'>&nbsp;&nbsp;<a class='sitemap_item' href='$default_url"."index.php?page=static_content&amp;id=" . $id . "'>" . $title . "</A><br><br></div><br>", $value);
}
if (!$id) $static_content_list = "<span><center>No static content available<c/enter></span>";
	
/*===========================================================================
Propogate the orphan page list
===========================================================================*/
$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "orphan`");
while($sql_result = @mysql_fetch_array($sql_query))
{
	$title = $sql_result[title_lan_ . $language];
	$id = $sql_result[id];
	$orphan_list .= str_replace($value, "<div class='nav_entry'><span class='float_right'><a href='$default_url".$admin_dir."index.php?page=orphan&amp;action=edit&amp;id=" . $id . "'><img class='icon' title='Edit' src='$default_url"."admin/icons/article_edit.gif'></a>&nbsp<a href='$default_url".$admin_dir."index.php?page=orphan&amp;action=delete&amp;id=" . $id . "' onClick=\"javascript:return confirm('[lan]delete_warning[/lan] $value ?')\"><img class='icon' title='Delete' src='$default_url" . "admin/icons/article_delete.gif'></a></span><img class='icon' title='$type' src='$default_url".$templates_dir . "images/icons/page.gif'>&nbsp;&nbsp;<a class='sitemap_item' href='$default_url"."index.php?page=orphan&amp;id=" . $id . "'>" . $title . "</A><br><br></div><br>", $value);
}
if (!$id) $orphan_list = "<span><center>No orphan pages available</center></span>";

/*===========================================================================
Create and propogate the sitemap editor
===========================================================================*/

$sitemap_editor = replace_variables($sitemap_editor);


?>
