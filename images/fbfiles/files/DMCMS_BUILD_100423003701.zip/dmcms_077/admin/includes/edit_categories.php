<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Check user priviledges
===========================================================================*/
require VALIDATE;

if ($user != 'ADMIN') header("Location: " . $default_url . "index.php");

$javascript_onload = 'setup_categories_form();';

$content = "templates/admin_mod_categories.tpl";
$main = read_file($content);

/*===========================================================================
Propogate the site map
============================================================================*/

//generate list with links for modifying category
foreach($all_tables as $value){
	$tables_list = '';
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "core_structure` WHERE `table` = '$value'");
	while($sql_result = mysql_fetch_array($sql_query)){
		$type = $sql_result[type];
		$media_library_default_view = $sql_result[media_library_default_view];
		$num_slideshow_images = $sql_result[num_slideshow_images];
		$imagebox_type = $sql_result[imagebox_type];
		$display_in_margin = $sql_result[display_in_margin];
		$display_in_sitemap = $sql_result[display_in_sitemap];
		$allow_comments = $sql_result[allow_comments];
		$category = $sql_result[category_lan_ . $language];
	}
}


$editing_category_message = $lan[editing_category_message];



//check if category is being editied if so propogate text boxes
$category = strtolower($_REQUEST['category']);

if (isset($category) && $category <> '') {
	$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "core_structure` WHERE `table` = '$category'");
	while($sql_result = mysql_fetch_array($sql_query)){
		$display_in_margin = $sql_result[display_in_margin];
		$display_in_sitemap = $sql_result[display_in_sitemap];
		$media_library_default_view = $sql_result[media_library_default_view];
		$num_slideshow_images = $sql_result[num_slideshow_images];
		$imagebox_type = $sql_result[imagebox_type];
		$allow_comments = $sql_result[allow_comments];
		$category_lan_1 = $sql_result[category_lan_1];
		$tool_tip_lan_1 = $sql_result[tool_tip_lan_1];
		$category_lan_2 = $sql_result[category_lan_2];
		$tool_tip_lan_2 = $sql_result[tool_tip_lan_2];
		$category_lan_3 = $sql_result[category_lan_3];
		$tool_tip_lan_3 = $sql_result[tool_tip_lan_3];
		$category_lan_4 = $sql_result[category_lan_4];
		$tool_tip_lan_4 = $sql_result[tool_tip_lan_4];
	}

	if ($media_library_default_view == 'thumbnails') $sitemap_editor = str_replace('[var]thumbnails[/var]', 'checked="true"', $sitemap_editor);
	if ($media_library_default_view == 'list') $sitemap_editor = str_replace('[var]list_view[/var]', 'checked="true"', $sitemap_editor);
	if ($media_library_default_view == 'first') $sitemap_editor = str_replace('[var]first_image[/var]', 'checked="true"', $sitemap_editor);
	if ($media_library_default_view == 'last') $sitemap_editor = str_replace('[var]last_image[/var]', 'checked="true"', $sitemap_editor);
	if ($imagebox_type == 'slideshow') $sitemap_editor = str_replace('[var]slideshow[/var]', 'checked="true"', $sitemap_editor);
	if ($imagebox_type == 'random') $sitemap_editor = str_replace('[var]random[/var]', 'checked="true"', $sitemap_editor);
	if ($display_in_margin == 'on') $sitemap_editor = str_replace('[var]display_in_margin[/var]', 'checked="true"', $sitemap_editor);
	if ($display_in_sitemap == 'on') $sitemap_editor = str_replace('[var]display_in_sitemap[/var]', 'checked="true"', $sitemap_editor);
	if ($allow_comments == 'on') $sitemap_editor = str_replace('[var]allow_comments[/var]', 'checked="true"', $sitemap_editor);

	$old_category = $category;
	$editing_category_message = $lan[editing_category_message_1] . " '" . $category . "'";
}


/*===========================================================================
Generate the category type drop down menu
===========================================================================*/
$category_type = '';

$type = 'normal'; //set default list type to display
//get current type
$sql_query  = mysql_query("SELECT * FROM `" . $db_table_prefix . "core_structure` WHERE `table` LIKE '$category'");
while ($sql_result = mysql_fetch_array($sql_query)){
	$type = $sql_result[type];
}

//get all possible types from database + active type
$sql_query  = mysql_query("SHOW COLUMNS FROM `" . $db_table_prefix . "core_structure` LIKE 'type'");
$sql_result = mysql_fetch_row($sql_query);
preg_match_all("/'(.*?)'/", $sql_result[1], $temp_array);
$category_types = array_unique($temp_array);
sort($category_types);
//create drop down list
$category_type = "<select class='w100pcnt' name='category_type' onchange='setup_categories_form()'>". $crlf . "<option value='$type'>$type</option>" . $crlf;
foreach($category_types[0] as $value) {
	$value = str_replace('\'', '', $value);
	if ($value != $type){
		$category_type .= "<option value='$value'>$value</option>";
	}
}
$category_type = str_replace('  ', '', $category_type);
$category_type .= '</select>';


?>
