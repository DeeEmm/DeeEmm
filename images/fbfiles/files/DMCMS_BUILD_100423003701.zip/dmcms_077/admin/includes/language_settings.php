<?php
defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Check user priviledges
===========================================================================*/
require VALIDATE;
if ($user != 'ADMIN') header("Location: " . $default_url . "index.php");


/*===========================================================================
admin page
===========================================================================*/
function language_admin() {
	global $conf;
	global $lan;
	global $var;


	//Get page details
	$var[page_title] .= ' :: ' . $lan[edit_language_settings];
	$var[cookie_trial] .= ' :: ' . $lan[edit_language_settings];
	$var[admin_title] = $lan[edit_language_settings];
	
	$content = "templates/admin_mod_language.tpl";
	$main = read_file($content);
	
	if ($conf[multi_language]) $main = str_replace('[conf]multi_language[/conf]', 'checked="true"', $main);
	
	//count number of languages in lang_conf table
	$num_langs = count($lang_conf);
	
	//generate and propogate textboxes
	
	return $main;
}


/*===========================================================================
get_languages
===========================================================================*/
function get_languages(){
	global $conf;
	global $lang_conf;
	
	//count number of languages in lang_conf table
	$num_langs = count($lang_conf);
	
	
	foreach ($lang_conf as $key => $value){
		
	}
	
	


}

/*===========================================================================
add_language
===========================================================================*/
function add_language(){


}

/*===========================================================================
delete_language
===========================================================================*/
function delete_language($language_id){


}

/*===========================================================================
Save_language_settings
===========================================================================*/
function save_language_settings(){
	global $db_table_prefix;
	global $conf;
	
	//Get user input
	$conf[multi_language] = $_REQUEST['multi_language'];

	//Update values
	foreach ($conf as $key => $value){
		mysql_query("UPDATE `" . $db_table_prefix . "core_conf` SET `value` = '$value' WHERE `name` = '$key'");
	}
	
	//count number of languages in lang_conf table
	$num_langs = count($lang_conf);
	
	//read values in from form
	
	//Save to database
	
	
}




//[FIXME - LANGUAGE HANDLING CHANGED - SPLIT INTO SEPERATE SECTION]
/*
$conf[language_1] = $_REQUEST['language_1'];
$conf[language_1_flag] = $_REQUEST['language_1_flag'];
$conf[language_2] = $_REQUEST['language_2'];
$conf[language_2_flag] = $_REQUEST['language_2_flag'];
$conf[language_3] = $_REQUEST['language_3'];
$conf[language_3_flag] = $_REQUEST['language_3_flag'];
$conf[language_4] = $_REQUEST['language_4'];
$conf[language_4_flag] = $_REQUEST['language_4_flag'];*/





?>