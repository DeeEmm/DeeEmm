<?php
defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Check user priviledges
===========================================================================*/
require VALIDATE;

if ($user != 'ADMIN') header("Location: " . $default_url . "index.php");


/*===========================================================================
Get user input
===========================================================================*/
$conf[site_name] = $_REQUEST['site_name'];
$conf[site_description] = $_REQUEST['site_description'];
$conf[site_is_active] = $_REQUEST['site_is_active'];
$conf[admin_email] = $_REQUEST['admin_email'];
$conf[db_editor_path] = $_REQUEST['db_editor_path'];
$conf[login_link_enabled] = $_REQUEST['login_link_enabled'];
$conf[search_enabled] = $_REQUEST['search_enabled'];
$conf[current_template] = $_REQUEST['current_template'];

/*===========================================================================
Update values
===========================================================================*/
foreach ($conf as $key => $value){
	mysql_query("UPDATE `" . $db_table_prefix . "core_conf` SET `value` = '$value' WHERE `name` = '$key'") ;
}


?>