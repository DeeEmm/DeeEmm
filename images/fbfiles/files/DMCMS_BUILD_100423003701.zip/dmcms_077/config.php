<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Change the details below to get your site up and running

1. Change $default_url to the default url of your site
2. Change $db_username to your database username
3. Change $db_password to the password of the above user
4. Change $db_name to the name of your database

You may also need to change the following settings, but for most server setups
the standard settings should work just fine:

5. Change $db_server to the IP address of your SQL server if different from your webserver
	Default value - 
	$db_server = 'localhost'; 
	
6. Change $abs_path if your website does not reside in the document root
	Default Value - 
	$abs_path 			= dirname(__FILE__) . '/';
===========================================================================*/

$default_url 		= 'http://localhost/dmcms_077/'; //$_SERVER["HTTP_HOST"]
$db_username 		= 'DeeEmm'; 
$db_password 		= 'DeeEmm'; 
$db_name 			= 'dmcms_077'; 

$db_server 			= 'localhost'; 
$abs_path 			= dirname(__FILE__) . '/';

/*===========================================================================
Miscellaneous settings - change these to suit your site

[FIXME] - revise for SEO - should be set on per page basis!!
===========================================================================*/
$author 			= 'Mick Percy';
$meta_keywords 		= 'DeeEmm CMS, DMCMS, Open Source Content Management Software';
$header_copyright 	= "Copyright " . date ("Y") . " DMCMS";

/*===========================================================================
Setup the envoironment
===========================================================================*/
$templates_dir 		= 'templates/';
$stylesheet 		= 'default.css';
$media_dir 			= 'media/';
$admin_dir 			= 'admin/';
$db_backup_dir 		= 'db_backups/';
$core_dir 			= 'core/';
$plugins_dir 		= 'plugins/';
$includes_dir 		= 'includes/';
$updates_dir 		= 'updates/';
$language_dir 		= 'language/';

$admin_url			= $default_url . $admin_dir;

/*===========================================================================
It is not reccomended to change the following line.
===========================================================================*/
$db_table_prefix 	= 'dm_';

?>
