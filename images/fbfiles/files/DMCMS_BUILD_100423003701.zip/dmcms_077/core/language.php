<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Get language info from database and store in associative array

id
description
iso_code
===========================================================================*/

$lang_conf = array();
$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "lang_conf`");

while($row = mysql_fetch_assoc( $sql_query )){
	$lang_conf[] = $row;
}

mysql_free_result($sql_query);

/*===========================================================================
Check cookie for language
===========================================================================*/
if (!isset($_COOKIE["deeemm_language"])) {
  $language = '1';
  session_start();
  $_SESSION['language'] = $language;
  header("Cache-control: private"); //IE6 session control fix
  header('P3P: CP="NOI ADM DEV PSAi COM NAV OUR OTRo STP IND DEM"'); //bypass 3rd party policy
  setcookie("deeemm_language" ,$language ,time()+60*60*12*365 );
}
  elseif (isset($_COOKIE["deeemm_language"])) {
  session_start();
  header("Cache-control: private"); //IE6 session control fix
  $language = $_COOKIE["deeemm_language"];
}


//Set session info - set cookie = language
if ($page=="1" || $page=="2" || $page=="3" || $page=="4") {
  $language = $page;
  setcookie("deeemm_language" ,$language ,time()-1 );
  setcookie("deeemm_language" ,$language ,time()+60*60*12*365 );
  $page='';
}


/*===========================================================================
Select current langauge file
===========================================================================*/
$language_file = $abs_path . $language_dir . $lang_conf[$language][description] . '.php';
require $language_file;



?>