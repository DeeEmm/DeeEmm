<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

/*===========================================================================
Get registered plugins
===========================================================================*/

$plugin_list = array();
$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "plugin_list`");

while($row = mysql_fetch_assoc( $sql_query )){

	$plugin_list[$row[name]] = $row[is_registered];

}
mysql_free_result($sql_query);



/*===========================================================================
Get plugin config variables from database
===========================================================================*/

$plugin_conf = array();
$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "plugin_conf`");

while($row = mysql_fetch_assoc( $sql_query )){

	$plugin_conf[$row[name]] = $row[value];

}
mysql_free_result($sql_query);


/*===========================================================================
load registered plugins
===========================================================================*/

foreach ($plugin_list as $plugin => $enabled){

	if ($enabled == 'TRUE'){
		//get plugin files
		require $abs_path . $plugins_dir . $plugin . '/index.php';	
	}
} 


?>