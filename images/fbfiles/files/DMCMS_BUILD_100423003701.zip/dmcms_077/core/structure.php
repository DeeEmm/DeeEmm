<?php
defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

$admin_email = convert2ascii($conf[admin_email]);	

/*===========================================================================
Get site structure from database
===========================================================================*/
/*
$sql_query = mysql_query("SHOW TABLES");
while($sql_result = mysql_fetch_array($sql_query)){
	if ($sql_result[0] <> $db_table_prefix .'admin' && $sql_result[0] <> $db_table_prefix .'static_content' && $sql_result[0] <> $db_table_prefix .'admin' && $sql_result[0] <> $db_table_prefix .'users' && $sql_result[0] <> $db_table_prefix .'structure')
	$all_tables[] .= $sql_result[0];
}
*/

/*===========================================================================
Get site structure from database
===========================================================================*/
//count number of tables in structure
$sql_result = mysql_query("SELECT count(*) from `" . $db_table_prefix . "core_structure`");
$num_tables = @mysql_result($sql_result,0);

/*===========================================================================
Create array of ALL pages in structure
===========================================================================*/
$all_tables = array();
$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "core_structure` ORDER BY `order`");
while($sql_result = mysql_fetch_array($sql_query)){
	$all_tables[] .= $sql_result[table];
}

/*===========================================================================
Create array of all MEDIA pages in structure
===========================================================================*/
unset($imagebox_libraries);
$media_tables = array();
$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "core_structure` WHERE `type` = 'media' ORDER BY `order`");
while($sql_result = mysql_fetch_array($sql_query)){
	$media_tables[] .= $sql_result[table];
	//create array of all imagebox libraries
	if ($sql_result[display_in_margin] == 'on'){
		$imagebox_libraries[] .= $sql_result[table];
	}
}

/*===========================================================================
Create array of all unique CATEGORIES in MEDIA LIBRARIES
===========================================================================*/
$media_categories = array();
foreach($media_tables as $value){
	$sql_query = mysql_query("SELECT DISTINCT `category` FROM `" . $db_table_prefix . 'cat_' . $value . "`");
	while($sql_result = mysql_fetch_array($sql_query)){
		if (!in_array($sql_result[category], $media_categories)){
			$media_categories[] .= $sql_result[category];
		}
	}
}

/*===========================================================================
Create array of all LIST pages in structure
===========================================================================*/
unset($newsbox_libraries);
$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "core_structure` WHERE `type` LIKE 'list' ORDER BY `order`");
while($sql_result = mysql_fetch_array($sql_query)){
	$list_tables[] .= $sql_result[table];
	//create array of all newsbox libraries
	if ($sql_result[display_in_margin] == 'on'){
		$newsbox_libraries[] .= $sql_result[table];
	}
}

/*===========================================================================
Create array of all NORMAL pages in structure
===========================================================================*/
$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "core_structure` WHERE `type` = 'normal' ORDER BY `order`");
while($sql_result = mysql_fetch_array($sql_query)){
	$normal_tables[] .= $sql_result[table];
}

/*===========================================================================
Create array of all STATIC pages
===========================================================================*/
$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "static_content`");
while($sql_result = mysql_fetch_array($sql_query)){
	$static_pages[] .= $sql_result[category];
}

/*===========================================================================
Create array of all ORPHAN pages
===========================================================================*/
$sql_query = mysql_query("SELECT * FROM `" . $db_table_prefix . "static_content`");
while($sql_result = mysql_fetch_array($sql_query)){
	$orphan_pages[] .= $sql_result[category];
}


?>