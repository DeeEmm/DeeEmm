<?php

defined( '_INDM' ) or die( 'POSSIBLE HACK ATTEMPT!' );

//===========================================================================

$new_version = '0.6.4 (BETA)';

/*===========================================================================
//>update version number
===========================================================================*/
mysql_query("UPDATE `" . $db_table_prefix . "admin` SET `version` = '$new_version' WHERE `id` = 0") OR DIE ("<b>A fatal MySQL error occured</b>.\n<br />Query: " . $sql_query . "<br />\nError: (" . mysql_errno() . ") " . mysql_error());
echo $version . ' -> ' . $new_version . ' Update<br><br>';    


/*===========================================================================
//>update control tables in database
===========================================================================*/
mysql_query("ALTER TABLE `" . $db_table_prefix . "core_users` ADD UNIQUE(`user_name`)") OR DIE ("<b>A fatal MySQL error occured</b>.\n<br />Query: " . $sql_query . "<br />\nError: (" . mysql_errno() . ") " . mysql_error());
mysql_query("ALTER TABLE `" . $db_table_prefix . "core_structure` ADD `allow_comments` varchar(2) NOT NULL AFTER `display_in_sitemap`") OR DIE ("<b>A fatal MySQL error occured</b>.\n<br />Query: " . $sql_query . "<br />\nError: (" . mysql_errno() . ") " . mysql_error());


/*===========================================================================
//>update non control (content) tables in database
===========================================================================*/
//No changes

?>