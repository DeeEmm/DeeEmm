<!---------------------------------------------------------------------------
nautilus.php version 0.7

Dolphin to JomSocial Migrator

Written by DeeEmm AKA Michael Percy. 

Copyright (c)2011 DeeEmm Web Technologies

http://www.DeeEmm.com
-----------------------------------------------------------------------------

"GIVE A MAN A FISH AND HE WILL EAT FOR A DAY
	TEACH A MAN TO FISH, AND HE WILL SIT IN A BOAT AND DRINK BEER" (George Carlin)

-----------------------------------------------------------------------------
PLEASE NOTE.
-----------------------------------------------------------------------------

This script is copyright 2011 DeeEmm Web Technologies. www.DeeEmm.com

This script is free to use and distribute provided that it remains in 
it's unmodified form. If you wish to make improvements, or add functionality,
please post your modifications to the forums at www.DeeEmm.com so that others 
may benefit. 'Pay it forward' ;)

If you like this script make sure you post about it! Let everyone know that 
there IS an alternative to the buggy, overpriced, oversold, undersupported
and eternally in beta Dolphin 'fish script'.

-----------------------------------------------------------------------------
HISTORY 
-----------------------------------------------------------------------------

Version 0.7
21.09.11
- Forum migration finished
- Added truncate table commands for each module

Version 0.6 
20.09.11
- Added ability to choose items for export
- Created HTML interface
- Updated to work with Joomla 1.7 / JomSocial 2.2.4 / Kunena 1.7.0

Version 0.5 
19.09.11
- Photo comment migration
- Video comment migration
- Convert HTML to BB code

Version 0.4 
01.09.11
- Changed installation method for photo transfer
- Finished photo migration testing
- Testing video migration

Version 0.3 
31.08.11 
- Finished Forum migration
- Testing photo migration

Version 0.2 
30.08.11 TODO
- Forums topics and posts migration
- Photo comment migration
- Groups migration

Version 0.1 
29.08.11 Initial Version

-----------------------------------------------------------------------------
TODO
-----------------------------------------------------------------------------

Add error notification + fix erroneous error messages for file transfers

Groups Migration
.htaccess rules for photos / videos / blogs / forums / profiles
Script to remove dolphin tables from database
navigation structure
articles 
links (sites)
blogs (wordpress)
add check for script versions

-----------------------------------------------------------------------------
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! WARNING !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
-----------------------------------------------------------------------------

1/ To use this script you will need to be able to read and understand, with 
100% clarity, the following instructions. You will need a basic knowledge of 
web management to be able to perform this migration. If you cannot read, or do 
not understand the instructions, or do not feel confident to perform the migration, 
or are worried that you might fuck things up, then our advice is please go and 
pay a professional to fuck it up for you. 

2/ DeeEmm Web Technologies will not accept any responsibilities for any losses, 
real, perceived or otherwise, for the the use or misuse of this script. Basically
if you fuck it up, don't come crying to us (see #1 above)

3/ DeeEmm Web Technologies give this script freely on the understanding that it 
will be used at the sole risk of the user. DeeEmm Web Technologies do not imply 
that using this script will definitely migrate your website FROM the Dolphin 
platform to the Jomsocial platform, but in all likelihood it should work ok.

4/ With respect to #3. Please note that in our opinion, even a fucked up JomSocial 
installation is much more desirable than a 'fully functional' Fish Script installation.

5/ :D

6/ Before you bitch about the increased setting up that JomSocial requires, please 
consider that whilst Dolphin may include eveything in one installation package, you 
will only need to install JomSocial ONCE! Nothing will require fixing. It will simply 
work - out of the box, first time.

7/ Please do not complain that the components required are commercial and not free. 
If you run a free Boonex Dolphin site with a couple of dozen members, then this is 
probably not the thing for you. If you are tired of investing many $$$'s in a 
Fish Script site that STILL does not meet your expectations, then read on... 

8/ The JomSocial trial can be obtained for just $1. The standard version is only $99. 
If you wait you will often find that they have deals - at the time of writing this 
they have a 25% off sale. You can also enter the coupon code shareme-d2wltr to get 
$10 off. JomComment is normally $20. The only other commercial component you will 
need is the corephp wordpress component, which is well worth the $69. Don't be 
tempted to use the MyBlog component offered by Azrul (JomSocial). It sucks. Both 
Kunena (forum component) and Akeeba (backup component) are free. 

9/ Did we mention no bitching or moaning?? Please remember that I donated my free 
time to help you, by providing you with this script for free. If you don't like the 
script. Don't use it! It's that simple! 

10/ If you really liked this script. Go tell everyone to migrate to JomSocial ;).

-----------------------------------------------------------------------------
!!!! BY RUNNING THIS SCRIPT YOU ACCEPT THAT YOU USE IT AT YOUR OWN RISK !!!!!
-----------------------------------------------------------------------------




-----------------------------------------------------------------------------
COMPATIBILITY
-----------------------------------------------------------------------------


This script has been tested with the following versions

Dolphin 7.0.4
http://www.boonex.com

Joomla 1.7 
http://www.joomla.org

JomSocial 2.2.4
http://www.jomsocial.com/

Kunena 1.7 
http://www.kunena.org/download

corePHP Wordpress component version 
http://www.corephp.com

-----------------------------------------------------------------------------
PRE-REQUISITES
-----------------------------------------------------------------------------

1/ Backup your Boonex Dolphin files and MySQL database
2/ Download Joomla. 
3/ Download JomSocial extension
4/ Download JomComment extension
5/ [Optional] Download Kunena extension (user forums)
6/ [Optional] Download Akeeba extension (backup management)
7/ [Optional] Download corephp Wordpress extension (blogs)

We reccommend that you consider installing the AKEEBA Backup extension to manage taking 
backups of your site. This can also be automated by the use of a cron job.

If you intend to migrate your forums you will need to install the KUNENA 
extension. This is a mature forum that fully integrates with JomSocial and is 
comparible in features and operation with phpBB or SMF

The corephp Wordpress extension is the best wordpress integration that I have 
found. As with some of the other components, it is not free, but worth the small
amount it costs. Please note that there are two ways to install Wordpress. For it to
function in a similar manner to Dolphin (multi user) it will need to be configured
as multisite.

-----------------------------------------------------------------------------
QUICK INSTALLATION INSTRUCTIONS

A/ Install Joomla
B/ Install JomSocial component
C/ Install additional components 
D/ Run migration script
E/ tweak settings to get everything running properly
E/ Delete old files
-----------------------------------------------------------------------------
DETAILED INSTALLATION INSTRUCTIONS

1/  BACKUP YOUR WEBSITE FILES
2/  BACKUP YOUR DATABASE
3/  Create a folder called 'boonex' in your web root
4/  Move EVERYTHNG from your Dolphin installation into this folder (including hidden files such as .htaccess)
5/  Copy contents of boonex/modules/boonex/avatar/data/images/ to /images/avatar/
6/  Upload the Joomla files to your webroot
7/  Navigate to your website root in your browser, you should see the Joomla installer
8/  Follow the on screen instructions to install Joomla 

	NOTE !! When it asks you to put in the database name user and password info USE THE 
	SAME details as your dolphin installation !! This is important as otherwise this script
	WILL NOT WORK !!

9/  Log into admin panel at http://yoursite.com/admistrator
10/  Navigate to Extensions > Extension Manager
11/ Browse to the JomSocial component + click upload to install it
12/ If required repeat installation for Kunena forum / JomComments / Wordpress components
13/ Run this script

14/ Perform the following post installation actions to set up your site

- go to extensions > template manager
- click on 'Beez2 - Default' to edit the template
- edit the title + description
- Remove / change the current logo
- save + close
- go to extensions > module manager
- click on green status arrow for 'main menu' and 'login form' to disable them (arrows will turn red)
- go to menus > main menu
- click on star in 'home' column for jomsocial to set jomsocial as home page (star will turn yellow)
- go to site > global configuration
- edit site name / metadata as required
- enable url rewriting (you will also need to rename htaccess.txt to .htaccess in webroot)
- save + close

That's It!

-----------------------------------------------------------------------------
LIMITATIONS / THINGS TO NOTE
-----------------------------------------------------------------------------

1/ Only standard Dolphin tables will be imported. Modified tables may not work.
1/ The joomla admin user you created on installation is copied to userid 9999999 
2/ You can use this user id to log into the administration panel. 
3/ Dolphin user #1 is made into a superadmin (user #1 is normally admin)
4/ Old passwords will not work. All user passwords will need to be reset via the password reset function
5/ Facebook connect will need to be set up again -  Please note - default settings will pull data in from facebook (avatar etc)
6/ Groups are not currently migrated (set for future version)
7/ Old URL's will not work so SEO will be affected (updated .htaccess planned for future version)
8/ Only basic HTML is converted to Kunena BB code in forum post conversion. More complex requirements
will need modification of the html2kbb function.
9/ Forum view counts will be zero as this is not recorded in Dolphin


-----------------------------------------------------------------------------
POST_INSTALLATION
-----------------------------------------------------------------------------

1/ Delete the boonex folder
2/ Delete the dolphin tables from the database (you can use this script to do it automatically)
3/ Delete this file
4/ Relax.
5/ Crack open a cold one
6/ Raise your glass to finally being rid of the fish script.

Cheers! :D

-----------------------------------------------------------------------------
HINTS, TIPS, & TWEAKING
-----------------------------------------------------------------------------

If you are new to Joomla / JomSocial there are a few handy things to know...

Joomla 'Modules' are similar to Dolphin 'Blocks' you can change module types 
and positions in the admin panel. Modules are available for many extensions to 
help display data FROM the extension on your site. eg latest forum posts. 

Module positions are set in the template. To view available module positions 
you can add the following to the end of the URL ?tp=1 You will need to also 
enable this in the template for the module positions to be displayed.

Menus are also controlled by modules, so to add a menu you need to add a menu module to 
the relevent module position. Check out the standard modules to get an idea of 
how they work. This means you can have multiple menus.

Extensions are similar to dolphin modules. You can search for extensions in the 
'JED' (Joomla Extensions Directory). Most Jooma extensions are free. 
Make sure you select extensions that are compatible with your installation 
version. Also, read the comments as they most often give a good idea of the 
provenance of the extension.

As JomSocial is a joomla extension, to get other extensions to interact with it, 
it might be necessary to install plugins. So when looking for extension, check 
to see if they are JomSocial compatible. 

For example. Installing the kunena JomSocial plugin allows the kunena posts to 
be included in the JomSocial activity feed. 

To install an component / extension. 

1/ Log INTO the admin control panel at http://yoursite.com/administrator 
2/ Browse to extensions > extension manager
3/ Click the 'choose file' button in the 'upload package file' section, 
4/ Browse to the extension package (it should be a zip file) 
5/ Hit 'upload & install' button

The Extension will automagically be installed. 

Check the 'Components' menu as there should now be a link to administrate your new component.

If the installation fails it will tell you with an error message.


-----------------------------------------------------------------------------
SUPPORT
-----------------------------------------------------------------------------

Support is provided in the forums on www.DeeEmm.com ONLY!!

Do not email me. 
Do not PM me. 
Do not post on some other forum and expect to get a reply to your question. 
Do not post support questions to the comments section of my site.

If it's not posted to the correct forum... 

...YOU WILL NOT GET A REPLY. 

Simple-As!

I will endeavor to answer all posts, but please remember that not only do 
I do this in my spare time, but I am probably in a diferent time zone to you, 
so you might not get an answer immediately. A little patience is key ;)

Please also consider that you will need a basic knowledge of web management to
be able to perform this migration. If you are asking basic or retarded questions,
or questions about something that is explained in these instructions I will simply 
ignore you, or maybe even take this piss.

Also. If you know the answer to a question posted by another user, please help them
by answering it for them. It helps me, it helps them and you will also go to a 
better place in the next life. 

Remember - Kudos is free. Pay it forward.

-----------------------------------------------------------------------------
http://www.deeemm.com
---------------------------------------------------------------------------->

<?php

/*===========================================================================
JOOMLA INTEGRATION
-----------------------------------------------------------------------------

Set up framework / database connection / authentication etc...

(should be the same for J1.7)
===========================================================================*/
define( '_JEXEC', 1 );
define('JPATH_BASE', dirname(__FILE__));
define( 'DS', DIRECTORY_SEPARATOR );
require_once ( JPATH_BASE .DS.'includes'.DS.'defines.php' );
require_once ( JPATH_BASE .DS.'includes'.DS.'framework.php' );

/* Create the Application */
$mainframe =& JFactory::getApplication('site');

/* Make sure we are logged in. */
if (JFactory::getUser()->id == 0)
    die("Access denied: Login required. <br><br>Click back on your browser and log into site before running this script.");

//echo 'Logged in as "' . JFactory::getUser()->username . '"';

$db =& JFactory::getDBO();



/*===========================================================================
SETUP VARIABLES
-----------------------------------------------------------------------------

Get post data submitted in form

===========================================================================*/

//Table prefix
$TP = '#__';

//Joomla Version
$JomVersion = '1.7'; // 1.6

//get post data from form
$ParseForm = $_POST["ParseForm"];
$SetupJomsocial = $_POST["SetupJomsocial"];
$MigrateProfiles = $_POST["MigrateProfiles"];
$MigrateAvatars = $_POST["MigrateAvatars"];
$MigrateFriends = $_POST["MigrateFriends"];
$MigratePhotos = $_POST["MigratePhotos"];
$MigrateVideos = $_POST["MigrateVideos"];
$MigrateForums = $_POST["MigrateForums"];
$MigrateEvents = $_POST["MigrateEvents"];
$MigrateBlogs = $_POST["MigrateBlogs"];
$MigrateGroups = $_POST["MigrateGroups"];
$MigrateSites = $_POST["MigrateSites"];
$MigrateContent = $_POST["MigrateContent"];
$MigrateModzzzPoints = $_POST["MigrateModzzzPoints"];
$DropBoonexTables = $_POST["DropBoonexTables"];



/*===========================================================================
SETUP JOMSOCIAL
-----------------------------------------------------------------------------

Set menu links
===========================================================================*/
if ($SetupJomsocial){

	//Update home link on menu to JomSocial
	$query = "UPDATE `#__menu` SET `home` = '0' WHERE `title` = 'home'";
	$db->setQuery($query);
	$result = $db->query();
	$query = "UPDATE `#__menu` SET `home` = '1' WHERE `title` = 'jomsocial'";
	$db->setQuery($query);
	$result = $db->query();


	echo '<br>Navigation Menu updated<br>';


	//Unpublish modules
	$query = "UPDATE `#__modules` SET `published` = '0' WHERE `title` = 'Main Menu'";
	$db->setQuery($query);
	$result = $db->query();
	$query = "UPDATE `#__modules` SET `published` = '0' WHERE `title` = 'Login Form'";
	$db->setQuery($query);
	$result = $db->query();


	echo '<br>Uneeded Modules Unpublished<br>';


	//DO SOME OTHER STUFF TOO...

}



/*===========================================================================
IMPORT USERS + PROFILES
-----------------------------------------------------------------------------

User name fields set to same as nickname as no name fields in Dolphin
User password fields are not able to be transferred - password reset required
User access level all set to 'members' except userid #1 = superuser

J1.7
jos_usergroups
jos_user_profiles

jos_users
jos_user_usergroup_map

Standard profile fields transferred. 
Can add custom fields but #__community_fields table will need to be updated
Add htaccess rule

===========================================================================*/
if ($MigrateProfiles){
	
	//Change default Joomla admin user
	$query = "UPDATE `#__users` SET `id` = '9999999' WHERE `id` = '42'";
	$db->setQuery($query);
	$result = $db->query();
	$query = "UPDATE `#__user_usergroup_map` SET `user_id` = '9999999' WHERE `user_id` = '42'";
	$db->setQuery($query);
	$result = $db->query();
	
	//To populate #__users table
	$query = "INSERT INTO #__users (id, username, name, password, usertype, block, email, registerDate, lastvisitDate) SELECT ID, NickName, NickName, Password, 'Registered', '0', Email, DateReg, DateLastLogin FROM Profiles";
	$db->setQuery($query);
	$result = $db->query();
	
	//Set user #1 as super admin
	$query = "UPDATE `#__users` SET `usertype` = 'Super User' WHERE `id` = '1'";
	$db->setQuery($query);
	$result = $db->query();
	
	//To populate #__user_usergroup_map
	$query = "INSERT INTO #__user_usergroup_map (user_id, group_id) select id, '2' FROM Profiles";
	$db->setQuery($query);
	$result = $db->query();

	//update super users
	$query = "UPDATE `#__user_usergroup_map` SET `group_id` = '8' WHERE `user_id` = '1'";
	$db->setQuery($query);
	$result = $db->query();
	$query = "UPDATE `#__user_usergroup_map` SET `group_id` = '8' WHERE `user_id` = '9999999'";
	$db->setQuery($query);
	$result = $db->query();
	


	//depreciated in Joomla 1.7...
	/*
	//To populate #__core_acl_aro table
	$query = "INSERT INTO  #__core_acl_aro (section_value, value, name) select 'users', ID, NickName FROM Profiles;";
	$db->setQuery($query);
	$result = $db->query();
	
	//To populate #__core_acl_groups_aro_map
	$query = "INSERT INTO #__core_acl_groups_aro_map (group_id, aro_id) select '18', id FROM #__core_acl_aro;";
	$db->setQuery($query);
	$result = $db->query();
	*/
	
	echo '<br>Users Migrated<br>';

	//populate description
	$query = "INSERT INTO #__community_fields_values (user_id, field_id, value) select id, '4', DescriptionMe FROM Profiles";
	$db->setQuery($query);
	$result = $db->query();

	//populate DOB
	$query = "INSERT INTO #__community_fields_values (user_id, field_id, value) select id, '3', DateOfBirth FROM Profiles";
	$db->setQuery($query);
	$result = $db->query();

	//populate country
	$query = "INSERT INTO #__community_fields_values (user_id, field_id, value) select id, '11', Country FROM Profiles";
	$db->setQuery($query);
	$result = $db->query();

	//populate city
	$query = "INSERT INTO #__community_fields_values (user_id, field_id, value) select id, '10', City FROM Profiles";
	$db->setQuery($query);
	$result = $db->query();

	//populate sex
	$query = "INSERT INTO #__community_fields_values (user_id, field_id, value) select id, '2', Sex FROM Profiles";
	$db->setQuery($query);
	$result = $db->query();

	//populate profile status's
	$query = "INSERT INTO #__community_users (userid, status, view ) select ID, UserStatusMessage, views FROM Profiles";
	$db->setQuery($query);
	$result = $db->query();


	echo '<br>Profiles Migrated<br>';
	

}


/*===========================================================================
IMPORT POINTS
-----------------------------------------------------------------------------

Import point totals from MODZZZ POINTS modification
===========================================================================*/
if ($MigrateModzzzPoints) {
	$query = "UPDATE #__community_users u, modzzz_point_points m SET u.points = m.points WHERE u.userid = m.member_id";
	$db->setQuery($query);
	$result = $db->query();
	
	echo '<br>Points Migrated<br>';
}



/*===========================================================================
IMPORT FRIENDS
-----------------------------------------------------------------------------

Import friends
===========================================================================*/
if ($MigrateFriends){

	//drop existing data
	$query = "TRUNCATE TABLE `#__community_connection` ";
	$db->setQuery($query);
	$result = $db->query();
	
	$query = "INSERT INTO #__community_connection (connect_FROM, connect_to, status, created) select `ID`, `Profile`, `Check`, `When` FROM sys_friend_list";
	$db->setQuery($query);
	$result = $db->query();

	echo '<br>Friends Migrated<br>';
}


/*===========================================================================
IMPORT USER AVATARS
-----------------------------------------------------------------------------

Manual transfer of avatar images required
Bug - newest avatar not being set in SQL (multiple avatars stored in dolphin)

Manually copy contents of boonex/modules/boonex/avatar/data/images/ to /images/avatar/
===========================================================================*/
if ($MigrateAvatars){

	//drop existing data
	$query = "TRUNCATE TABLE `#__community_users` ";
	$db->setQuery($query);
	$result = $db->query();
	
	//Copy data
	$query = "UPDATE #__community_users u, bx_avatar_images b SET u.avatar = concat(concat('images/avatar/', b.id), '.jpg') WHERE u.userid = b.author_id";
	$db->setQuery($query);
	$result = $db->query();
	$query = "UPDATE #__community_users u, bx_avatar_images b SET u.thumb = concat(concat('images/avatar/', b.id), '.jpg') WHERE u.userid = b.author_id";
	$db->setQuery($query);
	$result = $db->query();

	echo '<br>Avatar Info Migrated<br>';

	
	// open handle 
	$handle = opendir("boonex/modules/boonex/avatar/data/images");

	// Copy files
	while (false !== ($file = readdir($handle))) {
		
		$SourceFile = "boonex/modules/boonex/avatar/data/images/" . $file;
		$TargetFile = "images/avatar/" . $file;
		
		if ($file !== '.' && $file !== '..'){
		
			if (copyemz($SourceFile, $TargetFile)) {    
				echo $SourceFile . ' -> ' . $TargetFile . ' moved successfully<br>';
			} else {
				echo "failed to move $SourceFile ...<br>";
			}
		}
		
	}

	// close directory
	closedir($handle);


}

/*===========================================================================
IMPORT EVENTS
-----------------------------------------------------------------------------

Some data mis-matched (location versus city/state/country).
Event avatars stored with normal photos so selective copying required.

Copy event specific images FROM boonex/modules/boonex/photos/data/xxx.jpg to images/avatar/events/xxx.jpg

Add htaccess rule

===========================================================================*/
if ($MigrateEvents){
	
	//drop existing data
	$query = "TRUNCATE TABLE `#__community_events` ";
	$db->setQuery($query);
	$result = $db->query();
	
	//Copy data
	$query = "INSERT INTO #__community_events (title, location, description, creator, startdate, enddate, avatar, thumb, hits ) select `Title`, `Place`, `Description`, `ResponsibleID`, FROM_UNIXTIME(EventStart), FROM_UNIXTIME(EventEnd), concat(concat('images/avatar/events/', PrimPhoto),'.jpg'), concat(concat('images/avatar/events/', PrimPhoto),'_t.jpg'), Views FROM bx_events_main";
	$db->setQuery($query);
	$result = $db->query();

	//copy event images
	$query = "SELECT PrimPhoto FROM bx_events_main";
	$db->setQuery($query);
	$row = $db->loadAssocList();

	$count = count($row);
	for ($i = 0; $i < $count; $i++) {
	
		$SourceFile = './boonex/modules/boonex/photos/data/' . $row['count']['PrimPhoto'] . '.jpg';
		$DestFile = './images/avatar/events/' . $row['count']['PrimPhoto'] . '.jpg';
	
		//copy file
		if (!copyemz($SourceFile, $DestFile)) {    
			echo "failed to copy $DestFile ...";
		} else {
			echo $SourceFile . ' -> ' . $DestFile . ' copied successfully';
		}
	
	}

	echo '<br>Events Migrated<br>';

}

/*===========================================================================
IMPORT PHOTOS
-----------------------------------------------------------------------------

create photo albums
migrate photos 
copy files FROM boonex/modules/boonex/photos/data/files/... to ./images/
migrate photo comments
Add htaccess rule

TODO 
Photo albums / user albums (My Photos)
Photo comments
===========================================================================*/
if ($MigratePhotos){

	//drop existing data
	$query = "TRUNCATE TABLE `#__community_photos_albums` ";
	$db->setQuery($query);
	$result = $db->query();
	$query = "TRUNCATE TABLE `#__community_photos` ";
	$db->setQuery($query);
	$result = $db->query();
	
	//create album for each user
	$query = "INSERT INTO #__community_photos_albums (id, creator, name, description, permissions, created, path, type) select ID, ID, NickName, Concat(NickName, '`s photos'),'0', DateReg, concat(concat('images/photos/', ID),'/'), 'user' FROM Profiles";
	$db->setQuery($query);
	$result = $db->query();

	//migrate photos
	$query = "INSERT INTO #__community_photos (id, albumid, caption, published, creator, permissions, image, thumbnail, original, created, hits) SELECT id, Owner, Title, '1', Owner, '0',  concat('images/photos/', concat(Owner, concat('/',concat(id, '_m.jpg')))), concat('images/photos/', concat(Owner, concat('/',concat(id, '_t.jpg')))), concat('images/originalphotos/', concat(Owner, concat('/',concat(id, '.jpg')))), FROM_UNIXTIME(Date), Views FROM bx_photos_main";
	$db->setQuery($query);
	$result = $db->query();

	//set album cover image
	$query = "UPDATE #__community_photos_albums a, #__community_photos p SET a.photoid = (select p.id FROM #__community_photos LIMIT 1) WHERE a.creator = p.creator";
	$db->setQuery($query);
	$result = $db->query();

	//copy photos
	$query = "SELECT * FROM #__community_photos";
	$db->setQuery($query);
	$row = $db->loadAssocList();

	$count = count($row);


	echo $count;
	for ($i = 0; $i < $count; $i++) {
	
		//copy original size photos to new location
		$SourceFile = './boonex/modules/boonex/photos/data/files/'  . $row[$i]['id'] . '.jpg';
		$DestPath = './images/originalphotos/' . $row[$i]['creator'] . '/';
		$DestFilename = $row[$i]['id'] . '.jpg';
		$TargetFile = $DestPath . $DestFilename;

		//create the user directory
		if(mkdir($DestPath , 0777, true)) { 
			echo "Directory $DestPath has been created successfully...<br>"; 
		} else { 
			echo "Failed to create $DestPath directory...<br>"; 
		}	

		if (copyemz($SourceFile, $TargetFile)) {    
			echo $SourceFile . ' -> ' . $DestFilename . ' copied successfully<br>';
		} else {
		echo "failed to copy $DestFilename ...<br>";
		}


		//copy medium size photos to new location
		$SourceFile = './boonex/modules/boonex/photos/data/files/' . $row[$i]['id'] . '_m.jpg';
		$DestFilename = $row[$i]['id'] . '._m.jpg';	
		$DestPath = './images/photos/' . $row[$i]['creator'] . '/';
		$TargetFile = $DestPath . $DestFilename;
		
		//create the user directory
		if(mkdir($DestPath , 0777, true)) { 
			echo "Directory $DestPath has been created successfully...<br>"; 
		} else { 
			echo "Failed to create $DestPath directory...<br>"; 
		}

		if (copyemz($SourceFile, $TargetFile)) {    
			echo $SourceFile . ' -> ' . $DestFilename . ' copied successfully<br>';
		} else {
			echo "failed to copy $DestFilename ...<br>";
		}
		
	
		//copy thumbnails to new location
		$SourceFile = './boonex/modules/boonex/photos/data/files/' . $row[$i]['id'] . '_t.jpg';
		$DestFilename = $row[$i]['id'] . '_t.jpg';
		$TargetFile = $DestPath . $DestFilename;

		if (copyemz($SourceFile, $TargetFile)) {    
			echo $SourceFile . ' -> ' . $DestFilename . ' copied successfully<br>';
		} else {
			echo "failed to copy $DestFilename ...<br>";
		}
	}

	echo '<br>Photos Migrated<br>';

	//Migrate photo comments
	$query = "INSERT INTO #__community_wall (id, contentid, post_by, ip, comment, date, published, type) select '', cmt_object_id, cmt_author_id, '', cmt_text, cmt_time, '1', 'photos' FROM bx_photos_cmts";
	$db->setQuery($query);
	$result = $db->query();

	echo '<br>Photo Comments Migrated<br>';

}


/*===========================================================================
IMPORT VIDEOS
-----------------------------------------------------------------------------

oldpath = boonex/flash/modules/video/files/
newpath = videos/originalvideos/
===========================================================================*/
if ($MigrateVideos){

	//drop existing data
	$query = "TRUNCATE TABLE `#__community_videos` ";
	$db->setQuery($query);
	$result = $db->query();
	
	//migrate video info
	$query = "INSERT INTO #__community_videos (id, title, type, video_id, Description, creator, Created, permissions, hits, published, status, path) SELECT id, Title, Source, Video, Description, Owner, FROM_UNIXTIME(Date), '0', Views,  1, 'ready', concat('videos/originalvideos/', concat(Owner, concat('/',concat(id, '.mpg')))) FROM RayVideoFiles";
	$db->setQuery($query);
	$result = $db->query();
	
	//copy videos
	$query = "SELECT id FROM #__community_videos";
	$db->setQuery($query);
	$row = $db->loadAssocList();
	
	$count = count($row);
	for ($i = 0; $i < $count; $i++) {
		
		//copy videos to new location
		$SourceFile = './boonex/flash/modules/video/files/' . $row[$count]['id'] . '.mpg';
		$DestFile = './videos/originalvideos/' . $row[$count]['id'] . '.mpg';
		if (!copyemz($SourceFile, $DestFile)) {    
			echo "failed to copy $DestFile ...";
		} else {
			echo $SourceFile . ' -> ' . $DestFile . ' copied successfully';
		}
	
		//copy thumbs to new location
		$SourceFile = './boonex/flash/modules/video/files/' . $row[$count]['id'] . '_small.jpg';
		$DestFile = './videos/originalvideos/' . $row[$count]['id'] . '_small.jpg';	
		if (!copyemz($SourceFile, $DestFile)) {    
			echo "failed to copy $DestFile ...";
		} else {
			echo $SourceFile . ' -> ' . $DestFile . ' copied successfully';
		}
	
	}

	echo '<br>Videos Migrated<br>';
	
	//Migrate Video comments
	$query = "INSERT INTO #__community_wall (id, contentid, post_by, ip, comment, date, published, type) select '', cmt_object_id, cmt_author_id, '', cmt_text, cmt_time, '1', 'videos' FROM bx_videos_cmts";
	$db->setQuery($query);
	$result = $db->query();

	echo '<br>Video Comments Migrated<br>';

}

/*===========================================================================
IMPORT FORUMS
-----------------------------------------------------------------------------

bx_forum_cat - categories
bx_forum - forums
bx_forum_topic - topics [not needed]
bx_forum_post - posts

catid = forum_id
thread = topic_id of first post
parent = topic_id id of previous post. First post in series has value of '0'

TODO - Need to fix reply count.

1) First message in the topic has always parent=0
2) Rest of the messages have parent=firstid or any previous post in the topic/thread
3) Thread points always to id of the first message
4) catid is always the same as first messages catid

===========================================================================*/
if ($MigrateForums){

	//Set up forums
	
	//create menu link
	$query = "INSERT INTO ttaim_menu (menutype, title, alias, path, link, type, published, level ) VALUES ('jomsocial', 'Forums', 'forums', 'forum', 'index.php?option=com_kunena&view=entrypage', 'component', '1', '1')";
	$db->setQuery($query);
	$result = $db->query();
	
	//drop existing demo forums + posts
	$query = "TRUNCATE TABLE `#__kunena_categories` ";
	$db->setQuery($query);
	$result = $db->query();
	$query = "TRUNCATE TABLE `#__kunena_messages` ";
	$db->setQuery($query);
	$result = $db->query();
	$query = "TRUNCATE TABLE `#__kunena_messages_text` ";
	$db->setQuery($query);
	$result = $db->query(); 
	

	//create forums
	$query = "INSERT INTO #__kunena_categories ( id, parent, name, description, published, pub_access, pub_recurse, admin_access, admin_recurse, accesstype) SELECT forum_id, concat(cat_id, '000'), forum_title, forum_desc, '1', '0','1','1', '1', 'joomla.level' FROM bx_forum";
	$db->setQuery($query);
	$result = $db->query();
	
	//create categories
	$query = "INSERT INTO #__kunena_categories (id, parent, name, published, pub_access, pub_recurse, admin_access, admin_recurse) select concat(cat_id,'000'), '0', cat_name,'1', '1', '1', '1','1' FROM bx_forum_cat";
	$db->setQuery($query);
	$result = $db->query();
	
	echo '<br>Forum Categories Migrated<br>';	
	
	//migrate posts
	//$query = "INSERT INTO  #__kunena_messages (id, catid, parent, thread, name, userid, subject, time) SELECT `post_id`, forum_id , `topic_id`, `topic_id`, `user`, (SELECT id FROM #__users WHERE username = user), (SELECT topic_title FROM bx_forum_topic WHERE bx_forum_topic.topic_id = bx_forum_post.topic_id LIMIT 1),`when` FROM  bx_forum_post";
	$query = "INSERT INTO  #__kunena_messages (id, catid, parent, thread, name, userid, subject, time) SELECT `post_id`, forum_id , '0', `topic_id`, `user`, (SELECT id FROM #__users WHERE username = user), (SELECT topic_title FROM bx_forum_topic WHERE bx_forum_topic.topic_id = bx_forum_post.topic_id LIMIT 1),`when` FROM  bx_forum_post";
	$db->setQuery($query);
	$result = $db->query();	

	//update num posts in categories
	$query = "UPDATE #__kunena_categories c, #__kunena_messages m SET c.numPosts = (SELECT COUNT(*) FROM #__kunena_messages WHERE #__kunena_messages.catid = c.id)";
	$db->setQuery($query);
	$result = $db->query();
	
	
	//get max value for thread / parent
	$query = "SELECT MAX(thread) FROM #__kunena_messages";
	$db->setQuery($query);
	$maxval = $db->loadResult();
	
	//walk through each entry
	for ($i = 0; $i < $maxval; $i++) {
	
		//find first post in thread 
		$query = "SELECT MIN(id) FROM #__kunena_messages WHERE `thread` = '$i'";
		$db->setQuery($query);
		$idval = $db->loadResult();
	
	
		//update thread to point at first post id
		$query = "UPDATE `#__kunena_messages` SET `thread` = '$idval' WHERE `thread` = '$i'";
		$db->setQuery($query);
		$result = $db->query();
			
	}
	
	//migrate message text
	$query = "INSERT INTO  #__kunena_messages_text (mesid, message) select post_id, post_text FROM bx_forum_post";
	$db->setQuery($query);
	$result = $db->query();

	echo '<br>Forum Posts Migrated<br>';
	
	//convert HTML into BB code
	$query = "SELECT MAX(mesid) FROM #__kunena_messages_text";
	$db->setQuery($query);
	$count = $db->loadResult();	
	
	//walk through each post and convert HTML to Kunana BB Code
	for ($i = 0; $i < $count; $i++) {
	
		$message = null;
		$converted = null;
	
		//get post from database
		$query = "SELECT message FROM #__kunena_messages_text WHERE mesid = $i";
		$db->setQuery($query);
		$message = $db->loadResult();
		
		//if post is present convert it to BB Code
		if ($message) {
	
			$converted = html2kbb($message);
		
			$query = "UPDATE `#__kunena_messages_text` SET `message` = '$converted' WHERE `mesid` = '$i'";
			$db->setQuery($query);
			$message = $db->loadResult();
		}
	
	
	}

	echo '<br>Forum Posts Converted to BB Code<br>';

}

/*===========================================================================
IMPORT GROUPS
-----------------------------------------------------------------------------

There are no group forums in JomSocial so we need to import the posts into
the bulletin boards.
===========================================================================*/
if ($MigrateGroups){

	//TODO

	echo '<br>Groups not migrated - Feature disabled<br>';

}


/*===========================================================================
IMPORT BLOGS
-----------------------------------------------------------------------------

To migrate the blogs you will first need to install the CorePHP wordpress 
component
===========================================================================*/
if ($ImportBlogs){

	//TODO

	echo '<br>Blogs not migrated - Feature disabled<br>';
}



/*===========================================================================
IMPORT CONTENT
-----------------------------------------------------------------------------

Create categories
Migrate articles
===========================================================================*/
if ($ImportContent){

	//TODO

	echo '<br>Content not migrated - Feature disabled<br>';
}




/*===========================================================================
DELETE BOONEX TABLES FROM DATABASE
-----------------------------------------------------------------------------

Drop tables that do not have the '#__' prefix
NOTE!! this will delete ALL tables not associated with Joomla
===========================================================================*/
if ($DropBoonexTables == TRUE){

	//get array of tables in database
	$query = "SHOW TABLES";
	$db->setQuery($query);
	$all_tables = $db->loadResultArray();

	//get array of joomla tables
	$query = "SHOW TABLES LIKE '#__%'";
	$db->setQuery($query);
	$joomla_tables = $db->loadResultArray();
	
	//get array of differences
	$boonex_tables = array_diff($all_tables, $joomla_tables);	

	//recurse through array deleting tables
	$count = count($all_tables);
	for ($i = 0; $i < $count; $i++) {
		//DROP TABLES
		if ($boonex_tables[$i]){
			echo $boonex_tables[$i] . ' Deleted.<br>';
			$query = "DROP TABLE IF EXISTS " . $boonex_tables[$i];
			$db->setQuery($query);
			$result = $db->query();
		}
	}	

	echo '<br>Boonex Tables Dropped (yay!)<br>';

}



/*===========================================================================
FUNCTION HTML2kbb
-----------------------------------------------------------------------------

Convert HTML tags into Kunena BB style tags

This function is not exhaustive and there may be additional formatting or tags 
that are not correctly converted. However, in most cases the function should 
suffice. If you have a forum with excessive use of text formatting, or specific
flash object embedding, you may have to customise this function to acccommodate
this. 
===========================================================================*/
function html2kbb($html2kbb) {

	if ($html2kbb){

		//convert hrefs
		$html2kbb = preg_replace('/<a\s[^>]*href=\"([^\"]*)\"[^>]*>(.*)<\/a>/siU', '[url="$1" ]$1[/url]', $html2kbb); 

		//convert smileys before images
		$html2kbb = str_replace('<img src="../plugins/tiny_mce/plugins/emotions/img/smiley-laughing.gif" border="0" alt="Laughing" title="Laughing" />',':D',  $html2kbb);
		$html2kbb = str_replace('<img src="../plugins/tiny_mce/plugins/emotions/img/smiley-embarassed.gif" border="0" alt="Embarassed" title="Embarassed" />',':-[',  $html2kbb);
		//...more to add ...

		//convert images
		$html2kbb = preg_replace('/<img\s[^>]*src=\"([^\"]*)\"[^>]*\/>/siU', '[img]$1[/img]', $html2kbb); 

		//convert <p> + <br> tags
		$html2kbb=str_replace("<br>", "\r\n", $html2kbb);
		$html2kbb=str_replace("<br/>", "\r\n", $html2kbb);
		$html2kbb=str_replace("<br 	/>", "\r\n", $html2kbb);
		$html2kbb=str_replace("<p>", "\r\n", $html2kbb);
		$html2kbb=str_replace("</p>", "\r\n", $html2kbb);

		//convert headings
		$html2kbb = str_replace('<h2>', '[b]', $html2kbb);
		$html2kbb = str_replace('</h2>', '[/b]\r\n', $html2kbb);
		$html2kbb = str_replace('<h3>', '[b]', $html2kbb);
		$html2kbb = str_replace('</h3>', '[/b]\r\n', $html2kbb);
		$html2kbb = str_replace('<h4>', '[b]', $html2kbb);
		$html2kbb = str_replace('</h4>', '[/b]\r\n', $html2kbb);
		$html2kbb = str_replace('<h5>', '[b]', $html2kbb);
		$html2kbb = str_replace('</h5>', '[/b]\r\n', $html2kbb);
		$html2kbb = str_replace('<h6>', '[b]', $html2kbb);
		$html2kbb = str_replace('</h6>', '[/b]\r\n', $html2kbb);

		$html2kbb = str_replace('<strong>', '[b]', $html2kbb);
		$html2kbb = str_replace('</strong>', '[/b]', $html2kbb);
		$html2kbb = str_replace('<em>', '[i]', $html2kbb);
		$html2kbb = str_replace('</em>', '[/i]', $html2kbb);

		//strip everything else...
		$html2kbb = strip_tags($html2kbb);

		return($html2kbb);		

	}

}


/*===========================================================================
COPY FILES FUNCTION
-----------------------------------------------------------------------------

Server permissions may stop this from working!
If your files don't copy - check your permissions
===========================================================================*/
function copyemz($file1,$file2){ 
	$contentx =@file_get_contents($file1); 
	$openedfile = fopen($file2, "w"); 
	fwrite($openedfile, $contentx); 
	fclose($openedfile); 
	if ($contentx === FALSE) { 
	$status=false; 
	}else $status=true; 
 
	return $status; 
} 


?>

<html>

<h2>DeeEmm Web Technologies</h2>

<h3>Dolphin to Joomla (Jomsocial) Migrator V 0.7 BETA</h3>

<hr>

<p><strong>IMPORTANT!!</strong> Before attempting to use this script, right click this page and select view source, then read the instructions contained in the comments of this file. </p>

<hr>

<p>To migrate, simply select the checkboxes below.</p>

<form name="nautilus" action="./nautilus.php" method="POST">

<fieldset>
<legend>Setup</legend>
<br>
<input type=hidden name="ParseForm" value="TRUE">
<input type=checkbox name="SetupJomsocial" checked="true"> Setup Jomsocial (recommended)<br>
<input type=checkbox name="DropBoonexTables"> Drop Boonex tables (Please ensure successfull migration first)
<br>
</fieldset>
<br>

<fieldset>
<legend>Select modules to migrate (select one or more - you can do them one at a time if you like)</legend>
<br>
<input type=checkbox name="MigrateProfiles" checked="true"> Migrate Profiles (recommended)<br>
<input type=checkbox name="MigrateAvatars"> Migrate Avatars<br>
<input type=checkbox name="MigrateFriends"> Migrate Friends<br>
<input type=checkbox name="MigratePhotos"> Migrate Photos<br>
<input type=checkbox name="MigrateVideos"> Migrate Videos<br>
<input type=checkbox name="MigrateForums"> Migrate Forums<br>
<input type=checkbox name="MigrateEvents"> Migrate Events<br>
<!--
<input type=checkbox name="MigrateBlogs"> Migrate Blogs<br>
<input type=checkbox name="MigrateGroups"> Migrate Groups<br>
<input type=checkbox name="MigrateSites"> Migrate Sites<br>
<input type=checkbox name="MigrateContent"> Migrate Content<br>
-->
</fieldset>
<br>

<fieldset>
<legend>Select third party modules to migrate</legend>
<br>
<input type=checkbox name="MigrateModzzzPoints"> Migrate Modzzz Points<br>
</fieldset>
<br>

<input type=submit value="Then Press This Button To Migrate">
</form>

<hr>
<a href="http://www.deeemm.com">http://www.deeemm.com</a>

</html>
